function e(e, t) {
    const n = Object.create(null),
        o = e.split(",");
    for (let s = 0; s < o.length; s++) n[o[s]] = !0;
    return t ? e => !!n[e.toLowerCase()] : e => !!n[e]
}
const t = e("itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly");

function n(e) {
    return !!e || "" === e
}

function o(e) {
    if (_(e)) {
        const t = {};
        for (let n = 0; n < e.length; n++) {
            const s = e[n],
                l = L(s) ? i(s) : o(s);
            if (l)
                for (const e in l) t[e] = l[e]
        }
        return t
    }
    return L(e) || P(e) ? e : void 0
}
const s = /;(?![^(]*\))/g,
    l = /:(.+)/;

function i(e) {
    const t = {};
    return e.split(s).forEach((e => {
        if (e) {
            const n = e.split(l);
            n.length > 1 && (t[n[0].trim()] = n[1].trim())
        }
    })), t
}

function r(e) {
    let t = "";
    if (L(e)) t = e;
    else if (_(e))
        for (let n = 0; n < e.length; n++) {
            const o = r(e[n]);
            o && (t += o + " ")
        } else if (P(e))
            for (const n in e) e[n] && (t += n + " ");
    return t.trim()
}

function a(e, t) {
    if (e === t) return !0;
    let n = M(e),
        o = M(t);
    if (n || o) return !(!n || !o) && e.getTime() === t.getTime();
    if (n = _(e), o = _(t), n || o) return !(!n || !o) && function (e, t) {
        if (e.length !== t.length) return !1;
        let n = !0;
        for (let o = 0; n && o < e.length; o++) n = a(e[o], t[o]);
        return n
    }(e, t);
    if (n = P(e), o = P(t), n || o) {
        if (!n || !o) return !1;
        if (Object.keys(e).length !== Object.keys(t).length) return !1;
        for (const n in e) {
            const o = e.hasOwnProperty(n),
                s = t.hasOwnProperty(n);
            if (o && !s || !o && s || !a(e[n], t[n])) return !1
        }
    }
    return String(e) === String(t)
}

function c(e, t) {
    return e.findIndex((e => a(e, t)))
}
const u = e => L(e) ? e : null == e ? "" : _(e) || P(e) && (e.toString === V || !A(e.toString)) ? JSON.stringify(e, d, 2) : String(e),
    d = (e, t) => t && t.__v_isRef ? d(e, t.value) : C(t) ? {
        [`Map(${t.size})`]: [...t.entries()].reduce(((e, [t, n]) => (e[`${t} =>`] = n, e)), {})
    } : S(t) ? {
        [`Set(${t.size})`]: [...t.values()]
    } : !P(t) || _(t) || $(t) ? t : String(t),
    p = {},
    f = [],
    h = () => {},
    v = () => !1,
    m = /^on[^a-z]/,
    g = e => m.test(e),
    y = e => e.startsWith("onUpdate:"),
    b = Object.assign,
    k = (e, t) => {
        const n = e.indexOf(t);
        n > -1 && e.splice(n, 1)
    },
    x = Object.prototype.hasOwnProperty,
    w = (e, t) => x.call(e, t),
    _ = Array.isArray,
    C = e => "[object Map]" === I(e),
    S = e => "[object Set]" === I(e),
    M = e => e instanceof Date,
    A = e => "function" == typeof e,
    L = e => "string" == typeof e,
    E = e => "symbol" == typeof e,
    P = e => null !== e && "object" == typeof e,
    T = e => P(e) && A(e.then) && A(e.catch),
    V = Object.prototype.toString,
    I = e => V.call(e),
    $ = e => "[object Object]" === I(e),
    B = e => L(e) && "NaN" !== e && "-" !== e[0] && "" + parseInt(e, 10) === e,
    O = e(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
    j = e => {
        const t = Object.create(null);
        return n => t[n] || (t[n] = e(n))
    },
    F = /-(\w)/g,
    z = j((e => e.replace(F, ((e, t) => t ? t.toUpperCase() : "")))),
    R = /\B([A-Z])/g,
    N = j((e => e.replace(R, "-$1").toLowerCase())),
    H = j((e => e.charAt(0).toUpperCase() + e.slice(1))),
    D = j((e => e ? `on${H(e)}` : "")),
    U = (e, t) => !Object.is(e, t),
    W = (e, t) => {
        for (let n = 0; n < e.length; n++) e[n](t)
    },
    q = (e, t, n) => {
        Object.defineProperty(e, t, {
            configurable: !0,
            enumerable: !1,
            value: n
        })
    },
    G = e => {
        const t = parseFloat(e);
        return isNaN(t) ? e : t
    };
let K;
let Z;
class Y {
    constructor(e = !1) {
        this.active = !0, this.effects = [], this.cleanups = [], !e && Z && (this.parent = Z, this.index = (Z.scopes || (Z.scopes = [])).push(this) - 1)
    }
    run(e) {
        if (this.active) try {
            return Z = this, e()
        } finally {
            Z = this.parent
        }
    }
    on() {
        Z = this
    }
    off() {
        Z = this.parent
    }
    stop(e) {
        if (this.active) {
            let t, n;
            for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
            for (t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
            if (this.scopes)
                for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
            if (this.parent && !e) {
                const e = this.parent.scopes.pop();
                e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index)
            }
            this.active = !1
        }
    }
}
const J = e => {
        const t = new Set(e);
        return t.w = 0, t.n = 0, t
    },
    Q = e => (e.w & ne) > 0,
    X = e => (e.n & ne) > 0,
    ee = new WeakMap;
let te = 0,
    ne = 1;
let oe;
const se = Symbol(""),
    le = Symbol("");
class ie {
    constructor(e, t = null, n) {
        this.fn = e, this.scheduler = t, this.active = !0, this.deps = [], this.parent = void 0,
            function (e, t = Z) {
                t && t.active && t.effects.push(e)
            }(this, n)
    }
    run() {
        if (!this.active) return this.fn();
        let e = oe,
            t = ae;
        for (; e;) {
            if (e === this) return;
            e = e.parent
        }
        try {
            return this.parent = oe, oe = this, ae = !0, ne = 1 << ++te, te <= 30 ? (({
                deps: e
            }) => {
                if (e.length)
                    for (let t = 0; t < e.length; t++) e[t].w |= ne
            })(this) : re(this), this.fn()
        } finally {
            te <= 30 && (e => {
                const {
                    deps: t
                } = e;
                if (t.length) {
                    let n = 0;
                    for (let o = 0; o < t.length; o++) {
                        const s = t[o];
                        Q(s) && !X(s) ? s.delete(e) : t[n++] = s, s.w &= ~ne, s.n &= ~ne
                    }
                    t.length = n
                }
            })(this), ne = 1 << --te, oe = this.parent, ae = t, this.parent = void 0
        }
    }
    stop() {
        this.active && (re(this), this.onStop && this.onStop(), this.active = !1)
    }
}

function re(e) {
    const {
        deps: t
    } = e;
    if (t.length) {
        for (let n = 0; n < t.length; n++) t[n].delete(e);
        t.length = 0
    }
}
let ae = !0;
const ce = [];

function ue() {
    ce.push(ae), ae = !1
}

function de() {
    const e = ce.pop();
    ae = void 0 === e || e
}

function pe(e, t, n) {
    if (ae && oe) {
        let t = ee.get(e);
        t || ee.set(e, t = new Map);
        let o = t.get(n);
        o || t.set(n, o = J()), fe(o)
    }
}

function fe(e, t) {
    let n = !1;
    te <= 30 ? X(e) || (e.n |= ne, n = !Q(e)) : n = !e.has(oe), n && (e.add(oe), oe.deps.push(e))
}

function he(e, t, n, o, s, l) {
    const i = ee.get(e);
    if (!i) return;
    let r = [];
    if ("clear" === t) r = [...i.values()];
    else if ("length" === n && _(e)) i.forEach(((e, t) => {
        ("length" === t || t >= o) && r.push(e)
    }));
    else switch (void 0 !== n && r.push(i.get(n)), t) {
        case "add":
            _(e) ? B(n) && r.push(i.get("length")) : (r.push(i.get(se)), C(e) && r.push(i.get(le)));
            break;
        case "delete":
            _(e) || (r.push(i.get(se)), C(e) && r.push(i.get(le)));
            break;
        case "set":
            C(e) && r.push(i.get(se))
    }
    if (1 === r.length) r[0] && ve(r[0]);
    else {
        const e = [];
        for (const t of r) t && e.push(...t);
        ve(J(e))
    }
}

function ve(e, t) {
    for (const n of _(e) ? e : [...e])(n !== oe || n.allowRecurse) && (n.scheduler ? n.scheduler() : n.run())
}
const me = e("__proto__,__v_isRef,__isVue"),
    ge = new Set(Object.getOwnPropertyNames(Symbol).map((e => Symbol[e])).filter(E)),
    ye = _e(),
    be = _e(!1, !0),
    ke = _e(!0),
    xe = we();

function we() {
    const e = {};
    return ["includes", "indexOf", "lastIndexOf"].forEach((t => {
        e[t] = function (...e) {
            const n = rt(this);
            for (let t = 0, s = this.length; t < s; t++) pe(n, 0, t + "");
            const o = n[t](...e);
            return -1 === o || !1 === o ? n[t](...e.map(rt)) : o
        }
    })), ["push", "pop", "shift", "unshift", "splice"].forEach((t => {
        e[t] = function (...e) {
            ue();
            const n = rt(this)[t].apply(this, e);
            return de(), n
        }
    })), e
}

function _e(e = !1, t = !1) {
    return function (n, o, s) {
        if ("__v_isReactive" === o) return !e;
        if ("__v_isReadonly" === o) return e;
        if ("__v_isShallow" === o) return t;
        if ("__v_raw" === o && s === (e ? t ? Qe : Je : t ? Ye : Ze).get(n)) return n;
        const l = _(n);
        if (!e && l && w(xe, o)) return Reflect.get(xe, o, s);
        const i = Reflect.get(n, o, s);
        if (E(o) ? ge.has(o) : me(o)) return i;
        if (e || pe(n, 0, o), t) return i;
        if (ft(i)) {
            return !l || !B(o) ? i.value : i
        }
        return P(i) ? e ? tt(i) : et(i) : i
    }
}

function Ce(e = !1) {
    return function (t, n, o, s) {
        let l = t[n];
        if (st(l) && ft(l) && !ft(o)) return !1;
        if (!e && !st(o) && (lt(o) || (o = rt(o), l = rt(l)), !_(t) && ft(l) && !ft(o))) return l.value = o, !0;
        const i = _(t) && B(n) ? Number(n) < t.length : w(t, n),
            r = Reflect.set(t, n, o, s);
        return t === rt(s) && (i ? U(o, l) && he(t, "set", n, o) : he(t, "add", n, o)), r
    }
}
const Se = {
        get: ye,
        set: Ce(),
        deleteProperty: function (e, t) {
            const n = w(e, t);
            e[t];
            const o = Reflect.deleteProperty(e, t);
            return o && n && he(e, "delete", t, void 0), o
        },
        has: function (e, t) {
            const n = Reflect.has(e, t);
            return E(t) && ge.has(t) || pe(e, 0, t), n
        },
        ownKeys: function (e) {
            return pe(e, 0, _(e) ? "length" : se), Reflect.ownKeys(e)
        }
    },
    Me = {
        get: ke,
        set: (e, t) => !0,
        deleteProperty: (e, t) => !0
    },
    Ae = b({}, Se, {
        get: be,
        set: Ce(!0)
    }),
    Le = e => e,
    Ee = e => Reflect.getPrototypeOf(e);

function Pe(e, t, n = !1, o = !1) {
    const s = rt(e = e.__v_raw),
        l = rt(t);
    t !== l && !n && pe(s, 0, t), !n && pe(s, 0, l);
    const {
        has: i
    } = Ee(s), r = o ? Le : n ? ut : ct;
    return i.call(s, t) ? r(e.get(t)) : i.call(s, l) ? r(e.get(l)) : void(e !== s && e.get(t))
}

function Te(e, t = !1) {
    const n = this.__v_raw,
        o = rt(n),
        s = rt(e);
    return e !== s && !t && pe(o, 0, e), !t && pe(o, 0, s), e === s ? n.has(e) : n.has(e) || n.has(s)
}

function Ve(e, t = !1) {
    return e = e.__v_raw, !t && pe(rt(e), 0, se), Reflect.get(e, "size", e)
}

function Ie(e) {
    e = rt(e);
    const t = rt(this);
    return Ee(t).has.call(t, e) || (t.add(e), he(t, "add", e, e)), this
}

function $e(e, t) {
    t = rt(t);
    const n = rt(this),
        {
            has: o,
            get: s
        } = Ee(n);
    let l = o.call(n, e);
    l || (e = rt(e), l = o.call(n, e));
    const i = s.call(n, e);
    return n.set(e, t), l ? U(t, i) && he(n, "set", e, t) : he(n, "add", e, t), this
}

function Be(e) {
    const t = rt(this),
        {
            has: n,
            get: o
        } = Ee(t);
    let s = n.call(t, e);
    s || (e = rt(e), s = n.call(t, e)), o && o.call(t, e);
    const l = t.delete(e);
    return s && he(t, "delete", e, void 0), l
}

function Oe() {
    const e = rt(this),
        t = 0 !== e.size,
        n = e.clear();
    return t && he(e, "clear", void 0, void 0), n
}

function je(e, t) {
    return function (n, o) {
        const s = this,
            l = s.__v_raw,
            i = rt(l),
            r = t ? Le : e ? ut : ct;
        return !e && pe(i, 0, se), l.forEach(((e, t) => n.call(o, r(e), r(t), s)))
    }
}

function Fe(e, t, n) {
    return function (...o) {
        const s = this.__v_raw,
            l = rt(s),
            i = C(l),
            r = "entries" === e || e === Symbol.iterator && i,
            a = "keys" === e && i,
            c = s[e](...o),
            u = n ? Le : t ? ut : ct;
        return !t && pe(l, 0, a ? le : se), {
            next() {
                const {
                    value: e,
                    done: t
                } = c.next();
                return t ? {
                    value: e,
                    done: t
                } : {
                    value: r ? [u(e[0]), u(e[1])] : u(e),
                    done: t
                }
            },
            [Symbol.iterator]() {
                return this
            }
        }
    }
}

function ze(e) {
    return function (...t) {
        return "delete" !== e && this
    }
}

function Re() {
    const e = {
            get(e) {
                return Pe(this, e)
            },
            get size() {
                return Ve(this)
            },
            has: Te,
            add: Ie,
            set: $e,
            delete: Be,
            clear: Oe,
            forEach: je(!1, !1)
        },
        t = {
            get(e) {
                return Pe(this, e, !1, !0)
            },
            get size() {
                return Ve(this)
            },
            has: Te,
            add: Ie,
            set: $e,
            delete: Be,
            clear: Oe,
            forEach: je(!1, !0)
        },
        n = {
            get(e) {
                return Pe(this, e, !0)
            },
            get size() {
                return Ve(this, !0)
            },
            has(e) {
                return Te.call(this, e, !0)
            },
            add: ze("add"),
            set: ze("set"),
            delete: ze("delete"),
            clear: ze("clear"),
            forEach: je(!0, !1)
        },
        o = {
            get(e) {
                return Pe(this, e, !0, !0)
            },
            get size() {
                return Ve(this, !0)
            },
            has(e) {
                return Te.call(this, e, !0)
            },
            add: ze("add"),
            set: ze("set"),
            delete: ze("delete"),
            clear: ze("clear"),
            forEach: je(!0, !0)
        };
    return ["keys", "values", "entries", Symbol.iterator].forEach((s => {
        e[s] = Fe(s, !1, !1), n[s] = Fe(s, !0, !1), t[s] = Fe(s, !1, !0), o[s] = Fe(s, !0, !0)
    })), [e, n, t, o]
}
const [Ne, He, De, Ue] = Re();

function We(e, t) {
    const n = t ? e ? Ue : De : e ? He : Ne;
    return (t, o, s) => "__v_isReactive" === o ? !e : "__v_isReadonly" === o ? e : "__v_raw" === o ? t : Reflect.get(w(n, o) && o in t ? n : t, o, s)
}
const qe = {
        get: We(!1, !1)
    },
    Ge = {
        get: We(!1, !0)
    },
    Ke = {
        get: We(!0, !1)
    },
    Ze = new WeakMap,
    Ye = new WeakMap,
    Je = new WeakMap,
    Qe = new WeakMap;

function Xe(e) {
    return e.__v_skip || !Object.isExtensible(e) ? 0 : function (e) {
        switch (e) {
            case "Object":
            case "Array":
                return 1;
            case "Map":
            case "Set":
            case "WeakMap":
            case "WeakSet":
                return 2;
            default:
                return 0
        }
    }((e => I(e).slice(8, -1))(e))
}

function et(e) {
    return st(e) ? e : nt(e, !1, Se, qe, Ze)
}

function tt(e) {
    return nt(e, !0, Me, Ke, Je)
}

function nt(e, t, n, o, s) {
    if (!P(e)) return e;
    if (e.__v_raw && (!t || !e.__v_isReactive)) return e;
    const l = s.get(e);
    if (l) return l;
    const i = Xe(e);
    if (0 === i) return e;
    const r = new Proxy(e, 2 === i ? o : n);
    return s.set(e, r), r
}

function ot(e) {
    return st(e) ? ot(e.__v_raw) : !(!e || !e.__v_isReactive)
}

function st(e) {
    return !(!e || !e.__v_isReadonly)
}

function lt(e) {
    return !(!e || !e.__v_isShallow)
}

function it(e) {
    return ot(e) || st(e)
}

function rt(e) {
    const t = e && e.__v_raw;
    return t ? rt(t) : e
}

function at(e) {
    return q(e, "__v_skip", !0), e
}
const ct = e => P(e) ? et(e) : e,
    ut = e => P(e) ? tt(e) : e;

function dt(e) {
    ae && oe && fe((e = rt(e)).dep || (e.dep = J()))
}

function pt(e, t) {
    (e = rt(e)).dep && ve(e.dep)
}

function ft(e) {
    return !(!e || !0 !== e.__v_isRef)
}

function ht(e) {
    return mt(e, !1)
}

function vt(e) {
    return mt(e, !0)
}

function mt(e, t) {
    return ft(e) ? e : new gt(e, t)
}
class gt {
    constructor(e, t) {
        this.__v_isShallow = t, this.dep = void 0, this.__v_isRef = !0, this._rawValue = t ? e : rt(e), this._value = t ? e : ct(e)
    }
    get value() {
        return dt(this), this._value
    }
    set value(e) {
        e = this.__v_isShallow ? e : rt(e), U(e, this._rawValue) && (this._rawValue = e, this._value = this.__v_isShallow ? e : ct(e), pt(this))
    }
}

function yt(e) {
    return ft(e) ? e.value : e
}
const bt = {
    get: (e, t, n) => yt(Reflect.get(e, t, n)),
    set: (e, t, n, o) => {
        const s = e[t];
        return ft(s) && !ft(n) ? (s.value = n, !0) : Reflect.set(e, t, n, o)
    }
};

function kt(e) {
    return ot(e) ? e : new Proxy(e, bt)
}
class xt {
    constructor(e, t, n) {
        this._object = e, this._key = t, this._defaultValue = n, this.__v_isRef = !0
    }
    get value() {
        const e = this._object[this._key];
        return void 0 === e ? this._defaultValue : e
    }
    set value(e) {
        this._object[this._key] = e
    }
}

function wt(e, t, n) {
    const o = e[t];
    return ft(o) ? o : new xt(e, t, n)
}
class _t {
    constructor(e, t, n, o) {
        this._setter = t, this.dep = void 0, this.__v_isRef = !0, this._dirty = !0, this.effect = new ie(e, (() => {
            this._dirty || (this._dirty = !0, pt(this))
        })), this.effect.computed = this, this.effect.active = this._cacheable = !o, this.__v_isReadonly = n
    }
    get value() {
        const e = rt(this);
        return dt(e), !e._dirty && e._cacheable || (e._dirty = !1, e._value = e.effect.run()), e._value
    }
    set value(e) {
        this._setter(e)
    }
}

function Ct(e, t, n, o) {
    let s;
    try {
        s = o ? e(...o) : e()
    } catch (l) {
        Mt(l, t, n)
    }
    return s
}

function St(e, t, n, o) {
    if (A(e)) {
        const s = Ct(e, t, n, o);
        return s && T(s) && s.catch((e => {
            Mt(e, t, n)
        })), s
    }
    const s = [];
    for (let l = 0; l < e.length; l++) s.push(St(e[l], t, n, o));
    return s
}

function Mt(e, t, n, o = !0) {
    t && t.vnode;
    if (t) {
        let o = t.parent;
        const s = t.proxy,
            l = n;
        for (; o;) {
            const t = o.ec;
            if (t)
                for (let n = 0; n < t.length; n++)
                    if (!1 === t[n](e, s, l)) return;
            o = o.parent
        }
        const i = t.appContext.config.errorHandler;
        if (i) return void Ct(i, null, 10, [e, s, l])
    }! function (e, t, n, o = !0) {
        console.error(e)
    }(e, 0, 0, o)
}
Promise.resolve();
let At = !1,
    Lt = !1;
const Et = [];
let Pt = 0;
const Tt = [];
let Vt = null,
    It = 0;
const $t = [];
let Bt = null,
    Ot = 0;
const jt = Promise.resolve();
let Ft = null,
    zt = null;

function Rt(e) {
    const t = Ft || jt;
    return e ? t.then(this ? e.bind(this) : e) : t
}

function Nt(e) {
    Et.length && Et.includes(e, At && e.allowRecurse ? Pt + 1 : Pt) || e === zt || (null == e.id ? Et.push(e) : Et.splice(function (e) {
        let t = Pt + 1,
            n = Et.length;
        for (; t < n;) {
            const o = t + n >>> 1;
            qt(Et[o]) < e ? t = o + 1 : n = o
        }
        return t
    }(e.id), 0, e), Ht())
}

function Ht() {
    At || Lt || (Lt = !0, Ft = jt.then(Gt))
}

function Dt(e, t, n, o) {
    _(e) ? n.push(...e) : t && t.includes(e, e.allowRecurse ? o + 1 : o) || n.push(e), Ht()
}

function Ut(e, t = null) {
    if (Tt.length) {
        for (zt = t, Vt = [...new Set(Tt)], Tt.length = 0, It = 0; It < Vt.length; It++) Vt[It]();
        Vt = null, It = 0, zt = null, Ut(e, t)
    }
}

function Wt(e) {
    if ($t.length) {
        const e = [...new Set($t)];
        if ($t.length = 0, Bt) return void Bt.push(...e);
        for (Bt = e, Bt.sort(((e, t) => qt(e) - qt(t))), Ot = 0; Ot < Bt.length; Ot++) Bt[Ot]();
        Bt = null, Ot = 0
    }
}
const qt = e => null == e.id ? 1 / 0 : e.id;

function Gt(e) {
    Lt = !1, At = !0, Ut(e), Et.sort(((e, t) => qt(e) - qt(t)));
    try {
        for (Pt = 0; Pt < Et.length; Pt++) {
            const e = Et[Pt];
            e && !1 !== e.active && Ct(e, null, 14)
        }
    } finally {
        Pt = 0, Et.length = 0, Wt(), At = !1, Ft = null, (Et.length || Tt.length || $t.length) && Gt(e)
    }
}

function Kt(e, t, ...n) {
    const o = e.vnode.props || p;
    let s = n;
    const l = t.startsWith("update:"),
        i = l && t.slice(7);
    if (i && i in o) {
        const e = `${"modelValue"===i?"model":i}Modifiers`,
            {
                number: t,
                trim: l
            } = o[e] || p;
        l ? s = n.map((e => e.trim())) : t && (s = n.map(G))
    }
    let r, a = o[r = D(t)] || o[r = D(z(t))];
    !a && l && (a = o[r = D(N(t))]), a && St(a, e, 6, s);
    const c = o[r + "Once"];
    if (c) {
        if (e.emitted) {
            if (e.emitted[r]) return
        } else e.emitted = {};
        e.emitted[r] = !0, St(c, e, 6, s)
    }
}

function Zt(e, t, n = !1) {
    const o = t.emitsCache,
        s = o.get(e);
    if (void 0 !== s) return s;
    const l = e.emits;
    let i = {};
    return l ? (_(l) ? l.forEach((e => i[e] = null)) : b(i, l), o.set(e, i), i) : (o.set(e, null), null)
}

function Yt(e, t) {
    return !(!e || !g(t)) && (t = t.slice(2).replace(/Once$/, ""), w(e, t[0].toLowerCase() + t.slice(1)) || w(e, N(t)) || w(e, t))
}
let Jt = null,
    Qt = null;

function Xt(e) {
    const t = Jt;
    return Jt = e, Qt = e && e.type.__scopeId || null, t
}

function en(e) {
    Qt = e
}

function tn() {
    Qt = null
}

function nn(e, t = Jt, n) {
    if (!t) return e;
    if (e._n) return e;
    const o = (...n) => {
        o._d && To(-1);
        const s = Xt(t),
            l = e(...n);
        return Xt(s), o._d && To(1), l
    };
    return o._n = !0, o._c = !0, o._d = !0, o
}

function on(e) {
    const {
        type: t,
        vnode: n,
        proxy: o,
        withProxy: s,
        props: l,
        propsOptions: [i],
        slots: r,
        attrs: a,
        emit: c,
        render: u,
        renderCache: d,
        data: p,
        setupState: f,
        ctx: h,
        inheritAttrs: v
    } = e;
    let m, g;
    const b = Xt(e);
    try {
        if (4 & n.shapeFlag) {
            const e = s || o;
            m = qo(u.call(e, e, d, l, f, p, h)), g = a
        } else {
            const e = t;
            0, m = qo(e.length > 1 ? e(l, {
                attrs: a,
                slots: r,
                emit: c
            }) : e(l, null)), g = t.props ? a : sn(a)
        }
    } catch (x) {
        Ao.length = 0, Mt(x, e, 1), m = No(So)
    }
    let k = m;
    if (g && !1 !== v) {
        const e = Object.keys(g),
            {
                shapeFlag: t
            } = k;
        e.length && 7 & t && (i && e.some(y) && (g = ln(g, i)), k = Ho(k, g))
    }
    return n.dirs && (k.dirs = k.dirs ? k.dirs.concat(n.dirs) : n.dirs), n.transition && (k.transition = n.transition), m = k, Xt(b), m
}
const sn = e => {
        let t;
        for (const n in e)("class" === n || "style" === n || g(n)) && ((t || (t = {}))[n] = e[n]);
        return t
    },
    ln = (e, t) => {
        const n = {};
        for (const o in e) y(o) && o.slice(9) in t || (n[o] = e[o]);
        return n
    };

function rn(e, t, n) {
    const o = Object.keys(t);
    if (o.length !== Object.keys(e).length) return !0;
    for (let s = 0; s < o.length; s++) {
        const l = o[s];
        if (t[l] !== e[l] && !Yt(n, l)) return !0
    }
    return !1
}

function an(e, t) {
    t && t.pendingBranch ? _(e) ? t.effects.push(...e) : t.effects.push(e) : Dt(e, Bt, $t, Ot)
}

function cn(e, t) {
    if (ss) {
        let n = ss.provides;
        const o = ss.parent && ss.parent.provides;
        o === n && (n = ss.provides = Object.create(o)), n[e] = t
    } else;
}

function un(e, t, n = !1) {
    const o = ss || Jt;
    if (o) {
        const s = null == o.parent ? o.vnode.appContext && o.vnode.appContext.provides : o.parent.provides;
        if (s && e in s) return s[e];
        if (arguments.length > 1) return n && A(t) ? t.call(o.proxy) : t
    }
}

function dn(e, t) {
    return hn(e, null, t)
}
const pn = {};

function fn(e, t, n) {
    return hn(e, t, n)
}

function hn(e, t, {
    immediate: n,
    deep: o,
    flush: s,
    onTrack: l,
    onTrigger: i
} = p) {
    const r = ss;
    let a, c, u = !1,
        d = !1;
    if (ft(e) ? (a = () => e.value, u = lt(e)) : ot(e) ? (a = () => e, o = !0) : _(e) ? (d = !0, u = e.some(ot), a = () => e.map((e => ft(e) ? e.value : ot(e) ? vn(e) : A(e) ? Ct(e, r, 2) : void 0))) : a = A(e) ? t ? () => Ct(e, r, 2) : () => {
            if (!r || !r.isUnmounted) return c && c(), St(e, r, 3, [f])
        } : h, t && o) {
        const e = a;
        a = () => vn(e())
    }
    let f = e => {
        c = y.onStop = () => {
            Ct(e, r, 4)
        }
    };
    if (cs) return f = h, t ? n && St(t, r, 3, [a(), d ? [] : void 0, f]) : a(), h;
    let v = d ? [] : pn;
    const m = () => {
        if (y.active)
            if (t) {
                const e = y.run();
                (o || u || (d ? e.some(((e, t) => U(e, v[t]))) : U(e, v))) && (c && c(), St(t, r, 3, [e, v === pn ? void 0 : v, f]), v = e)
            } else y.run()
    };
    let g;
    m.allowRecurse = !!t, g = "sync" === s ? m : "post" === s ? () => ao(m, r && r.suspense) : () => {
        !r || r.isMounted ? function (e) {
            Dt(e, Vt, Tt, It)
        }(m) : m()
    };
    const y = new ie(a, g);
    return t ? n ? m() : v = y.run() : "post" === s ? ao(y.run.bind(y), r && r.suspense) : y.run(), () => {
        y.stop(), r && r.scope && k(r.scope.effects, y)
    }
}

function vn(e, t) {
    if (!P(e) || e.__v_skip) return e;
    if ((t = t || new Set).has(e)) return e;
    if (t.add(e), ft(e)) vn(e.value, t);
    else if (_(e))
        for (let n = 0; n < e.length; n++) vn(e[n], t);
    else if (S(e) || C(e)) e.forEach((e => {
        vn(e, t)
    }));
    else if ($(e))
        for (const n in e) vn(e[n], t);
    return e
}

function mn() {
    const e = {
        isMounted: !1,
        isLeaving: !1,
        isUnmounting: !1,
        leavingVNodes: new Map
    };
    return Bn((() => {
        e.isMounted = !0
    })), jn((() => {
        e.isUnmounting = !0
    })), e
}
const gn = [Function, Array],
    yn = {
        name: "BaseTransition",
        props: {
            mode: String,
            appear: Boolean,
            persisted: Boolean,
            onBeforeEnter: gn,
            onEnter: gn,
            onAfterEnter: gn,
            onEnterCancelled: gn,
            onBeforeLeave: gn,
            onLeave: gn,
            onAfterLeave: gn,
            onLeaveCancelled: gn,
            onBeforeAppear: gn,
            onAppear: gn,
            onAfterAppear: gn,
            onAppearCancelled: gn
        },
        setup(e, {
            slots: t
        }) {
            const n = ls(),
                o = mn();
            let s;
            return () => {
                const l = t.default && Cn(t.default(), !0);
                if (!l || !l.length) return;
                const i = rt(e),
                    {
                        mode: r
                    } = i,
                    a = l[0];
                if (o.isLeaving) return xn(a);
                const c = wn(a);
                if (!c) return xn(a);
                const u = kn(c, i, o, n);
                _n(c, u);
                const d = n.subTree,
                    p = d && wn(d);
                let f = !1;
                const {
                    getTransitionKey: h
                } = c.type;
                if (h) {
                    const e = h();
                    void 0 === s ? s = e : e !== s && (s = e, f = !0)
                }
                if (p && p.type !== So && (!Oo(c, p) || f)) {
                    const e = kn(p, i, o, n);
                    if (_n(p, e), "out-in" === r) return o.isLeaving = !0, e.afterLeave = () => {
                        o.isLeaving = !1, n.update()
                    }, xn(a);
                    "in-out" === r && c.type !== So && (e.delayLeave = (e, t, n) => {
                        bn(o, p)[String(p.key)] = p, e._leaveCb = () => {
                            t(), e._leaveCb = void 0, delete u.delayedLeave
                        }, u.delayedLeave = n
                    })
                }
                return a
            }
        }
    };

function bn(e, t) {
    const {
        leavingVNodes: n
    } = e;
    let o = n.get(t.type);
    return o || (o = Object.create(null), n.set(t.type, o)), o
}

function kn(e, t, n, o) {
    const {
        appear: s,
        mode: l,
        persisted: i = !1,
        onBeforeEnter: r,
        onEnter: a,
        onAfterEnter: c,
        onEnterCancelled: u,
        onBeforeLeave: d,
        onLeave: p,
        onAfterLeave: f,
        onLeaveCancelled: h,
        onBeforeAppear: v,
        onAppear: m,
        onAfterAppear: g,
        onAppearCancelled: y
    } = t, b = String(e.key), k = bn(n, e), x = (e, t) => {
        e && St(e, o, 9, t)
    }, w = {
        mode: l,
        persisted: i,
        beforeEnter(t) {
            let o = r;
            if (!n.isMounted) {
                if (!s) return;
                o = v || r
            }
            t._leaveCb && t._leaveCb(!0);
            const l = k[b];
            l && Oo(e, l) && l.el._leaveCb && l.el._leaveCb(), x(o, [t])
        },
        enter(e) {
            let t = a,
                o = c,
                l = u;
            if (!n.isMounted) {
                if (!s) return;
                t = m || a, o = g || c, l = y || u
            }
            let i = !1;
            const r = e._enterCb = t => {
                i || (i = !0, x(t ? l : o, [e]), w.delayedLeave && w.delayedLeave(), e._enterCb = void 0)
            };
            t ? (t(e, r), t.length <= 1 && r()) : r()
        },
        leave(t, o) {
            const s = String(e.key);
            if (t._enterCb && t._enterCb(!0), n.isUnmounting) return o();
            x(d, [t]);
            let l = !1;
            const i = t._leaveCb = n => {
                l || (l = !0, o(), x(n ? h : f, [t]), t._leaveCb = void 0, k[s] === e && delete k[s])
            };
            k[s] = e, p ? (p(t, i), p.length <= 1 && i()) : i()
        },
        clone: e => kn(e, t, n, o)
    };
    return w
}

function xn(e) {
    if (En(e)) return (e = Ho(e)).children = null, e
}

function wn(e) {
    return En(e) ? e.children ? e.children[0] : void 0 : e
}

function _n(e, t) {
    6 & e.shapeFlag && e.component ? _n(e.component.subTree, t) : 128 & e.shapeFlag ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
}

function Cn(e, t = !1) {
    let n = [],
        o = 0;
    for (let s = 0; s < e.length; s++) {
        const l = e[s];
        l.type === _o ? (128 & l.patchFlag && o++, n = n.concat(Cn(l.children, t))) : (t || l.type !== So) && n.push(l)
    }
    if (o > 1)
        for (let s = 0; s < n.length; s++) n[s].patchFlag = -2;
    return n
}

function Sn(e) {
    return A(e) ? {
        setup: e,
        name: e.name
    } : e
}
const Mn = e => !!e.type.__asyncLoader;

function An(e) {
    A(e) && (e = {
        loader: e
    });
    const {
        loader: t,
        loadingComponent: n,
        errorComponent: o,
        delay: s = 200,
        timeout: l,
        suspensible: i = !0,
        onError: r
    } = e;
    let a, c = null,
        u = 0;
    const d = () => {
        let e;
        return c || (e = c = t().catch((e => {
            if (e = e instanceof Error ? e : new Error(String(e)), r) return new Promise(((t, n) => {
                r(e, (() => t((u++, c = null, d()))), (() => n(e)), u + 1)
            }));
            throw e
        })).then((t => e !== c && c ? c : (t && (t.__esModule || "Module" === t[Symbol.toStringTag]) && (t = t.default), a = t, t))))
    };
    return Sn({
        name: "AsyncComponentWrapper",
        __asyncLoader: d,
        get __asyncResolved() {
            return a
        },
        setup() {
            const e = ss;
            if (a) return () => Ln(a, e);
            const t = t => {
                c = null, Mt(t, e, 13, !o)
            };
            if (i && e.suspense || cs) return d().then((t => () => Ln(t, e))).catch((e => (t(e), () => o ? No(o, {
                error: e
            }) : null)));
            const r = ht(!1),
                u = ht(),
                p = ht(!!s);
            return s && setTimeout((() => {
                p.value = !1
            }), s), null != l && setTimeout((() => {
                if (!r.value && !u.value) {
                    const e = new Error(`Async component timed out after ${l}ms.`);
                    t(e), u.value = e
                }
            }), l), d().then((() => {
                r.value = !0, e.parent && En(e.parent.vnode) && Nt(e.parent.update)
            })).catch((e => {
                t(e), u.value = e
            })), () => r.value && a ? Ln(a, e) : u.value && o ? No(o, {
                error: u.value
            }) : n && !p.value ? No(n) : void 0
        }
    })
}

function Ln(e, {
    vnode: {
        ref: t,
        props: n,
        children: o
    }
}) {
    const s = No(e, n, o);
    return s.ref = t, s
}
const En = e => e.type.__isKeepAlive,
    Pn = {
        name: "KeepAlive",
        __isKeepAlive: !0,
        props: {
            include: [String, RegExp, Array],
            exclude: [String, RegExp, Array],
            max: [String, Number]
        },
        setup(e, {
            slots: t
        }) {
            const n = ls(),
                o = n.ctx;
            if (!o.renderer) return t.default;
            const s = new Map,
                l = new Set;
            let i = null;
            const r = n.suspense,
                {
                    renderer: {
                        p: a,
                        m: c,
                        um: u,
                        o: {
                            createElement: d
                        }
                    }
                } = o,
                p = d("div");

            function f(e) {
                Vn(e), u(e, n, r, !0)
            }

            function h(e) {
                s.forEach(((t, n) => {
                    const o = fs(t.type);
                    !o || e && e(o) || v(n)
                }))
            }

            function v(e) {
                const t = s.get(e);
                i && t.type === i.type ? i && Vn(i) : f(t), s.delete(e), l.delete(e)
            }
            o.activate = (e, t, n, o, s) => {
                const l = e.component;
                c(e, t, n, 0, r), a(l.vnode, e, t, n, l, r, o, e.slotScopeIds, s), ao((() => {
                    l.isDeactivated = !1, l.a && W(l.a);
                    const t = e.props && e.props.onVnodeMounted;
                    t && Zo(t, l.parent, e)
                }), r)
            }, o.deactivate = e => {
                const t = e.component;
                c(e, p, null, 1, r), ao((() => {
                    t.da && W(t.da);
                    const n = e.props && e.props.onVnodeUnmounted;
                    n && Zo(n, t.parent, e), t.isDeactivated = !0
                }), r)
            }, fn((() => [e.include, e.exclude]), (([e, t]) => {
                e && h((t => Tn(e, t))), t && h((e => !Tn(t, e)))
            }), {
                flush: "post",
                deep: !0
            });
            let m = null;
            const g = () => {
                null != m && s.set(m, In(n.subTree))
            };
            return Bn(g), On(g), jn((() => {
                s.forEach((e => {
                    const {
                        subTree: t,
                        suspense: o
                    } = n, s = In(t);
                    if (e.type !== s.type) f(e);
                    else {
                        Vn(s);
                        const e = s.component.da;
                        e && ao(e, o)
                    }
                }))
            })), () => {
                if (m = null, !t.default) return null;
                const n = t.default(),
                    o = n[0];
                if (n.length > 1) return i = null, n;
                if (!(Bo(o) && (4 & o.shapeFlag || 128 & o.shapeFlag))) return i = null, o;
                let r = In(o);
                const a = r.type,
                    c = fs(Mn(r) ? r.type.__asyncResolved || {} : a),
                    {
                        include: u,
                        exclude: d,
                        max: p
                    } = e;
                if (u && (!c || !Tn(u, c)) || d && c && Tn(d, c)) return i = r, o;
                const f = null == r.key ? a : r.key,
                    h = s.get(f);
                return r.el && (r = Ho(r), 128 & o.shapeFlag && (o.ssContent = r)), m = f, h ? (r.el = h.el, r.component = h.component, r.transition && _n(r, r.transition), r.shapeFlag |= 512, l.delete(f), l.add(f)) : (l.add(f), p && l.size > parseInt(p, 10) && v(l.values().next().value)), r.shapeFlag |= 256, i = r, o
            }
        }
    };

function Tn(e, t) {
    return _(e) ? e.some((e => Tn(e, t))) : L(e) ? e.split(",").includes(t) : !!e.test && e.test(t)
}

function Vn(e) {
    let t = e.shapeFlag;
    256 & t && (t -= 256), 512 & t && (t -= 512), e.shapeFlag = t
}

function In(e) {
    return 128 & e.shapeFlag ? e.ssContent : e
}
const $n = e => (t, n = ss) => (!cs || "sp" === e) && function (e, t, n = ss, o = !1) {
        if (n) {
            const s = n[e] || (n[e] = []),
                l = t.__weh || (t.__weh = (...o) => {
                    if (n.isUnmounted) return;
                    ue(), is(n);
                    const s = St(t, n, e, o);
                    return rs(), de(), s
                });
            return o ? s.unshift(l) : s.push(l), l
        }
    }(e, t, n),
    Bn = $n("m"),
    On = $n("u"),
    jn = $n("bum"),
    Fn = $n("um");

function zn(e, t, n, o = !1) {
    const s = {},
        l = {};
    q(l, jo, 1), e.propsDefaults = Object.create(null), Rn(e, t, s, l);
    for (const i in e.propsOptions[0]) i in s || (s[i] = void 0);
    n ? e.props = o ? s : nt(s, !1, Ae, Ge, Ye) : e.type.props ? e.props = s : e.props = l, e.attrs = l
}

function Rn(e, t, n, o) {
    const [s, l] = e.propsOptions;
    let i, r = !1;
    if (t)
        for (let a in t) {
            if (O(a)) continue;
            const c = t[a];
            let u;
            s && w(s, u = z(a)) ? l && l.includes(u) ? (i || (i = {}))[u] = c : n[u] = c : Yt(e.emitsOptions, a) || a in o && c === o[a] || (o[a] = c, r = !0)
        }
    if (l) {
        const t = rt(n),
            o = i || p;
        for (let i = 0; i < l.length; i++) {
            const r = l[i];
            n[r] = Nn(s, t, r, o[r], e, !w(o, r))
        }
    }
    return r
}

function Nn(e, t, n, o, s, l) {
    const i = e[n];
    if (null != i) {
        const e = w(i, "default");
        if (e && void 0 === o) {
            const e = i.default;
            if (i.type !== Function && A(e)) {
                const {
                    propsDefaults: l
                } = s;
                n in l ? o = l[n] : (is(s), o = l[n] = e.call(null, t), rs())
            } else o = e
        }
        i[0] && (l && !e ? o = !1 : !i[1] || "" !== o && o !== N(n) || (o = !0))
    }
    return o
}

function Hn(e, t, n = !1) {
    const o = t.propsCache,
        s = o.get(e);
    if (s) return s;
    const l = e.props,
        i = {},
        r = [];
    if (!l) return o.set(e, f), f;
    if (_(l))
        for (let c = 0; c < l.length; c++) {
            const e = z(l[c]);
            Dn(e) && (i[e] = p)
        } else if (l)
            for (const c in l) {
                const e = z(c);
                if (Dn(e)) {
                    const t = l[c],
                        n = i[e] = _(t) || A(t) ? {
                            type: t
                        } : t;
                    if (n) {
                        const t = qn(Boolean, n.type),
                            o = qn(String, n.type);
                        n[0] = t > -1, n[1] = o < 0 || t < o, (t > -1 || w(n, "default")) && r.push(e)
                    }
                }
            }
    const a = [i, r];
    return o.set(e, a), a
}

function Dn(e) {
    return "$" !== e[0]
}

function Un(e) {
    const t = e && e.toString().match(/^\s*function (\w+)/);
    return t ? t[1] : null === e ? "null" : ""
}

function Wn(e, t) {
    return Un(e) === Un(t)
}

function qn(e, t) {
    return _(t) ? t.findIndex((t => Wn(t, e))) : A(t) && Wn(t, e) ? 0 : -1
}
const Gn = e => "_" === e[0] || "$stable" === e,
    Kn = e => _(e) ? e.map(qo) : [qo(e)],
    Zn = (e, t, n) => {
        const o = nn(((...e) => Kn(t(...e))), n);
        return o._c = !1, o
    },
    Yn = (e, t, n) => {
        const o = e._ctx;
        for (const s in e) {
            if (Gn(s)) continue;
            const n = e[s];
            if (A(n)) t[s] = Zn(0, n, o);
            else if (null != n) {
                const e = Kn(n);
                t[s] = () => e
            }
        }
    },
    Jn = (e, t) => {
        const n = Kn(t);
        e.slots.default = () => n
    };

function Qn(e, t) {
    if (null === Jt) return e;
    const n = Jt.proxy,
        o = e.dirs || (e.dirs = []);
    for (let s = 0; s < t.length; s++) {
        let [e, l, i, r = p] = t[s];
        A(e) && (e = {
            mounted: e,
            updated: e
        }), e.deep && vn(l), o.push({
            dir: e,
            instance: n,
            value: l,
            oldValue: void 0,
            arg: i,
            modifiers: r
        })
    }
    return e
}

function Xn(e, t, n, o) {
    const s = e.dirs,
        l = t && t.dirs;
    for (let i = 0; i < s.length; i++) {
        const r = s[i];
        l && (r.oldValue = l[i].value);
        let a = r.dir[o];
        a && (ue(), St(a, n, 8, [e.el, r, e, t]), de())
    }
}

function eo() {
    return {
        app: null,
        config: {
            isNativeTag: v,
            performance: !1,
            globalProperties: {},
            optionMergeStrategies: {},
            errorHandler: void 0,
            warnHandler: void 0,
            compilerOptions: {}
        },
        mixins: [],
        components: {},
        directives: {},
        provides: Object.create(null),
        optionsCache: new WeakMap,
        propsCache: new WeakMap,
        emitsCache: new WeakMap
    }
}
let to = 0;

function no(e, t) {
    return function (n, o = null) {
        null == o || P(o) || (o = null);
        const s = eo(),
            l = new Set;
        let i = !1;
        const r = s.app = {
            _uid: to++,
            _component: n,
            _props: o,
            _container: null,
            _context: s,
            _instance: null,
            version: ms,
            get config() {
                return s.config
            },
            set config(e) {},
            use: (e, ...t) => (l.has(e) || (e && A(e.install) ? (l.add(e), e.install(r, ...t)) : A(e) && (l.add(e), e(r, ...t))), r),
            mixin: e => r,
            component: (e, t) => t ? (s.components[e] = t, r) : s.components[e],
            directive: (e, t) => t ? (s.directives[e] = t, r) : s.directives[e],
            mount(l, a, c) {
                if (!i) {
                    const u = No(n, o);
                    return u.appContext = s, a && t ? t(u, l) : e(u, l, c), i = !0, r._container = l, l.__vue_app__ = r, ps(u.component) || u.component.proxy
                }
            },
            unmount() {
                i && (e(null, r._container), delete r._container.__vue_app__)
            },
            provide: (e, t) => (s.provides[e] = t, r)
        };
        return r
    }
}

function oo(e, t, n, o, s = !1) {
    if (_(e)) return void e.forEach(((e, l) => oo(e, t && (_(t) ? t[l] : t), n, o, s)));
    if (Mn(o) && !s) return;
    const l = 4 & o.shapeFlag ? ps(o.component) || o.component.proxy : o.el,
        i = s ? null : l,
        {
            i: r,
            r: a
        } = e,
        c = t && t.r,
        u = r.refs === p ? r.refs = {} : r.refs,
        d = r.setupState;
    if (null != c && c !== a && (L(c) ? (u[c] = null, w(d, c) && (d[c] = null)) : ft(c) && (c.value = null)), A(a)) Ct(a, r, 12, [i, u]);
    else {
        const t = L(a),
            o = ft(a);
        if (t || o) {
            const o = () => {
                if (e.f) {
                    const n = t ? u[a] : a.value;
                    s ? _(n) && k(n, l) : _(n) ? n.includes(l) || n.push(l) : t ? u[a] = [l] : (a.value = [l], e.k && (u[e.k] = a.value))
                } else t ? (u[a] = i, w(d, a) && (d[a] = i)) : ft(a) && (a.value = i, e.k && (u[e.k] = i))
            };
            i ? (o.id = -1, ao(o, n)) : o()
        }
    }
}
let so = !1;
const lo = e => /svg/.test(e.namespaceURI) && "foreignObject" !== e.tagName,
    io = e => 8 === e.nodeType;

function ro(e) {
    const {
        mt: t,
        p: n,
        o: {
            patchProp: o,
            nextSibling: s,
            parentNode: l,
            remove: i,
            insert: r,
            createComment: a
        }
    } = e, c = (n, o, i, r, a, v = !1) => {
        const m = io(n) && "[" === n.data,
            g = () => f(n, o, i, r, a, m),
            {
                type: y,
                ref: b,
                shapeFlag: k
            } = o,
            x = n.nodeType;
        o.el = n;
        let w = null;
        switch (y) {
            case Co:
                3 !== x ? w = g() : (n.data !== o.children && (so = !0, n.data = o.children), w = s(n));
                break;
            case So:
                w = 8 !== x || m ? g() : s(n);
                break;
            case Mo:
                if (1 === x) {
                    w = n;
                    const e = !o.children.length;
                    for (let t = 0; t < o.staticCount; t++) e && (o.children += w.outerHTML), t === o.staticCount - 1 && (o.anchor = w), w = s(w);
                    return w
                }
                w = g();
                break;
            case _o:
                w = m ? p(n, o, i, r, a, v) : g();
                break;
            default:
                if (1 & k) w = 1 !== x || o.type.toLowerCase() !== n.tagName.toLowerCase() ? g() : u(n, o, i, r, a, v);
                else if (6 & k) {
                    o.slotScopeIds = a;
                    const e = l(n);
                    if (t(o, e, null, i, r, lo(e), v), w = m ? h(n) : s(n), Mn(o)) {
                        let t;
                        m ? (t = No(_o), t.anchor = w ? w.previousSibling : e.lastChild) : t = 3 === n.nodeType ? Do("") : No("div"), t.el = n, o.component.subTree = t
                    }
                } else 64 & k ? w = 8 !== x ? g() : o.type.hydrate(n, o, i, r, a, v, e, d) : 128 & k && (w = o.type.hydrate(n, o, i, r, lo(l(n)), a, v, e, c))
        }
        return null != b && oo(b, null, r, o), w
    }, u = (e, t, n, s, l, r) => {
        r = r || !!t.dynamicChildren;
        const {
            type: a,
            props: c,
            patchFlag: u,
            shapeFlag: p,
            dirs: f
        } = t, h = "input" === a && f || "option" === a;
        if (h || -1 !== u) {
            if (f && Xn(t, null, n, "created"), c)
                if (h || !r || 48 & u)
                    for (const t in c)(h && t.endsWith("value") || g(t) && !O(t)) && o(e, t, null, c[t], !1, void 0, n);
                else c.onClick && o(e, "onClick", null, c.onClick, !1, void 0, n);
            let a;
            if ((a = c && c.onVnodeBeforeMount) && Zo(a, n, t), f && Xn(t, null, n, "beforeMount"), ((a = c && c.onVnodeMounted) || f) && an((() => {
                    a && Zo(a, n, t), f && Xn(t, null, n, "mounted")
                }), s), 16 & p && (!c || !c.innerHTML && !c.textContent)) {
                let o = d(e.firstChild, t, e, n, s, l, r);
                for (; o;) {
                    so = !0;
                    const e = o;
                    o = o.nextSibling, i(e)
                }
            } else 8 & p && e.textContent !== t.children && (so = !0, e.textContent = t.children)
        }
        return e.nextSibling
    }, d = (e, t, o, s, l, i, r) => {
        r = r || !!t.dynamicChildren;
        const a = t.children,
            u = a.length;
        for (let d = 0; d < u; d++) {
            const t = r ? a[d] : a[d] = qo(a[d]);
            if (e) e = c(e, t, s, l, i, r);
            else {
                if (t.type === Co && !t.children) continue;
                so = !0, n(null, t, o, null, s, l, lo(o), i)
            }
        }
        return e
    }, p = (e, t, n, o, i, c) => {
        const {
            slotScopeIds: u
        } = t;
        u && (i = i ? i.concat(u) : u);
        const p = l(e),
            f = d(s(e), t, p, n, o, i, c);
        return f && io(f) && "]" === f.data ? s(t.anchor = f) : (so = !0, r(t.anchor = a("]"), p, f), f)
    }, f = (e, t, o, r, a, c) => {
        if (so = !0, t.el = null, c) {
            const t = h(e);
            for (;;) {
                const n = s(e);
                if (!n || n === t) break;
                i(n)
            }
        }
        const u = s(e),
            d = l(e);
        return i(e), n(null, t, d, u, o, r, lo(d), a), u
    }, h = e => {
        let t = 0;
        for (; e;)
            if ((e = s(e)) && io(e) && ("[" === e.data && t++, "]" === e.data)) {
                if (0 === t) return s(e);
                t--
            } return e
    };
    return [(e, t) => {
        if (!t.hasChildNodes()) return n(null, e, t), void Wt();
        so = !1, c(t.firstChild, e, null, null, null), Wt(), so && console.error("Hydration completed but contains mismatches.")
    }, c]
}
const ao = an;

function co(e) {
    return function (e, t) {
        (K || (K = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof global ? global : {})).__VUE__ = !0;
        const {
            insert: n,
            remove: o,
            patchProp: s,
            createElement: l,
            createText: i,
            createComment: r,
            setText: a,
            setElementText: c,
            parentNode: u,
            nextSibling: d,
            setScopeId: v = h,
            cloneNode: m,
            insertStaticContent: g
        } = e, y = (e, t, n, o = null, s = null, l = null, i = !1, r = null, a = !!t.dynamicChildren) => {
            if (e === t) return;
            e && !Oo(e, t) && (o = ne(e), J(e, s, l, !0), e = null), -2 === t.patchFlag && (a = !1, t.dynamicChildren = null);
            const {
                type: c,
                ref: u,
                shapeFlag: d
            } = t;
            switch (c) {
                case Co:
                    k(e, t, n, o);
                    break;
                case So:
                    x(e, t, n, o);
                    break;
                case Mo:
                    null == e && _(t, n, o, i);
                    break;
                case _o:
                    $(e, t, n, o, s, l, i, r, a);
                    break;
                default:
                    1 & d ? M(e, t, n, o, s, l, i, r, a) : 6 & d ? B(e, t, n, o, s, l, i, r, a) : (64 & d || 128 & d) && c.process(e, t, n, o, s, l, i, r, a, se)
            }
            null != u && s && oo(u, e && e.ref, l, t || e, !t)
        }, k = (e, t, o, s) => {
            if (null == e) n(t.el = i(t.children), o, s);
            else {
                const n = t.el = e.el;
                t.children !== e.children && a(n, t.children)
            }
        }, x = (e, t, o, s) => {
            null == e ? n(t.el = r(t.children || ""), o, s) : t.el = e.el
        }, _ = (e, t, n, o) => {
            [e.el, e.anchor] = g(e.children, t, n, o, e.el, e.anchor)
        }, C = ({
            el: e,
            anchor: t
        }, o, s) => {
            let l;
            for (; e && e !== t;) l = d(e), n(e, o, s), e = l;
            n(t, o, s)
        }, S = ({
            el: e,
            anchor: t
        }) => {
            let n;
            for (; e && e !== t;) n = d(e), o(e), e = n;
            o(t)
        }, M = (e, t, n, o, s, l, i, r, a) => {
            i = i || "svg" === t.type, null == e ? A(t, n, o, s, l, i, r, a) : P(e, t, s, l, i, r, a)
        }, A = (e, t, o, i, r, a, u, d) => {
            let p, f;
            const {
                type: h,
                props: v,
                shapeFlag: g,
                transition: y,
                patchFlag: b,
                dirs: k
            } = e;
            if (e.el && void 0 !== m && -1 === b) p = e.el = m(e.el);
            else {
                if (p = e.el = l(e.type, a, v && v.is, v), 8 & g ? c(p, e.children) : 16 & g && E(e.children, p, null, i, r, a && "foreignObject" !== h, u, d), k && Xn(e, null, i, "created"), v) {
                    for (const t in v) "value" === t || O(t) || s(p, t, null, v[t], a, e.children, i, r, te);
                    "value" in v && s(p, "value", null, v.value), (f = v.onVnodeBeforeMount) && Zo(f, i, e)
                }
                L(p, e, e.scopeId, u, i)
            }
            k && Xn(e, null, i, "beforeMount");
            const x = (!r || r && !r.pendingBranch) && y && !y.persisted;
            x && y.beforeEnter(p), n(p, t, o), ((f = v && v.onVnodeMounted) || x || k) && ao((() => {
                f && Zo(f, i, e), x && y.enter(p), k && Xn(e, null, i, "mounted")
            }), r)
        }, L = (e, t, n, o, s) => {
            if (n && v(e, n), o)
                for (let l = 0; l < o.length; l++) v(e, o[l]);
            if (s) {
                if (t === s.subTree) {
                    const t = s.vnode;
                    L(e, t, t.scopeId, t.slotScopeIds, s.parent)
                }
            }
        }, E = (e, t, n, o, s, l, i, r, a = 0) => {
            for (let c = a; c < e.length; c++) {
                const a = e[c] = r ? Go(e[c]) : qo(e[c]);
                y(null, a, t, n, o, s, l, i, r)
            }
        }, P = (e, t, n, o, l, i, r) => {
            const a = t.el = e.el;
            let {
                patchFlag: u,
                dynamicChildren: d,
                dirs: f
            } = t;
            u |= 16 & e.patchFlag;
            const h = e.props || p,
                v = t.props || p;
            let m;
            n && uo(n, !1), (m = v.onVnodeBeforeUpdate) && Zo(m, n, t, e), f && Xn(t, e, n, "beforeUpdate"), n && uo(n, !0);
            const g = l && "foreignObject" !== t.type;
            if (d ? V(e.dynamicChildren, d, a, n, o, g, i) : r || D(e, t, a, null, n, o, g, i, !1), u > 0) {
                if (16 & u) I(a, t, h, v, n, o, l);
                else if (2 & u && h.class !== v.class && s(a, "class", null, v.class, l), 4 & u && s(a, "style", h.style, v.style, l), 8 & u) {
                    const i = t.dynamicProps;
                    for (let t = 0; t < i.length; t++) {
                        const r = i[t],
                            c = h[r],
                            u = v[r];
                        u === c && "value" !== r || s(a, r, c, u, l, e.children, n, o, te)
                    }
                }
                1 & u && e.children !== t.children && c(a, t.children)
            } else r || null != d || I(a, t, h, v, n, o, l);
            ((m = v.onVnodeUpdated) || f) && ao((() => {
                m && Zo(m, n, t, e), f && Xn(t, e, n, "updated")
            }), o)
        }, V = (e, t, n, o, s, l, i) => {
            for (let r = 0; r < t.length; r++) {
                const a = e[r],
                    c = t[r],
                    d = a.el && (a.type === _o || !Oo(a, c) || 70 & a.shapeFlag) ? u(a.el) : n;
                y(a, c, d, null, o, s, l, i, !0)
            }
        }, I = (e, t, n, o, l, i, r) => {
            if (n !== o) {
                for (const a in o) {
                    if (O(a)) continue;
                    const c = o[a],
                        u = n[a];
                    c !== u && "value" !== a && s(e, a, u, c, r, t.children, l, i, te)
                }
                if (n !== p)
                    for (const a in n) O(a) || a in o || s(e, a, n[a], null, r, t.children, l, i, te);
                "value" in o && s(e, "value", n.value, o.value)
            }
        }, $ = (e, t, o, s, l, r, a, c, u) => {
            const d = t.el = e ? e.el : i(""),
                p = t.anchor = e ? e.anchor : i("");
            let {
                patchFlag: f,
                dynamicChildren: h,
                slotScopeIds: v
            } = t;
            v && (c = c ? c.concat(v) : v), null == e ? (n(d, o, s), n(p, o, s), E(t.children, o, p, l, r, a, c, u)) : f > 0 && 64 & f && h && e.dynamicChildren ? (V(e.dynamicChildren, h, o, l, r, a, c), (null != t.key || l && t === l.subTree) && po(e, t, !0)) : D(e, t, o, p, l, r, a, c, u)
        }, B = (e, t, n, o, s, l, i, r, a) => {
            t.slotScopeIds = r, null == e ? 512 & t.shapeFlag ? s.ctx.activate(t, n, o, i, a) : j(t, n, o, s, l, i, a) : F(e, t, a)
        }, j = (e, t, n, o, s, l, i) => {
            const r = e.component = function (e, t, n) {
                const o = e.type,
                    s = (t ? t.appContext : e.appContext) || ns,
                    l = {
                        uid: os++,
                        vnode: e,
                        type: o,
                        parent: t,
                        appContext: s,
                        root: null,
                        next: null,
                        subTree: null,
                        effect: null,
                        update: null,
                        scope: new Y(!0),
                        render: null,
                        proxy: null,
                        exposed: null,
                        exposeProxy: null,
                        withProxy: null,
                        provides: t ? t.provides : Object.create(s.provides),
                        accessCache: null,
                        renderCache: [],
                        components: null,
                        directives: null,
                        propsOptions: Hn(o, s),
                        emitsOptions: Zt(o, s),
                        emit: null,
                        emitted: null,
                        propsDefaults: p,
                        inheritAttrs: o.inheritAttrs,
                        ctx: p,
                        data: p,
                        props: p,
                        attrs: p,
                        slots: p,
                        refs: p,
                        setupState: p,
                        setupContext: null,
                        suspense: n,
                        suspenseId: n ? n.pendingId : 0,
                        asyncDep: null,
                        asyncResolved: !1,
                        isMounted: !1,
                        isUnmounted: !1,
                        isDeactivated: !1,
                        bc: null,
                        c: null,
                        bm: null,
                        m: null,
                        bu: null,
                        u: null,
                        um: null,
                        bum: null,
                        da: null,
                        a: null,
                        rtg: null,
                        rtc: null,
                        ec: null,
                        sp: null
                    };
                l.ctx = {
                    _: l
                }, l.root = t ? t.root : l, l.emit = Kt.bind(null, l), e.ce && e.ce(l);
                return l
            }(e, o, s);
            if (En(e) && (r.ctx.renderer = se), function (e, t = !1) {
                    cs = t;
                    const {
                        props: n,
                        children: o
                    } = e.vnode, s = as(e);
                    zn(e, n, s, t), ((e, t) => {
                        if (32 & e.vnode.shapeFlag) {
                            const n = t._;
                            n ? (e.slots = rt(t), q(t, "_", n)) : Yn(t, e.slots = {})
                        } else e.slots = {}, t && Jn(e, t);
                        q(e.slots, jo, 1)
                    })(e, o);
                    const l = s ? function (e, t) {
                        const n = e.type;
                        e.accessCache = Object.create(null), e.proxy = at(new Proxy(e.ctx, ts));
                        const {
                            setup: o
                        } = n;
                        if (o) {
                            const n = e.setupContext = o.length > 1 ? function (e) {
                                const t = t => {
                                    e.exposed = t || {}
                                };
                                let n;
                                return {
                                    get attrs() {
                                        return n || (n = function (e) {
                                            return new Proxy(e.attrs, {
                                                get: (t, n) => (pe(e, 0, "$attrs"), t[n])
                                            })
                                        }(e))
                                    },
                                    slots: e.slots,
                                    emit: e.emit,
                                    expose: t
                                }
                            }(e) : null;
                            is(e), ue();
                            const s = Ct(o, e, 0, [e.props, n]);
                            if (de(), rs(), T(s)) {
                                if (s.then(rs, rs), t) return s.then((n => {
                                    us(e, n, t)
                                })).catch((t => {
                                    Mt(t, e, 0)
                                }));
                                e.asyncDep = s
                            } else us(e, s, t)
                        } else ds(e, t)
                    }(e, t) : void 0;
                    cs = !1
                }(r), r.asyncDep) {
                if (s && s.registerDep(r, R), !e.el) {
                    const e = r.subTree = No(So);
                    x(null, e, t, n)
                }
            } else R(r, e, t, n, s, l, i)
        }, F = (e, t, n) => {
            const o = t.component = e.component;
            if (function (e, t, n) {
                    const {
                        props: o,
                        children: s,
                        component: l
                    } = e, {
                        props: i,
                        children: r,
                        patchFlag: a
                    } = t, c = l.emitsOptions;
                    if (t.dirs || t.transition) return !0;
                    if (!(n && a >= 0)) return !(!s && !r || r && r.$stable) || o !== i && (o ? !i || rn(o, i, c) : !!i);
                    if (1024 & a) return !0;
                    if (16 & a) return o ? rn(o, i, c) : !!i;
                    if (8 & a) {
                        const e = t.dynamicProps;
                        for (let t = 0; t < e.length; t++) {
                            const n = e[t];
                            if (i[n] !== o[n] && !Yt(c, n)) return !0
                        }
                    }
                    return !1
                }(e, t, n)) {
                if (o.asyncDep && !o.asyncResolved) return void H(o, t, n);
                o.next = t,
                    function (e) {
                        const t = Et.indexOf(e);
                        t > Pt && Et.splice(t, 1)
                    }(o.update), o.update()
            } else t.component = e.component, t.el = e.el, o.vnode = t
        }, R = (e, t, n, o, s, l, i) => {
            const r = () => {
                    if (e.isMounted) {
                        let t, {
                                next: n,
                                bu: o,
                                u: r,
                                parent: a,
                                vnode: c
                            } = e,
                            d = n;
                        uo(e, !1), n ? (n.el = c.el, H(e, n, i)) : n = c, o && W(o), (t = n.props && n.props.onVnodeBeforeUpdate) && Zo(t, a, n, c), uo(e, !0);
                        const p = on(e),
                            f = e.subTree;
                        e.subTree = p, y(f, p, u(f.el), ne(f), e, s, l), n.el = p.el, null === d && function ({
                            vnode: e,
                            parent: t
                        }, n) {
                            for (; t && t.subTree === e;)(e = t.vnode).el = n, t = t.parent
                        }(e, p.el), r && ao(r, s), (t = n.props && n.props.onVnodeUpdated) && ao((() => Zo(t, a, n, c)), s)
                    } else {
                        let i;
                        const {
                            el: r,
                            props: a
                        } = t, {
                            bm: c,
                            m: u,
                            parent: d
                        } = e, p = Mn(t);
                        if (uo(e, !1), c && W(c), !p && (i = a && a.onVnodeBeforeMount) && Zo(i, d, t), uo(e, !0), r && re) {
                            const n = () => {
                                e.subTree = on(e), re(r, e.subTree, e, s, null)
                            };
                            p ? t.type.__asyncLoader().then((() => !e.isUnmounted && n())) : n()
                        } else {
                            const i = e.subTree = on(e);
                            y(null, i, n, o, e, s, l), t.el = i.el
                        }
                        if (u && ao(u, s), !p && (i = a && a.onVnodeMounted)) {
                            const e = t;
                            ao((() => Zo(i, d, e)), s)
                        }
                        256 & t.shapeFlag && e.a && ao(e.a, s), e.isMounted = !0, t = n = o = null
                    }
                },
                a = e.effect = new ie(r, (() => Nt(e.update)), e.scope),
                c = e.update = a.run.bind(a);
            c.id = e.uid, uo(e, !0), c()
        }, H = (e, t, n) => {
            t.component = e;
            const o = e.vnode.props;
            e.vnode = t, e.next = null,
                function (e, t, n, o) {
                    const {
                        props: s,
                        attrs: l,
                        vnode: {
                            patchFlag: i
                        }
                    } = e, r = rt(s), [a] = e.propsOptions;
                    let c = !1;
                    if (!(o || i > 0) || 16 & i) {
                        let o;
                        Rn(e, t, s, l) && (c = !0);
                        for (const l in r) t && (w(t, l) || (o = N(l)) !== l && w(t, o)) || (a ? !n || void 0 === n[l] && void 0 === n[o] || (s[l] = Nn(a, r, l, void 0, e, !0)) : delete s[l]);
                        if (l !== r)
                            for (const e in l) t && w(t, e) || (delete l[e], c = !0)
                    } else if (8 & i) {
                        const n = e.vnode.dynamicProps;
                        for (let o = 0; o < n.length; o++) {
                            let i = n[o];
                            const u = t[i];
                            if (a)
                                if (w(l, i)) u !== l[i] && (l[i] = u, c = !0);
                                else {
                                    const t = z(i);
                                    s[t] = Nn(a, r, t, u, e, !1)
                                }
                            else u !== l[i] && (l[i] = u, c = !0)
                        }
                    }
                    c && he(e, "set", "$attrs")
                }(e, t.props, o, n), ((e, t, n) => {
                    const {
                        vnode: o,
                        slots: s
                    } = e;
                    let l = !0,
                        i = p;
                    if (32 & o.shapeFlag) {
                        const e = t._;
                        e ? n && 1 === e ? l = !1 : (b(s, t), n || 1 !== e || delete s._) : (l = !t.$stable, Yn(t, s)), i = t
                    } else t && (Jn(e, t), i = {
                        default: 1
                    });
                    if (l)
                        for (const r in s) Gn(r) || r in i || delete s[r]
                })(e, t.children, n), ue(), Ut(void 0, e.update), de()
        }, D = (e, t, n, o, s, l, i, r, a = !1) => {
            const u = e && e.children,
                d = e ? e.shapeFlag : 0,
                p = t.children,
                {
                    patchFlag: f,
                    shapeFlag: h
                } = t;
            if (f > 0) {
                if (128 & f) return void G(u, p, n, o, s, l, i, r, a);
                if (256 & f) return void U(u, p, n, o, s, l, i, r, a)
            }
            8 & h ? (16 & d && te(u, s, l), p !== u && c(n, p)) : 16 & d ? 16 & h ? G(u, p, n, o, s, l, i, r, a) : te(u, s, l, !0) : (8 & d && c(n, ""), 16 & h && E(p, n, o, s, l, i, r, a))
        }, U = (e, t, n, o, s, l, i, r, a) => {
            t = t || f;
            const c = (e = e || f).length,
                u = t.length,
                d = Math.min(c, u);
            let p;
            for (p = 0; p < d; p++) {
                const o = t[p] = a ? Go(t[p]) : qo(t[p]);
                y(e[p], o, n, null, s, l, i, r, a)
            }
            c > u ? te(e, s, l, !0, !1, d) : E(t, n, o, s, l, i, r, a, d)
        }, G = (e, t, n, o, s, l, i, r, a) => {
            let c = 0;
            const u = t.length;
            let d = e.length - 1,
                p = u - 1;
            for (; c <= d && c <= p;) {
                const o = e[c],
                    u = t[c] = a ? Go(t[c]) : qo(t[c]);
                if (!Oo(o, u)) break;
                y(o, u, n, null, s, l, i, r, a), c++
            }
            for (; c <= d && c <= p;) {
                const o = e[d],
                    c = t[p] = a ? Go(t[p]) : qo(t[p]);
                if (!Oo(o, c)) break;
                y(o, c, n, null, s, l, i, r, a), d--, p--
            }
            if (c > d) {
                if (c <= p) {
                    const e = p + 1,
                        d = e < u ? t[e].el : o;
                    for (; c <= p;) y(null, t[c] = a ? Go(t[c]) : qo(t[c]), n, d, s, l, i, r, a), c++
                }
            } else if (c > p)
                for (; c <= d;) J(e[c], s, l, !0), c++;
            else {
                const h = c,
                    v = c,
                    m = new Map;
                for (c = v; c <= p; c++) {
                    const e = t[c] = a ? Go(t[c]) : qo(t[c]);
                    null != e.key && m.set(e.key, c)
                }
                let g, b = 0;
                const k = p - v + 1;
                let x = !1,
                    w = 0;
                const _ = new Array(k);
                for (c = 0; c < k; c++) _[c] = 0;
                for (c = h; c <= d; c++) {
                    const o = e[c];
                    if (b >= k) {
                        J(o, s, l, !0);
                        continue
                    }
                    let u;
                    if (null != o.key) u = m.get(o.key);
                    else
                        for (g = v; g <= p; g++)
                            if (0 === _[g - v] && Oo(o, t[g])) {
                                u = g;
                                break
                            } void 0 === u ? J(o, s, l, !0) : (_[u - v] = c + 1, u >= w ? w = u : x = !0, y(o, t[u], n, null, s, l, i, r, a), b++)
                }
                const C = x ? function (e) {
                    const t = e.slice(),
                        n = [0];
                    let o, s, l, i, r;
                    const a = e.length;
                    for (o = 0; o < a; o++) {
                        const a = e[o];
                        if (0 !== a) {
                            if (s = n[n.length - 1], e[s] < a) {
                                t[o] = s, n.push(o);
                                continue
                            }
                            for (l = 0, i = n.length - 1; l < i;) r = l + i >> 1, e[n[r]] < a ? l = r + 1 : i = r;
                            a < e[n[l]] && (l > 0 && (t[o] = n[l - 1]), n[l] = o)
                        }
                    }
                    l = n.length, i = n[l - 1];
                    for (; l-- > 0;) n[l] = i, i = t[i];
                    return n
                }(_) : f;
                for (g = C.length - 1, c = k - 1; c >= 0; c--) {
                    const e = v + c,
                        d = t[e],
                        p = e + 1 < u ? t[e + 1].el : o;
                    0 === _[c] ? y(null, d, n, p, s, l, i, r, a) : x && (g < 0 || c !== C[g] ? Z(d, n, p, 2) : g--)
                }
            }
        }, Z = (e, t, o, s, l = null) => {
            const {
                el: i,
                type: r,
                transition: a,
                children: c,
                shapeFlag: u
            } = e;
            if (6 & u) return void Z(e.component.subTree, t, o, s);
            if (128 & u) return void e.suspense.move(t, o, s);
            if (64 & u) return void r.move(e, t, o, se);
            if (r === _o) {
                n(i, t, o);
                for (let e = 0; e < c.length; e++) Z(c[e], t, o, s);
                return void n(e.anchor, t, o)
            }
            if (r === Mo) return void C(e, t, o);
            if (2 !== s && 1 & u && a)
                if (0 === s) a.beforeEnter(i), n(i, t, o), ao((() => a.enter(i)), l);
                else {
                    const {
                        leave: e,
                        delayLeave: s,
                        afterLeave: l
                    } = a, r = () => n(i, t, o), c = () => {
                        e(i, (() => {
                            r(), l && l()
                        }))
                    };
                    s ? s(i, r, c) : c()
                }
            else n(i, t, o)
        }, J = (e, t, n, o = !1, s = !1) => {
            const {
                type: l,
                props: i,
                ref: r,
                children: a,
                dynamicChildren: c,
                shapeFlag: u,
                patchFlag: d,
                dirs: p
            } = e;
            if (null != r && oo(r, null, n, e, !0), 256 & u) return void t.ctx.deactivate(e);
            const f = 1 & u && p,
                h = !Mn(e);
            let v;
            if (h && (v = i && i.onVnodeBeforeUnmount) && Zo(v, t, e), 6 & u) ee(e.component, n, o);
            else {
                if (128 & u) return void e.suspense.unmount(n, o);
                f && Xn(e, null, t, "beforeUnmount"), 64 & u ? e.type.remove(e, t, n, s, se, o) : c && (l !== _o || d > 0 && 64 & d) ? te(c, t, n, !1, !0) : (l === _o && 384 & d || !s && 16 & u) && te(a, t, n), o && Q(e)
            }(h && (v = i && i.onVnodeUnmounted) || f) && ao((() => {
                v && Zo(v, t, e), f && Xn(e, null, t, "unmounted")
            }), n)
        }, Q = e => {
            const {
                type: t,
                el: n,
                anchor: s,
                transition: l
            } = e;
            if (t === _o) return void X(n, s);
            if (t === Mo) return void S(e);
            const i = () => {
                o(n), l && !l.persisted && l.afterLeave && l.afterLeave()
            };
            if (1 & e.shapeFlag && l && !l.persisted) {
                const {
                    leave: t,
                    delayLeave: o
                } = l, s = () => t(n, i);
                o ? o(e.el, i, s) : s()
            } else i()
        }, X = (e, t) => {
            let n;
            for (; e !== t;) n = d(e), o(e), e = n;
            o(t)
        }, ee = (e, t, n) => {
            const {
                bum: o,
                scope: s,
                update: l,
                subTree: i,
                um: r
            } = e;
            o && W(o), s.stop(), l && (l.active = !1, J(i, e, t, n)), r && ao(r, t), ao((() => {
                e.isUnmounted = !0
            }), t), t && t.pendingBranch && !t.isUnmounted && e.asyncDep && !e.asyncResolved && e.suspenseId === t.pendingId && (t.deps--, 0 === t.deps && t.resolve())
        }, te = (e, t, n, o = !1, s = !1, l = 0) => {
            for (let i = l; i < e.length; i++) J(e[i], t, n, o, s)
        }, ne = e => 6 & e.shapeFlag ? ne(e.component.subTree) : 128 & e.shapeFlag ? e.suspense.next() : d(e.anchor || e.el), oe = (e, t, n) => {
            null == e ? t._vnode && J(t._vnode, null, null, !0) : y(t._vnode || null, e, t, null, null, null, n), Wt(), t._vnode = e
        }, se = {
            p: y,
            um: J,
            m: Z,
            r: Q,
            mt: j,
            mc: E,
            pc: D,
            pbc: V,
            n: ne,
            o: e
        };
        let le, re;
        t && ([le, re] = t(se));
        return {
            render: oe,
            hydrate: le,
            createApp: no(oe, le)
        }
    }(e, ro)
}

function uo({
    effect: e,
    update: t
}, n) {
    e.allowRecurse = t.allowRecurse = n
}

function po(e, t, n = !1) {
    const o = e.children,
        s = t.children;
    if (_(o) && _(s))
        for (let l = 0; l < o.length; l++) {
            const e = o[l];
            let t = s[l];
            1 & t.shapeFlag && !t.dynamicChildren && ((t.patchFlag <= 0 || 32 === t.patchFlag) && (t = s[l] = Go(s[l]), t.el = e.el), n || po(e, t))
        }
}
const fo = e => e && (e.disabled || "" === e.disabled),
    ho = e => "undefined" != typeof SVGElement && e instanceof SVGElement,
    vo = (e, t) => {
        const n = e && e.to;
        if (L(n)) {
            if (t) {
                return t(n)
            }
            return null
        }
        return n
    };

function mo(e, t, n, {
    o: {
        insert: o
    },
    m: s
}, l = 2) {
    0 === l && o(e.targetAnchor, t, n);
    const {
        el: i,
        anchor: r,
        shapeFlag: a,
        children: c,
        props: u
    } = e, d = 2 === l;
    if (d && o(i, t, n), (!d || fo(u)) && 16 & a)
        for (let p = 0; p < c.length; p++) s(c[p], t, n, 2);
    d && o(r, t, n)
}
const go = {
    __isTeleport: !0,
    process(e, t, n, o, s, l, i, r, a, c) {
        const {
            mc: u,
            pc: d,
            pbc: p,
            o: {
                insert: f,
                querySelector: h,
                createText: v,
                createComment: m
            }
        } = c, g = fo(t.props);
        let {
            shapeFlag: y,
            children: b,
            dynamicChildren: k
        } = t;
        if (null == e) {
            const e = t.el = v(""),
                c = t.anchor = v("");
            f(e, n, o), f(c, n, o);
            const d = t.target = vo(t.props, h),
                p = t.targetAnchor = v("");
            d && (f(p, d), i = i || ho(d));
            const m = (e, t) => {
                16 & y && u(b, e, t, s, l, i, r, a)
            };
            g ? m(n, c) : d && m(d, p)
        } else {
            t.el = e.el;
            const o = t.anchor = e.anchor,
                u = t.target = e.target,
                f = t.targetAnchor = e.targetAnchor,
                v = fo(e.props),
                m = v ? n : u,
                y = v ? o : f;
            if (i = i || ho(u), k ? (p(e.dynamicChildren, k, m, s, l, i, r), po(e, t, !0)) : a || d(e, t, m, y, s, l, i, r, !1), g) v || mo(t, n, o, c, 1);
            else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
                const e = t.target = vo(t.props, h);
                e && mo(t, e, null, c, 0)
            } else v && mo(t, u, f, c, 1)
        }
    },
    remove(e, t, n, o, {
        um: s,
        o: {
            remove: l
        }
    }, i) {
        const {
            shapeFlag: r,
            children: a,
            anchor: c,
            targetAnchor: u,
            target: d,
            props: p
        } = e;
        if (d && l(u), (i || !fo(p)) && (l(c), 16 & r))
            for (let f = 0; f < a.length; f++) {
                const e = a[f];
                s(e, t, n, !0, !!e.dynamicChildren)
            }
    },
    move: mo,
    hydrate: function (e, t, n, o, s, l, {
        o: {
            nextSibling: i,
            parentNode: r,
            querySelector: a
        }
    }, c) {
        const u = t.target = vo(t.props, a);
        if (u) {
            const a = u._lpa || u.firstChild;
            16 & t.shapeFlag && (fo(t.props) ? (t.anchor = c(i(e), t, r(e), n, o, s, l), t.targetAnchor = a) : (t.anchor = i(e), t.targetAnchor = c(a, t, u, n, o, s, l)), u._lpa = t.targetAnchor && i(t.targetAnchor))
        }
        return t.anchor && i(t.anchor)
    }
};

function yo(e, t) {
    return xo("components", e, !0, t) || e
}
const bo = Symbol();

function ko(e) {
    return L(e) ? xo("components", e, !1) || e : e || bo
}

function xo(e, t, n = !0, o = !1) {
    const s = Jt || ss;
    if (s) {
        const n = s.type;
        if ("components" === e) {
            const e = fs(n);
            if (e && (e === t || e === z(t) || e === H(z(t)))) return n
        }
        const l = wo(s[e] || n[e], t) || wo(s.appContext[e], t);
        return !l && o ? n : l
    }
}

function wo(e, t) {
    return e && (e[t] || e[z(t)] || e[H(z(t))])
}
const _o = Symbol(void 0),
    Co = Symbol(void 0),
    So = Symbol(void 0),
    Mo = Symbol(void 0),
    Ao = [];
let Lo = null;

function Eo(e = !1) {
    Ao.push(Lo = e ? null : [])
}
let Po = 1;

function To(e) {
    Po += e
}

function Vo(e) {
    return e.dynamicChildren = Po > 0 ? Lo || f : null, Ao.pop(), Lo = Ao[Ao.length - 1] || null, Po > 0 && Lo && Lo.push(e), e
}

function Io(e, t, n, o, s, l) {
    return Vo(Ro(e, t, n, o, s, l, !0))
}

function $o(e, t, n, o, s) {
    return Vo(No(e, t, n, o, s, !0))
}

function Bo(e) {
    return !!e && !0 === e.__v_isVNode
}

function Oo(e, t) {
    return e.type === t.type && e.key === t.key
}
const jo = "__vInternal",
    Fo = ({
        key: e
    }) => null != e ? e : null,
    zo = ({
        ref: e,
        ref_key: t,
        ref_for: n
    }) => null != e ? L(e) || ft(e) || A(e) ? {
        i: Jt,
        r: e,
        k: t,
        f: !!n
    } : e : null;

function Ro(e, t = null, n = null, o = 0, s = null, l = (e === _o ? 0 : 1), i = !1, r = !1) {
    const a = {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e,
        props: t,
        key: t && Fo(t),
        ref: t && zo(t),
        scopeId: Qt,
        slotScopeIds: null,
        children: n,
        component: null,
        suspense: null,
        ssContent: null,
        ssFallback: null,
        dirs: null,
        transition: null,
        el: null,
        anchor: null,
        target: null,
        targetAnchor: null,
        staticCount: 0,
        shapeFlag: l,
        patchFlag: o,
        dynamicProps: s,
        dynamicChildren: null,
        appContext: null
    };
    return r ? (Ko(a, n), 128 & l && e.normalize(a)) : n && (a.shapeFlag |= L(n) ? 8 : 16), Po > 0 && !i && Lo && (a.patchFlag > 0 || 6 & l) && 32 !== a.patchFlag && Lo.push(a), a
}
const No = function (e, t = null, n = null, s = 0, l = null, i = !1) {
    e && e !== bo || (e = So);
    if (Bo(e)) {
        const o = Ho(e, t, !0);
        return n && Ko(o, n), o
    }
    a = e, A(a) && "__vccOpts" in a && (e = e.__vccOpts);
    var a;
    if (t) {
        t = function (e) {
            return e ? it(e) || jo in e ? b({}, e) : e : null
        }(t);
        let {
            class: e,
            style: n
        } = t;
        e && !L(e) && (t.class = r(e)), P(n) && (it(n) && !_(n) && (n = b({}, n)), t.style = o(n))
    }
    const c = L(e) ? 1 : (e => e.__isSuspense)(e) ? 128 : (e => e.__isTeleport)(e) ? 64 : P(e) ? 4 : A(e) ? 2 : 0;
    return Ro(e, t, n, s, l, c, i, !0)
};

function Ho(e, t, n = !1) {
    const {
        props: s,
        ref: l,
        patchFlag: i,
        children: a
    } = e, c = t ? function (...e) {
        const t = {};
        for (let n = 0; n < e.length; n++) {
            const s = e[n];
            for (const e in s)
                if ("class" === e) t.class !== s.class && (t.class = r([t.class, s.class]));
                else if ("style" === e) t.style = o([t.style, s.style]);
            else if (g(e)) {
                const n = t[e],
                    o = s[e];
                !o || n === o || _(n) && n.includes(o) || (t[e] = n ? [].concat(n, o) : o)
            } else "" !== e && (t[e] = s[e])
        }
        return t
    }(s || {}, t) : s;
    return {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e.type,
        props: c,
        key: c && Fo(c),
        ref: t && t.ref ? n && l ? _(l) ? l.concat(zo(t)) : [l, zo(t)] : zo(t) : l,
        scopeId: e.scopeId,
        slotScopeIds: e.slotScopeIds,
        children: a,
        target: e.target,
        targetAnchor: e.targetAnchor,
        staticCount: e.staticCount,
        shapeFlag: e.shapeFlag,
        patchFlag: t && e.type !== _o ? -1 === i ? 16 : 16 | i : i,
        dynamicProps: e.dynamicProps,
        dynamicChildren: e.dynamicChildren,
        appContext: e.appContext,
        dirs: e.dirs,
        transition: e.transition,
        component: e.component,
        suspense: e.suspense,
        ssContent: e.ssContent && Ho(e.ssContent),
        ssFallback: e.ssFallback && Ho(e.ssFallback),
        el: e.el,
        anchor: e.anchor
    }
}

function Do(e = " ", t = 0) {
    return No(Co, null, e, t)
}

function Uo(e, t) {
    const n = No(Mo, null, e);
    return n.staticCount = t, n
}

function Wo(e = "", t = !1) {
    return t ? (Eo(), $o(So, null, e)) : No(So, null, e)
}

function qo(e) {
    return null == e || "boolean" == typeof e ? No(So) : _(e) ? No(_o, null, e.slice()) : "object" == typeof e ? Go(e) : No(Co, null, String(e))
}

function Go(e) {
    return null === e.el || e.memo ? e : Ho(e)
}

function Ko(e, t) {
    let n = 0;
    const {
        shapeFlag: o
    } = e;
    if (null == t) t = null;
    else if (_(t)) n = 16;
    else if ("object" == typeof t) {
        if (65 & o) {
            const n = t.default;
            return void(n && (n._c && (n._d = !1), Ko(e, n()), n._c && (n._d = !0)))
        } {
            n = 32;
            const o = t._;
            o || jo in t ? 3 === o && Jt && (1 === Jt.slots._ ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024)) : t._ctx = Jt
        }
    } else A(t) ? (t = {
        default: t,
        _ctx: Jt
    }, n = 32) : (t = String(t), 64 & o ? (n = 16, t = [Do(t)]) : n = 8);
    e.children = t, e.shapeFlag |= n
}

function Zo(e, t, n, o = null) {
    St(e, t, 7, [n, o])
}

function Yo(e, t, n, o) {
    let s;
    const l = n && n[o];
    if (_(e) || L(e)) {
        s = new Array(e.length);
        for (let n = 0, o = e.length; n < o; n++) s[n] = t(e[n], n, void 0, l && l[n])
    } else if ("number" == typeof e) {
        s = new Array(e);
        for (let n = 0; n < e; n++) s[n] = t(n + 1, n, void 0, l && l[n])
    } else if (P(e))
        if (e[Symbol.iterator]) s = Array.from(e, ((e, n) => t(e, n, void 0, l && l[n])));
        else {
            const n = Object.keys(e);
            s = new Array(n.length);
            for (let o = 0, i = n.length; o < i; o++) {
                const i = n[o];
                s[o] = t(e[i], i, o, l && l[o])
            }
        }
    else s = [];
    return n && (n[o] = s), s
}

function Jo(e, t, n = {}, o, s) {
    if (Jt.isCE) return No("slot", "default" === t ? null : {
        name: t
    }, o && o());
    let l = e[t];
    l && l._c && (l._d = !1), Eo();
    const i = l && Qo(l(n)),
        r = $o(_o, {
            key: n.key || `_${t}`
        }, i || (o ? o() : []), i && 1 === e._ ? 64 : -2);
    return !s && r.scopeId && (r.slotScopeIds = [r.scopeId + "-s"]), l && l._c && (l._d = !0), r
}

function Qo(e) {
    return e.some((e => !Bo(e) || e.type !== So && !(e.type === _o && !Qo(e.children)))) ? e : null
}
const Xo = e => e ? as(e) ? ps(e) || e.proxy : Xo(e.parent) : null,
    es = b(Object.create(null), {
        $: e => e,
        $el: e => e.vnode.el,
        $data: e => e.data,
        $props: e => e.props,
        $attrs: e => e.attrs,
        $slots: e => e.slots,
        $refs: e => e.refs,
        $parent: e => Xo(e.parent),
        $root: e => Xo(e.root),
        $emit: e => e.emit,
        $options: e => e.type,
        $forceUpdate: e => () => Nt(e.update),
        $nextTick: e => Rt.bind(e.proxy),
        $watch: e => h
    }),
    ts = {
        get({
            _: e
        }, t) {
            const {
                ctx: n,
                setupState: o,
                data: s,
                props: l,
                accessCache: i,
                type: r,
                appContext: a
            } = e;
            let c;
            if ("$" !== t[0]) {
                const r = i[t];
                if (void 0 !== r) switch (r) {
                    case 1:
                        return o[t];
                    case 2:
                        return s[t];
                    case 4:
                        return n[t];
                    case 3:
                        return l[t]
                } else {
                    if (o !== p && w(o, t)) return i[t] = 1, o[t];
                    if (s !== p && w(s, t)) return i[t] = 2, s[t];
                    if ((c = e.propsOptions[0]) && w(c, t)) return i[t] = 3, l[t];
                    if (n !== p && w(n, t)) return i[t] = 4, n[t];
                    i[t] = 0
                }
            }
            const u = es[t];
            let d, f;
            return u ? ("$attrs" === t && pe(e, 0, t), u(e)) : (d = r.__cssModules) && (d = d[t]) ? d : n !== p && w(n, t) ? (i[t] = 4, n[t]) : (f = a.config.globalProperties, w(f, t) ? f[t] : void 0)
        },
        set({
            _: e
        }, t, n) {
            const {
                data: o,
                setupState: s,
                ctx: l
            } = e;
            return s !== p && w(s, t) ? (s[t] = n, !0) : o !== p && w(o, t) ? (o[t] = n, !0) : !w(e.props, t) && (("$" !== t[0] || !(t.slice(1) in e)) && (l[t] = n, !0))
        },
        has({
            _: {
                data: e,
                setupState: t,
                accessCache: n,
                ctx: o,
                appContext: s,
                propsOptions: l
            }
        }, i) {
            let r;
            return !!n[i] || e !== p && w(e, i) || t !== p && w(t, i) || (r = l[0]) && w(r, i) || w(o, i) || w(es, i) || w(s.config.globalProperties, i)
        },
        defineProperty(e, t, n) {
            return null != n.get ? this.set(e, t, n.get(), null) : null != n.value && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
        }
    },
    ns = eo();
let os = 0;
let ss = null;
const ls = () => ss || Jt,
    is = e => {
        ss = e, e.scope.on()
    },
    rs = () => {
        ss && ss.scope.off(), ss = null
    };

function as(e) {
    return 4 & e.vnode.shapeFlag
}
let cs = !1;

function us(e, t, n) {
    A(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : P(t) && (e.setupState = kt(t)), ds(e, n)
}

function ds(e, t, n) {
    const o = e.type;
    e.render || (e.render = o.render || h)
}

function ps(e) {
    if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy(kt(at(e.exposed)), {
        get: (t, n) => n in t ? t[n] : n in es ? es[n](e) : void 0
    }))
}

function fs(e) {
    return A(e) && e.displayName || e.name
}
const hs = (e, t) => function (e, t, n = !1) {
    let o, s;
    const l = A(e);
    return l ? (o = e, s = h) : (o = e.get, s = e.set), new _t(o, s, l || !s, n)
}(e, 0, cs);

function vs(e, t, n) {
    const o = arguments.length;
    return 2 === o ? P(t) && !_(t) ? Bo(t) ? No(e, null, [t]) : No(e, t) : No(e, null, t) : (o > 3 ? n = Array.prototype.slice.call(arguments, 2) : 3 === o && Bo(n) && (n = [n]), No(e, t, n))
}
const ms = "3.2.31",
    gs = "undefined" != typeof document ? document : null,
    ys = gs && gs.createElement("template"),
    bs = {
        insert: (e, t, n) => {
            t.insertBefore(e, n || null)
        },
        remove: e => {
            const t = e.parentNode;
            t && t.removeChild(e)
        },
        createElement: (e, t, n, o) => {
            const s = t ? gs.createElementNS("http://www.w3.org/2000/svg", e) : gs.createElement(e, n ? {
                is: n
            } : void 0);
            return "select" === e && o && null != o.multiple && s.setAttribute("multiple", o.multiple), s
        },
        createText: e => gs.createTextNode(e),
        createComment: e => gs.createComment(e),
        setText: (e, t) => {
            e.nodeValue = t
        },
        setElementText: (e, t) => {
            e.textContent = t
        },
        parentNode: e => e.parentNode,
        nextSibling: e => e.nextSibling,
        querySelector: e => gs.querySelector(e),
        setScopeId(e, t) {
            e.setAttribute(t, "")
        },
        cloneNode(e) {
            const t = e.cloneNode(!0);
            return "_value" in e && (t._value = e._value), t
        },
        insertStaticContent(e, t, n, o, s, l) {
            const i = n ? n.previousSibling : t.lastChild;
            if (s && (s === l || s.nextSibling))
                for (; t.insertBefore(s.cloneNode(!0), n), s !== l && (s = s.nextSibling););
            else {
                ys.innerHTML = o ? `<svg>${e}</svg>` : e;
                const s = ys.content;
                if (o) {
                    const e = s.firstChild;
                    for (; e.firstChild;) s.appendChild(e.firstChild);
                    s.removeChild(e)
                }
                t.insertBefore(s, n)
            }
            return [i ? i.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
        }
    };
const ks = /\s*!important$/;

function xs(e, t, n) {
    if (_(n)) n.forEach((n => xs(e, t, n)));
    else if (t.startsWith("--")) e.setProperty(t, n);
    else {
        const o = function (e, t) {
            const n = _s[t];
            if (n) return n;
            let o = z(t);
            if ("filter" !== o && o in e) return _s[t] = o;
            o = H(o);
            for (let s = 0; s < ws.length; s++) {
                const n = ws[s] + o;
                if (n in e) return _s[t] = n
            }
            return t
        }(e, t);
        ks.test(n) ? e.setProperty(N(o), n.replace(ks, ""), "important") : e[o] = n
    }
}
const ws = ["Webkit", "Moz", "ms"],
    _s = {};
const Cs = "http://www.w3.org/1999/xlink";
let Ss = Date.now,
    Ms = !1;
if ("undefined" != typeof window) {
    Ss() > document.createEvent("Event").timeStamp && (Ss = () => performance.now());
    const e = navigator.userAgent.match(/firefox\/(\d+)/i);
    Ms = !!(e && Number(e[1]) <= 53)
}
let As = 0;
const Ls = Promise.resolve(),
    Es = () => {
        As = 0
    };

function Ps(e, t, n, o) {
    e.addEventListener(t, n, o)
}

function Ts(e, t, n, o, s = null) {
    const l = e._vei || (e._vei = {}),
        i = l[t];
    if (o && i) i.value = o;
    else {
        const [n, r] = function (e) {
            let t;
            if (Vs.test(e)) {
                let n;
                for (t = {}; n = e.match(Vs);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0
            }
            return [N(e.slice(2)), t]
        }(t);
        if (o) {
            const i = l[t] = function (e, t) {
                const n = e => {
                    const o = e.timeStamp || Ss();
                    (Ms || o >= n.attached - 1) && St(function (e, t) {
                        if (_(t)) {
                            const n = e.stopImmediatePropagation;
                            return e.stopImmediatePropagation = () => {
                                n.call(e), e._stopped = !0
                            }, t.map((e => t => !t._stopped && e && e(t)))
                        }
                        return t
                    }(e, n.value), t, 5, [e])
                };
                return n.value = e, n.attached = (() => As || (Ls.then(Es), As = Ss()))(), n
            }(o, s);
            Ps(e, n, i, r)
        } else i && (! function (e, t, n, o) {
            e.removeEventListener(t, n, o)
        }(e, n, i, r), l[t] = void 0)
    }
}
const Vs = /(?:Once|Passive|Capture)$/;
const Is = /^on[a-z]/;
const $s = (e, {
    slots: t
}) => vs(yn, zs(e), t);
$s.displayName = "Transition";
const Bs = {
        name: String,
        type: String,
        css: {
            type: Boolean,
            default: !0
        },
        duration: [String, Number, Object],
        enterFromClass: String,
        enterActiveClass: String,
        enterToClass: String,
        appearFromClass: String,
        appearActiveClass: String,
        appearToClass: String,
        leaveFromClass: String,
        leaveActiveClass: String,
        leaveToClass: String
    },
    Os = $s.props = b({}, yn.props, Bs),
    js = (e, t = []) => {
        _(e) ? e.forEach((e => e(...t))) : e && e(...t)
    },
    Fs = e => !!e && (_(e) ? e.some((e => e.length > 1)) : e.length > 1);

function zs(e) {
    const t = {};
    for (const b in e) b in Bs || (t[b] = e[b]);
    if (!1 === e.css) return t;
    const {
        name: n = "v",
        type: o,
        duration: s,
        enterFromClass: l = `${n}-enter-from`,
        enterActiveClass: i = `${n}-enter-active`,
        enterToClass: r = `${n}-enter-to`,
        appearFromClass: a = l,
        appearActiveClass: c = i,
        appearToClass: u = r,
        leaveFromClass: d = `${n}-leave-from`,
        leaveActiveClass: p = `${n}-leave-active`,
        leaveToClass: f = `${n}-leave-to`
    } = e, h = function (e) {
        if (null == e) return null;
        if (P(e)) return [Rs(e.enter), Rs(e.leave)]; {
            const t = Rs(e);
            return [t, t]
        }
    }(s), v = h && h[0], m = h && h[1], {
        onBeforeEnter: g,
        onEnter: y,
        onEnterCancelled: k,
        onLeave: x,
        onLeaveCancelled: w,
        onBeforeAppear: _ = g,
        onAppear: C = y,
        onAppearCancelled: S = k
    } = t, M = (e, t, n) => {
        Hs(e, t ? u : r), Hs(e, t ? c : i), n && n()
    }, A = (e, t) => {
        Hs(e, f), Hs(e, p), t && t()
    }, L = e => (t, n) => {
        const s = e ? C : y,
            i = () => M(t, e, n);
        js(s, [t, i]), Ds((() => {
            Hs(t, e ? a : l), Ns(t, e ? u : r), Fs(s) || Ws(t, o, v, i)
        }))
    };
    return b(t, {
        onBeforeEnter(e) {
            js(g, [e]), Ns(e, l), Ns(e, i)
        },
        onBeforeAppear(e) {
            js(_, [e]), Ns(e, a), Ns(e, c)
        },
        onEnter: L(!1),
        onAppear: L(!0),
        onLeave(e, t) {
            const n = () => A(e, t);
            Ns(e, d), Zs(), Ns(e, p), Ds((() => {
                Hs(e, d), Ns(e, f), Fs(x) || Ws(e, o, m, n)
            })), js(x, [e, n])
        },
        onEnterCancelled(e) {
            M(e, !1), js(k, [e])
        },
        onAppearCancelled(e) {
            M(e, !0), js(S, [e])
        },
        onLeaveCancelled(e) {
            A(e), js(w, [e])
        }
    })
}

function Rs(e) {
    return G(e)
}

function Ns(e, t) {
    t.split(/\s+/).forEach((t => t && e.classList.add(t))), (e._vtc || (e._vtc = new Set)).add(t)
}

function Hs(e, t) {
    t.split(/\s+/).forEach((t => t && e.classList.remove(t)));
    const {
        _vtc: n
    } = e;
    n && (n.delete(t), n.size || (e._vtc = void 0))
}

function Ds(e) {
    requestAnimationFrame((() => {
        requestAnimationFrame(e)
    }))
}
let Us = 0;

function Ws(e, t, n, o) {
    const s = e._endId = ++Us,
        l = () => {
            s === e._endId && o()
        };
    if (n) return setTimeout(l, n);
    const {
        type: i,
        timeout: r,
        propCount: a
    } = qs(e, t);
    if (!i) return o();
    const c = i + "end";
    let u = 0;
    const d = () => {
            e.removeEventListener(c, p), l()
        },
        p = t => {
            t.target === e && ++u >= a && d()
        };
    setTimeout((() => {
        u < a && d()
    }), r + 1), e.addEventListener(c, p)
}

function qs(e, t) {
    const n = window.getComputedStyle(e),
        o = e => (n[e] || "").split(", "),
        s = o("transitionDelay"),
        l = o("transitionDuration"),
        i = Gs(s, l),
        r = o("animationDelay"),
        a = o("animationDuration"),
        c = Gs(r, a);
    let u = null,
        d = 0,
        p = 0;
    "transition" === t ? i > 0 && (u = "transition", d = i, p = l.length) : "animation" === t ? c > 0 && (u = "animation", d = c, p = a.length) : (d = Math.max(i, c), u = d > 0 ? i > c ? "transition" : "animation" : null, p = u ? "transition" === u ? l.length : a.length : 0);
    return {
        type: u,
        timeout: d,
        propCount: p,
        hasTransform: "transition" === u && /\b(transform|all)(,|$)/.test(n.transitionProperty)
    }
}

function Gs(e, t) {
    for (; e.length < t.length;) e = e.concat(e);
    return Math.max(...t.map(((t, n) => Ks(t) + Ks(e[n]))))
}

function Ks(e) {
    return 1e3 * Number(e.slice(0, -1).replace(",", "."))
}

function Zs() {
    return document.body.offsetHeight
}
const Ys = new WeakMap,
    Js = new WeakMap,
    Qs = {
        name: "TransitionGroup",
        props: b({}, Os, {
            tag: String,
            moveClass: String
        }),
        setup(e, {
            slots: t
        }) {
            const n = ls(),
                o = mn();
            let s, l;
            return On((() => {
                if (!s.length) return;
                const t = e.moveClass || `${e.name||"v"}-move`;
                if (! function (e, t, n) {
                        const o = e.cloneNode();
                        e._vtc && e._vtc.forEach((e => {
                            e.split(/\s+/).forEach((e => e && o.classList.remove(e)))
                        }));
                        n.split(/\s+/).forEach((e => e && o.classList.add(e))), o.style.display = "none";
                        const s = 1 === t.nodeType ? t : t.parentNode;
                        s.appendChild(o);
                        const {
                            hasTransform: l
                        } = qs(o);
                        return s.removeChild(o), l
                    }(s[0].el, n.vnode.el, t)) return;
                s.forEach(Xs), s.forEach(el);
                const o = s.filter(tl);
                Zs(), o.forEach((e => {
                    const n = e.el,
                        o = n.style;
                    Ns(n, t), o.transform = o.webkitTransform = o.transitionDuration = "";
                    const s = n._moveCb = e => {
                        e && e.target !== n || e && !/transform$/.test(e.propertyName) || (n.removeEventListener("transitionend", s), n._moveCb = null, Hs(n, t))
                    };
                    n.addEventListener("transitionend", s)
                }))
            })), () => {
                const i = rt(e),
                    r = zs(i);
                let a = i.tag || _o;
                s = l, l = t.default ? Cn(t.default()) : [];
                for (let e = 0; e < l.length; e++) {
                    const t = l[e];
                    null != t.key && _n(t, kn(t, r, o, n))
                }
                if (s)
                    for (let e = 0; e < s.length; e++) {
                        const t = s[e];
                        _n(t, kn(t, r, o, n)), Ys.set(t, t.el.getBoundingClientRect())
                    }
                return No(a, null, l)
            }
        }
    };

function Xs(e) {
    const t = e.el;
    t._moveCb && t._moveCb(), t._enterCb && t._enterCb()
}

function el(e) {
    Js.set(e, e.el.getBoundingClientRect())
}

function tl(e) {
    const t = Ys.get(e),
        n = Js.get(e),
        o = t.left - n.left,
        s = t.top - n.top;
    if (o || s) {
        const t = e.el.style;
        return t.transform = t.webkitTransform = `translate(${o}px,${s}px)`, t.transitionDuration = "0s", e
    }
}
const nl = e => {
    const t = e.props["onUpdate:modelValue"];
    return _(t) ? e => W(t, e) : t
};

function ol(e) {
    e.target.composing = !0
}

function sl(e) {
    const t = e.target;
    t.composing && (t.composing = !1, function (e, t) {
        const n = document.createEvent("HTMLEvents");
        n.initEvent(t, !0, !0), e.dispatchEvent(n)
    }(t, "input"))
}
const ll = {
        created(e, {
            modifiers: {
                lazy: t,
                trim: n,
                number: o
            }
        }, s) {
            e._assign = nl(s);
            const l = o || s.props && "number" === s.props.type;
            Ps(e, t ? "change" : "input", (t => {
                if (t.target.composing) return;
                let o = e.value;
                n ? o = o.trim() : l && (o = G(o)), e._assign(o)
            })), n && Ps(e, "change", (() => {
                e.value = e.value.trim()
            })), t || (Ps(e, "compositionstart", ol), Ps(e, "compositionend", sl), Ps(e, "change", sl))
        },
        mounted(e, {
            value: t
        }) {
            e.value = null == t ? "" : t
        },
        beforeUpdate(e, {
            value: t,
            modifiers: {
                lazy: n,
                trim: o,
                number: s
            }
        }, l) {
            if (e._assign = nl(l), e.composing) return;
            if (document.activeElement === e) {
                if (n) return;
                if (o && e.value.trim() === t) return;
                if ((s || "number" === e.type) && G(e.value) === t) return
            }
            const i = null == t ? "" : t;
            e.value !== i && (e.value = i)
        }
    },
    il = {
        deep: !0,
        created(e, t, n) {
            e._assign = nl(n), Ps(e, "change", (() => {
                const t = e._modelValue,
                    n = dl(e),
                    o = e.checked,
                    s = e._assign;
                if (_(t)) {
                    const e = c(t, n),
                        l = -1 !== e;
                    if (o && !l) s(t.concat(n));
                    else if (!o && l) {
                        const n = [...t];
                        n.splice(e, 1), s(n)
                    }
                } else if (S(t)) {
                    const e = new Set(t);
                    o ? e.add(n) : e.delete(n), s(e)
                } else s(pl(e, o))
            }))
        },
        mounted: rl,
        beforeUpdate(e, t, n) {
            e._assign = nl(n), rl(e, t, n)
        }
    };

function rl(e, {
    value: t,
    oldValue: n
}, o) {
    e._modelValue = t, _(t) ? e.checked = c(t, o.props.value) > -1 : S(t) ? e.checked = t.has(o.props.value) : t !== n && (e.checked = a(t, pl(e, !0)))
}
const al = {
        created(e, {
            value: t
        }, n) {
            e.checked = a(t, n.props.value), e._assign = nl(n), Ps(e, "change", (() => {
                e._assign(dl(e))
            }))
        },
        beforeUpdate(e, {
            value: t,
            oldValue: n
        }, o) {
            e._assign = nl(o), t !== n && (e.checked = a(t, o.props.value))
        }
    },
    cl = {
        deep: !0,
        created(e, {
            value: t,
            modifiers: {
                number: n
            }
        }, o) {
            const s = S(t);
            Ps(e, "change", (() => {
                const t = Array.prototype.filter.call(e.options, (e => e.selected)).map((e => n ? G(dl(e)) : dl(e)));
                e._assign(e.multiple ? s ? new Set(t) : t : t[0])
            })), e._assign = nl(o)
        },
        mounted(e, {
            value: t
        }) {
            ul(e, t)
        },
        beforeUpdate(e, t, n) {
            e._assign = nl(n)
        },
        updated(e, {
            value: t
        }) {
            ul(e, t)
        }
    };

function ul(e, t) {
    const n = e.multiple;
    if (!n || _(t) || S(t)) {
        for (let o = 0, s = e.options.length; o < s; o++) {
            const s = e.options[o],
                l = dl(s);
            if (n) _(t) ? s.selected = c(t, l) > -1 : s.selected = t.has(l);
            else if (a(dl(s), t)) return void(e.selectedIndex !== o && (e.selectedIndex = o))
        }
        n || -1 === e.selectedIndex || (e.selectedIndex = -1)
    }
}

function dl(e) {
    return "_value" in e ? e._value : e.value
}

function pl(e, t) {
    const n = t ? "_trueValue" : "_falseValue";
    return n in e ? e[n] : t
}
const fl = ["ctrl", "shift", "alt", "meta"],
    hl = {
        stop: e => e.stopPropagation(),
        prevent: e => e.preventDefault(),
        self: e => e.target !== e.currentTarget,
        ctrl: e => !e.ctrlKey,
        shift: e => !e.shiftKey,
        alt: e => !e.altKey,
        meta: e => !e.metaKey,
        left: e => "button" in e && 0 !== e.button,
        middle: e => "button" in e && 1 !== e.button,
        right: e => "button" in e && 2 !== e.button,
        exact: (e, t) => fl.some((n => e[`${n}Key`] && !t.includes(n)))
    },
    vl = (e, t) => (n, ...o) => {
        for (let e = 0; e < t.length; e++) {
            const o = hl[t[e]];
            if (o && o(n, t)) return
        }
        return e(n, ...o)
    },
    ml = {
        esc: "escape",
        space: " ",
        up: "arrow-up",
        left: "arrow-left",
        right: "arrow-right",
        down: "arrow-down",
        delete: "backspace"
    },
    gl = (e, t) => n => {
        if (!("key" in n)) return;
        const o = N(n.key);
        return t.some((e => e === o || ml[e] === o)) ? e(n) : void 0
    },
    yl = {
        beforeMount(e, {
            value: t
        }, {
            transition: n
        }) {
            e._vod = "none" === e.style.display ? "" : e.style.display, n && t ? n.beforeEnter(e) : bl(e, t)
        },
        mounted(e, {
            value: t
        }, {
            transition: n
        }) {
            n && t && n.enter(e)
        },
        updated(e, {
            value: t,
            oldValue: n
        }, {
            transition: o
        }) {
            !t != !n && (o ? t ? (o.beforeEnter(e), bl(e, !0), o.enter(e)) : o.leave(e, (() => {
                bl(e, !1)
            })) : bl(e, t))
        },
        beforeUnmount(e, {
            value: t
        }) {
            bl(e, t)
        }
    };

function bl(e, t) {
    e.style.display = t ? e._vod : "none"
}
const kl = b({
    patchProp: (e, o, s, l, i = !1, r, a, c, u) => {
        "class" === o ? function (e, t, n) {
            const o = e._vtc;
            o && (t = (t ? [t, ...o] : [...o]).join(" ")), null == t ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
        }(e, l, i) : "style" === o ? function (e, t, n) {
            const o = e.style,
                s = L(n);
            if (n && !s) {
                for (const e in n) xs(o, e, n[e]);
                if (t && !L(t))
                    for (const e in t) null == n[e] && xs(o, e, "")
            } else {
                const l = o.display;
                s ? t !== n && (o.cssText = n) : t && e.removeAttribute("style"), "_vod" in e && (o.display = l)
            }
        }(e, s, l) : g(o) ? y(o) || Ts(e, o, 0, l, a) : ("." === o[0] ? (o = o.slice(1), 1) : "^" === o[0] ? (o = o.slice(1), 0) : function (e, t, n, o) {
            if (o) return "innerHTML" === t || "textContent" === t || !!(t in e && Is.test(t) && A(n));
            if ("spellcheck" === t || "draggable" === t) return !1;
            if ("form" === t) return !1;
            if ("list" === t && "INPUT" === e.tagName) return !1;
            if ("type" === t && "TEXTAREA" === e.tagName) return !1;
            if (Is.test(t) && L(n)) return !1;
            return t in e
        }(e, o, l, i)) ? function (e, t, o, s, l, i, r) {
            if ("innerHTML" === t || "textContent" === t) return s && r(s, l, i), void(e[t] = null == o ? "" : o);
            if ("value" === t && "PROGRESS" !== e.tagName && !e.tagName.includes("-")) {
                e._value = o;
                const n = null == o ? "" : o;
                return e.value === n && "OPTION" !== e.tagName || (e.value = n), void(null == o && e.removeAttribute(t))
            }
            if ("" === o || null == o) {
                const s = typeof e[t];
                if ("boolean" === s) return void(e[t] = n(o));
                if (null == o && "string" === s) return e[t] = "", void e.removeAttribute(t);
                if ("number" === s) {
                    try {
                        e[t] = 0
                    } catch (a) {}
                    return void e.removeAttribute(t)
                }
            }
            try {
                e[t] = o
            } catch (c) {}
        }(e, o, l, r, a, c, u) : ("true-value" === o ? e._trueValue = l : "false-value" === o && (e._falseValue = l), function (e, o, s, l, i) {
            if (l && o.startsWith("xlink:")) null == s ? e.removeAttributeNS(Cs, o.slice(6, o.length)) : e.setAttributeNS(Cs, o, s);
            else {
                const l = t(o);
                null == s || l && !n(s) ? e.removeAttribute(o) : e.setAttribute(o, l ? "" : s)
            }
        }(e, o, l, i))
    }
}, bs);
let xl, wl = !1;
const _l = (...e) => {
    const t = (xl = wl ? xl : co(kl), wl = !0, xl).createApp(...e),
        {
            mount: n
        } = t;
    return t.mount = e => {
        const t = function (e) {
            if (L(e)) {
                return document.querySelector(e)
            }
            return e
        }(e);
        if (t) return n(t, !0, t instanceof SVGElement)
    }, t
};
const Cl = /^https?:/i,
    Sl = "undefined" != typeof window;

function Ml(e, t) {
    const n = function (e, t) {
        t.sort(((e, t) => {
            const n = t.split("/").length - e.split("/").length;
            return 0 !== n ? n : t.length - e.length
        }));
        for (const n of t)
            if (e.startsWith(n)) return n
    }(t, Object.keys(e));
    return n ? e[n] : void 0
}

function Al(e) {
    const {
        locales: t
    } = e.themeConfig || {}, n = e.locales;
    return t && n ? Object.keys(t).reduce(((e, o) => (e[o] = {
        label: t[o].label,
        lang: n[o].lang
    }, e)), {}) : {}
}

function Ll(e, t) {
    t = function (e, t) {
        if (!Sl) return t;
        const n = e.base,
            o = n.endsWith("/") ? n.slice(0, -1) : n;
        return t.slice(o.length)
    }(e, t);
    const n = Ml(e.locales || {}, t),
        o = Ml(e.themeConfig.locales || {}, t);
    return Object.assign({}, e, n, {
        themeConfig: Object.assign({}, e.themeConfig, o, {
            locales: {}
        }),
        lang: (n || e).lang,
        locales: {},
        langs: Al(e)
    })
}
const El = Symbol(),
    Pl = vt((Tl = '{"lang":"en-US","title":"Vue.js","description":"Vue.js - The Progressive JavaScript Framework","base":"/","head":[],"themeConfig":{"nav":[{"text":"Docs","activeMatch":"^/(guide|style-guide|cookbook|examples)/","items":[{"text":"Guide","link":"/guide/introduction"},{"text":"Tutorial","link":"/tutorial/"},{"text":"Examples","link":"/examples/"},{"text":"Quick Start","link":"/guide/quick-start"},{"text":"Style Guide","link":"/style-guide/"},{"text":"Migration from Vue 2","link":"https://v3-migration.vuejs.org/"}]},{"text":"API","activeMatch":"^/api/","link":"/api/"},{"text":"Playground","link":"https://sfc.vuejs.org"},{"text":"Ecosystem","activeMatch":"^/ecosystem/","items":[{"text":"Resources","items":[{"text":"Partners","link":"/ecosystem/partners"},{"text":"Themes","link":"/ecosystem/themes"},{"text":"Jobs","link":"https://vuejobs.com/?ref=vuejs"},{"text":"T-Shirt Shop","link":"https://vue.threadless.com/"}]},{"text":"Video Courses","items":[{"text":"Vue Mastery","link":"https://www.vuemastery.com/courses/"},{"text":"Vue School","link":"https://vueschool.io/?friend=vuejs&utm_source=Vuejs.org&utm_medium=Link&utm_content=Navbar%20Dropdown"}]},{"text":"Help","items":[{"text":"Discord Chat","link":"https://discord.com/invite/HBherRA"},{"text":"Forum","link":"https://forum.vuejs.org/"},{"text":"DEV Community","link":"https://dev.to/t/vue"}]},{"text":"News","items":[{"text":"Blog","link":"https://blog.vuejs.org/"},{"text":"Twitter","link":"https://twitter.com/vuejs"},{"text":"Newsletter","link":"https://news.vuejs.org/"},{"text":"Events","link":"https://events.vuejs.org/"}]}]},{"text":"About","activeMatch":"^/about/","items":[{"text":"FAQ","link":"/about/faq"},{"text":"Team","link":"/about/team"},{"text":"Releases","link":"/about/releases"},{"text":"Community Guide","link":"/about/community-guide"},{"text":"Code of Conduct","link":"/about/coc"},{"text":"The Documentary","link":"https://www.youtube.com/watch?v=OrxmtDw4pVI"}]},{"text":"Sponsor","link":"/sponsor/"}],"sidebar":{"/guide/":[{"text":"Getting Started","items":[{"text":"Introduction","link":"/guide/introduction"},{"text":"Quick Start","link":"/guide/quick-start"}]},{"text":"Essentials","items":[{"text":"Creating an Application","link":"/guide/essentials/application"},{"text":"Template Syntax","link":"/guide/essentials/template-syntax"},{"text":"Reactivity Fundamentals","link":"/guide/essentials/reactivity-fundamentals"},{"text":"Computed Properties","link":"/guide/essentials/computed"},{"text":"Class and Style Bindings","link":"/guide/essentials/class-and-style"},{"text":"Conditional Rendering","link":"/guide/essentials/conditional"},{"text":"List Rendering","link":"/guide/essentials/list"},{"text":"Event Handling","link":"/guide/essentials/event-handling"},{"text":"Form Input Bindings","link":"/guide/essentials/forms"},{"text":"Lifecycle Hooks","link":"/guide/essentials/lifecycle"},{"text":"Watchers","link":"/guide/essentials/watchers"},{"text":"Template Refs","link":"/guide/essentials/template-refs"},{"text":"Components Basics","link":"/guide/essentials/component-basics"}]},{"text":"Components In-Depth","items":[{"text":"Registration","link":"/guide/components/registration"},{"text":"Props","link":"/guide/components/props"},{"text":"Events","link":"/guide/components/events"},{"text":"Fallthrough Attributes","link":"/guide/components/attrs"},{"text":"Slots","link":"/guide/components/slots"},{"text":"Provide / inject","link":"/guide/components/provide-inject"},{"text":"Async Components","link":"/guide/components/async"}]},{"text":"Reusability","items":[{"text":"Composables","link":"/guide/reusability/composables"},{"text":"Custom Directives","link":"/guide/reusability/custom-directives"},{"text":"Plugins","link":"/guide/reusability/plugins"}]},{"text":"Built-in Components","items":[{"text":"Transition","link":"/guide/built-ins/transition"},{"text":"TransitionGroup","link":"/guide/built-ins/transition-group"},{"text":"KeepAlive","link":"/guide/built-ins/keep-alive"},{"text":"Teleport","link":"/guide/built-ins/teleport"},{"text":"Suspense","link":"/guide/built-ins/suspense"}]},{"text":"Scaling Up","items":[{"text":"Single-File Components","link":"/guide/scaling-up/sfc"},{"text":"Tooling","link":"/guide/scaling-up/tooling"},{"text":"Routing","link":"/guide/scaling-up/routing"},{"text":"State Management","link":"/guide/scaling-up/state-management"},{"text":"Testing","link":"/guide/scaling-up/testing"},{"text":"Server-Side Rendering (SSR)","link":"/guide/scaling-up/ssr"}]},{"text":"Best Practices","items":[{"text":"Production Deployment","link":"/guide/best-practices/production-deployment"},{"text":"Performance","link":"/guide/best-practices/performance"},{"text":"Accessibility","link":"/guide/best-practices/accessibility"},{"text":"Security","link":"/guide/best-practices/security"}]},{"text":"TypeScript","items":[{"text":"Overview","link":"/guide/typescript/overview"},{"text":"TS with Composition API","link":"/guide/typescript/composition-api"},{"text":"TS with Options API","link":"/guide/typescript/options-api"}]},{"text":"Extra Topics","items":[{"text":"Ways of Using Vue","link":"/guide/extras/ways-of-using-vue"},{"text":"Composition API FAQ","link":"/guide/extras/composition-api-faq"},{"text":"Reactivity in Depth","link":"/guide/extras/reactivity-in-depth"},{"text":"Rendering Mechanism","link":"/guide/extras/rendering-mechanism"},{"text":"Render Functions & JSX","link":"/guide/extras/render-function"},{"text":"Vue and Web Components","link":"/guide/extras/web-components"},{"text":"Animation Techniques","link":"/guide/extras/animation"},{"text":"Reactivity Transform","link":"/guide/extras/reactivity-transform"}]}],"/api/":[{"text":"Global API","items":[{"text":"Application","link":"/api/application"},{"text":"General","link":"/api/general"}]},{"text":"Composition API","items":[{"text":"setup()","link":"/api/composition-api-setup"},{"text":"Reactivity: Core","link":"/api/reactivity-core"},{"text":"Reactivity: Utilities","link":"/api/reactivity-utilities"},{"text":"Reactivity: Advanced","link":"/api/reactivity-advanced"},{"text":"Lifecycle Hooks","link":"/api/composition-api-lifecycle"},{"text":"Dependency Injection","link":"/api/composition-api-dependency-injection"}]},{"text":"Options API","items":[{"text":"Options: State","link":"/api/options-state"},{"text":"Options: Rendering","link":"/api/options-rendering"},{"text":"Options: Lifecycle","link":"/api/options-lifecycle"},{"text":"Options: Composition","link":"/api/options-composition"},{"text":"Options: Misc","link":"/api/options-misc"},{"text":"Component Instance","link":"/api/component-instance"}]},{"text":"Built-ins","items":[{"text":"Directives","link":"/api/built-in-directives"},{"text":"Components","link":"/api/built-in-components"},{"text":"Special Elements","link":"/api/built-in-special-elements"},{"text":"Special Attributes","link":"/api/built-in-special-attributes"}]},{"text":"Single File Component","items":[{"text":"Syntax Specification","link":"/api/sfc-spec"},{"text":"<script setup>","link":"/api/sfc-script-setup"},{"text":"CSS Features","link":"/api/sfc-css-features"}]},{"text":"Advanced APIs","items":[{"text":"Render Function","link":"/api/render-function"},{"text":"Server-Side Rendering","link":"/api/ssr"},{"text":"TypeScript Utility Types","link":"/api/utility-types"},{"text":"Custom Renderer","link":"/api/custom-renderer"}]}],"/examples/":[{"text":"Basic","items":[{"text":"Hello World","link":"/examples/#hello-world"},{"text":"Handling User Input","link":"/examples/#handling-input"},{"text":"Attribute Bindings","link":"/examples/#attribute-bindings"},{"text":"Conditionals and Loops","link":"/examples/#conditionals-and-loops"},{"text":"Form Bindings","link":"/examples/#form-bindings"},{"text":"Simple Component","link":"/examples/#simple-component"}]},{"text":"Practical","items":[{"text":"Markdown Editor","link":"/examples/#markdown"},{"text":"Fetching Data","link":"/examples/#fetching-data"},{"text":"Grid with Sort and Filter","link":"/examples/#grid"},{"text":"Tree View","link":"/examples/#tree"},{"text":"SVG Graph","link":"/examples/#svg"},{"text":"Modal with Transitions","link":"/examples/#modal"},{"text":"List with Transitions","link":"/examples/#list-transition"},{"text":"TodoMVC","link":"/examples/#todomvc"}]},{"text":"7 GUIs","items":[{"text":"Counter","link":"/examples/#counter"},{"text":"Temperature Converter","link":"/examples/#temperature-converter"},{"text":"Flight Booker","link":"/examples/#flight-booker"},{"text":"Timer","link":"/examples/#timer"},{"text":"CRUD","link":"/examples/#crud"},{"text":"Circle Drawer","link":"/examples/#circle-drawer"},{"text":"Cells","link":"/examples/#cells"}]}],"/style-guide/":[{"text":"Style Guide","items":[{"text":"Overview","link":"/style-guide/"},{"text":"A - Essential","link":"/style-guide/rules-essential"},{"text":"B - Strongly Recommended","link":"/style-guide/rules-strongly-recommended"},{"text":"C - Recommended","link":"/style-guide/rules-recommended"},{"text":"D - Use with Caution","link":"/style-guide/rules-use-with-caution"}]}]},"algolia":{"indexName":"vuejs","appId":"ML0LEBN7FQ","apiKey":"f49cbd92a74532cc55cfbffa5e5a7d01","searchParameters":{"facetFilters":["version:v3"]}},"carbonAds":{"code":"CEBDT27Y","placement":"vuejsorg"},"socialLinks":[{"icon":"languages","link":"/translations/"},{"icon":"github","link":"https://github.com/vuejs/"},{"icon":"twitter","link":"https://twitter.com/vuejs"},{"icon":"discord","link":"https://discord.com/invite/HBherRA"}],"editLink":{"repo":"vuejs/docs","text":"Edit this page on GitHub"},"footer":{"license":{"text":"MIT License","link":"https://opensource.org/licenses/MIT"},"copyright":"Copyright © 2014-2022 Evan You"}},"locales":{},"langs":{},"scrollOffset":"header"}', JSON.parse(Tl)));
var Tl;

function Vl() {
    const e = un(El);
    if (!e) throw new Error("vitepress data not properly injected in app");
    return e
}

function Il(e) {
    return Cl.test(e) ? e : function (e, t) {
        return `${e}${t}`.replace(/\/+/g, "/")
    }(Pl.value.base, e)
}

function $l(e) {
    let t = e.replace(/\.html$/, "");
    if (t = decodeURIComponent(t), t.endsWith("/") && (t += "index"), Sl) {
        const e = "/";
        t = t.slice(e.length).replace(/\//g, "_") + ".md";
        const n = __VP_HASH_MAP__[t.toLowerCase()];
        t = `${e}assets/${t}.${n}.js`
    } else t = `./${t.slice(1).replace(/\//g,"_")}.md.js`;
    return t
}
const Bl = Symbol();

function Ol() {
    const e = un(Bl);
    if (!e) throw new Error("useRouter() is called without provider.");
    return e
}

function jl() {
    return Ol().route
}

function Fl(e, t, n = !1) {
    let o = null;
    try {
        o = e.classList.contains(".header-anchor") ? e : document.querySelector(decodeURIComponent(t))
    } catch (s) {
        console.warn(s)
    }
    if (o) {
        let e = Pl.value.scrollOffset;
        "string" == typeof e && (e = document.querySelector(e).getBoundingClientRect().bottom + 24);
        const t = parseInt(window.getComputedStyle(o).paddingTop, 10),
            s = window.scrollY + o.getBoundingClientRect().top - e + t;
        !n || Math.abs(s - window.scrollY) > window.innerHeight ? window.scrollTo(0, s) : window.scrollTo({
            left: 0,
            top: s,
            behavior: "smooth"
        })
    }
}

function zl(e, t) {
    let n = [],
        o = !0;
    dn((() => {
        const s = e.data,
            l = t.value,
            i = s && s.title,
            r = s && s.description,
            a = s && s.frontmatter.head;
        var c;
        document.title = (i ? i + " | " : "") + l.title, document.querySelector("meta[name=description]").setAttribute("content", r || l.description), (e => {
            if (o) return void(o = !1);
            const t = [],
                s = Math.min(n.length, e.length);
            for (let o = 0; o < s; o++) {
                let s = n[o];
                const [l, i, r = ""] = e[o];
                if (s.tagName.toLocaleLowerCase() === l) {
                    for (const e in i) s.getAttribute(e) !== i[e] && s.setAttribute(e, i[e]);
                    for (let e = 0; e < s.attributes.length; e++) {
                        const t = s.attributes[e].name;
                        t in i || s.removeAttribute(t)
                    }
                    s.innerHTML !== r && (s.innerHTML = r)
                } else document.head.removeChild(s), s = Rl(e[o]), document.head.append(s);
                t.push(s)
            }
            n.slice(s).forEach((e => document.head.removeChild(e))), e.slice(s).forEach((e => {
                const n = Rl(e);
                document.head.appendChild(n), t.push(n)
            })), n = t
        })([...a ? (c = a, c.filter((e => {
            return !("meta" === (t = e)[0] && t[1] && "description" === t[1].name);
            var t
        }))) : []])
    }))
}

function Rl([e, t, n]) {
    const o = document.createElement(e);
    for (const s in t) o.setAttribute(s, t[s]);
    return n && (o.innerHTML = n), o
}
var Nl = (e, t) => {
    const n = e.__vccOpts || e;
    for (const [o, s] of t) n[o] = s;
    return n
};
const Hl = {},
    Dl = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Ul = [Ro("path", {
        d: "M17,11H3c-0.6,0-1-0.4-1-1s0.4-1,1-1h14c0.6,0,1,0.4,1,1S17.6,11,17,11z"
    }, null, -1), Ro("path", {
        d: "M21,7H3C2.4,7,2,6.6,2,6s0.4-1,1-1h18c0.6,0,1,0.4,1,1S21.6,7,21,7z"
    }, null, -1), Ro("path", {
        d: "M21,15H3c-0.6,0-1-0.4-1-1s0.4-1,1-1h18c0.6,0,1,0.4,1,1S21.6,15,21,15z"
    }, null, -1), Ro("path", {
        d: "M17,19H3c-0.6,0-1-0.4-1-1s0.4-1,1-1h14c0.6,0,1,0.4,1,1S17.6,19,17,19z"
    }, null, -1)];
var Wl = Nl(Hl, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Dl, Ul)
    }]
]);
const ql = {},
    Gl = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Kl = [Ro("path", {
        d: "M16,19c-0.3,0-0.5-0.1-0.7-0.3c-0.4-0.4-0.4-1,0-1.4l5.3-5.3l-5.3-5.3c-0.4-0.4-0.4-1,0-1.4s1-0.4,1.4,0l6,6c0.4,0.4,0.4,1,0,1.4l-6,6C16.5,18.9,16.3,19,16,19z"
    }, null, -1), Ro("path", {
        d: "M8,19c-0.3,0-0.5-0.1-0.7-0.3l-6-6c-0.4-0.4-0.4-1,0-1.4l6-6c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4L3.4,12l5.3,5.3c0.4,0.4,0.4,1,0,1.4C8.5,18.9,8.3,19,8,19z"
    }, null, -1)];
var Zl = Nl(ql, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Gl, Kl)
    }]
]);
const Yl = {},
    Jl = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Ql = [Ro("path", {
        d: "M24,16a1.11,1.11,0,0,0,0-.19V8.18A1.11,1.11,0,0,0,24,8a.13.13,0,0,1,0-.06,1.14,1.14,0,0,0-.15-.34s0,0,0,0l0,0a1,1,0,0,0-.27-.26h0L12.59.17,12.48.12l-.1,0a1.1,1.1,0,0,0-.76,0l-.1,0-.11.05L.5,7.26a1,1,0,0,0-.27.26l0,0s0,0,0,0A1.14,1.14,0,0,0,0,7.93.13.13,0,0,1,0,8a1.11,1.11,0,0,0,0,.19v7.63A1.11,1.11,0,0,0,0,16a.13.13,0,0,1,0,.06,1,1,0,0,0,.15.34l0,0,0,0a1,1,0,0,0,.27.26l10.91,7.09.11.05.1.05a.94.94,0,0,0,.76,0l.1-.05.11-.05L23.5,16.73a1.2,1.2,0,0,0,.28-.27s0,0,0,0l0,0a1.19,1.19,0,0,0,.15-.35A.13.13,0,0,1,24,16ZM2.18,10.27,4.64,12,2.18,13.72ZM12,14.48,8.45,12,12,9.51,15.55,12Zm1.09-6.87V3.1L21,8.21l-3.51,2.45Zm-2.18,0L6.55,10.66,3,8.21,10.91,3.1ZM6.55,13.33l4.36,3V20.9L3,15.78Zm6.54,3,4.36-3L21,15.78,13.09,20.9ZM19.36,12l2.46-1.73v3.45Z"
    }, null, -1)];
var Xl = Nl(Yl, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Jl, Ql)
    }]
]);
const ei = {},
    ti = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    ni = [Ro("path", {
        d: "M12,16c-0.3,0-0.5-0.1-0.7-0.3l-6-6c-0.4-0.4-0.4-1,0-1.4s1-0.4,1.4,0l5.3,5.3l5.3-5.3c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4l-6,6C12.5,15.9,12.3,16,12,16z"
    }, null, -1)];
var oi = Nl(ei, [
    ["render", function (e, t) {
        return Eo(), Io("svg", ti, ni)
    }]
]);
const si = {},
    li = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    ii = [Ro("path", {
        d: "M15,19c-0.3,0-0.5-0.1-0.7-0.3l-6-6c-0.4-0.4-0.4-1,0-1.4l6-6c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4L10.4,12l5.3,5.3c0.4,0.4,0.4,1,0,1.4C15.5,18.9,15.3,19,15,19z"
    }, null, -1)];
var ri = Nl(si, [
    ["render", function (e, t) {
        return Eo(), Io("svg", li, ii)
    }]
]);
const ai = {},
    ci = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    ui = [Ro("path", {
        d: "M9,19c-0.3,0-0.5-0.1-0.7-0.3c-0.4-0.4-0.4-1,0-1.4l5.3-5.3L8.3,6.7c-0.4-0.4-0.4-1,0-1.4s1-0.4,1.4,0l6,6c0.4,0.4,0.4,1,0,1.4l-6,6C9.5,18.9,9.3,19,9,19z"
    }, null, -1)];
var di = Nl(ai, [
    ["render", function (e, t) {
        return Eo(), Io("svg", ci, ui)
    }]
]);
const pi = {},
    fi = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    hi = [Ro("path", {
        d: "M20.222 0c1.406 0 2.54 1.137 2.607 2.475V24l-2.677-2.273-1.47-1.338-1.604-1.398.67 2.205H3.71c-1.402 0-2.54-1.065-2.54-2.476V2.48C1.17 1.142 2.31.003 3.715.003h16.5L20.222 0zm-6.118 5.683h-.03l-.202.2c2.073.6 3.076 1.537 3.076 1.537-1.336-.668-2.54-1.002-3.744-1.137-.87-.135-1.74-.064-2.475 0h-.2c-.47 0-1.47.2-2.81.735-.467.203-.735.336-.735.336s1.002-1.002 3.21-1.537l-.135-.135s-1.672-.064-3.477 1.27c0 0-1.805 3.144-1.805 7.02 0 0 1 1.74 3.743 1.806 0 0 .4-.533.805-1.002-1.54-.468-2.14-1.404-2.14-1.404s.134.066.335.2h.06c.03 0 .044.015.06.03v.006c.016.016.03.03.06.03.33.136.66.27.93.4.466.202 1.065.403 1.8.536.93.135 1.996.2 3.21 0 .6-.135 1.2-.267 1.8-.535.39-.2.87-.4 1.397-.737 0 0-.6.936-2.205 1.404.33.466.795 1 .795 1 2.744-.06 3.81-1.8 3.87-1.726 0-3.87-1.815-7.02-1.815-7.02-1.635-1.214-3.165-1.26-3.435-1.26l.056-.02zm.168 4.413c.703 0 1.27.6 1.27 1.335 0 .74-.57 1.34-1.27 1.34-.7 0-1.27-.6-1.27-1.334.002-.74.573-1.338 1.27-1.338zm-4.543 0c.7 0 1.266.6 1.266 1.335 0 .74-.57 1.34-1.27 1.34-.7 0-1.27-.6-1.27-1.334 0-.74.57-1.338 1.27-1.338z"
    }, null, -1)];
var vi = Nl(pi, [
    ["render", function (e, t) {
        return Eo(), Io("svg", fi, hi)
    }]
]);
const mi = {},
    gi = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        height: "24px",
        viewBox: "0 0 24 24",
        width: "24px"
    },
    yi = [Ro("path", {
        d: "M0 0h24v24H0V0z",
        fill: "none"
    }, null, -1), Ro("path", {
        d: "M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"
    }, null, -1)];
var bi = Nl(mi, [
    ["render", function (e, t) {
        return Eo(), Io("svg", gi, yi)
    }]
]);
const ki = {},
    xi = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    wi = [Ro("path", {
        d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"
    }, null, -1)];
var _i = Nl(ki, [
    ["render", function (e, t) {
        return Eo(), Io("svg", xi, wi)
    }]
]);
const Ci = {},
    Si = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Mi = [Ro("path", {
        d: "M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"
    }, null, -1)];
var Ai = Nl(Ci, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Si, Mi)
    }]
]);
const Li = {},
    Ei = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Pi = [Ro("path", {
        d: "M12,1C5.9,1,1,5.9,1,12s4.9,11,11,11s11-4.9,11-11S18.1,1,12,1z M20.9,11h-4c-0.2-2.8-1.1-5.4-2.7-7.7C17.8,4.2,20.5,7.3,20.9,11zM9.1,13h5.9c-0.3,2.7-1.3,5.3-2.9,7.4C10.3,18.3,9.3,15.7,9.1,13zM9.1,11c0.3-2.7,1.3-5.3,2.9-7.4c1.7,2.2,2.7,4.8,2.9,7.4H9.1z M9.7,3.3C8.2,5.6,7.3,8.2,7.1,11h-4C3.5,7.3,6.2,4.2,9.7,3.3zM3.1,13h4c0.2,2.8,1.1,5.4,2.7,7.7C6.2,19.8,3.5,16.7,3.1,13z M14.3,20.7c1.5-2.3,2.4-4.9,2.7-7.7h4C20.5,16.7,17.8,19.8,14.3,20.7z"
    }, null, -1)];
var Ti = Nl(Li, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Ei, Pi)
    }]
]);
const Vi = {},
    Ii = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    $i = [Ro("path", {
        d: "M12,22.2c-0.3,0-0.5-0.1-0.7-0.3l-8.8-8.8c-2.5-2.5-2.5-6.7,0-9.2c2.5-2.5,6.7-2.5,9.2,0L12,4.3l0.4-0.4c0,0,0,0,0,0C13.6,2.7,15.2,2,16.9,2c0,0,0,0,0,0c1.7,0,3.4,0.7,4.6,1.9l0,0c1.2,1.2,1.9,2.9,1.9,4.6c0,1.7-0.7,3.4-1.9,4.6l-8.8,8.8C12.5,22.1,12.3,22.2,12,22.2zM7,4C5.9,4,4.7,4.4,3.9,5.3c-1.8,1.8-1.8,4.6,0,6.4l8.1,8.1l8.1-8.1c0.9-0.9,1.3-2,1.3-3.2c0-1.2-0.5-2.3-1.3-3.2l0,0C19.3,4.5,18.2,4,17,4c0,0,0,0,0,0c-1.2,0-2.3,0.5-3.2,1.3c0,0,0,0,0,0l-1.1,1.1c-0.4,0.4-1,0.4-1.4,0l-1.1-1.1C9.4,4.4,8.2,4,7,4z"
    }, null, -1)];
var Bi = Nl(Vi, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Ii, $i)
    }]
]);
const Oi = {},
    ji = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Fi = [Ro("path", {
        d: "M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"
    }, null, -1)];
var zi = Nl(Oi, [
    ["render", function (e, t) {
        return Eo(), Io("svg", ji, Fi)
    }]
]);
const Ri = {},
    Ni = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Hi = [Ro("path", {
        d: "M0 0h24v24H0z",
        fill: "none"
    }, null, -1), Ro("path", {
        d: " M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z ",
        class: "css-c4d79v"
    }, null, -1)];
var Di = Nl(Ri, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Ni, Hi)
    }]
]);
const Ui = {},
    Wi = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    qi = [Ro("path", {
        d: "M14,16c-1.8,0-3.6-0.8-4.8-2.4c-0.3-0.4-0.2-1.1,0.2-1.4c0.4-0.3,1.1-0.2,1.4,0.2c1.3,1.8,3.8,2.1,5.6,0.8c0.2-0.1,0.3-0.2,0.4-0.4l3-3c1.5-1.6,1.5-4.1-0.1-5.6c-1.6-1.5-4-1.5-5.6,0l-1.7,1.7c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-1,0-1.4l1.7-1.7c2.3-2.3,6-2.3,8.3,0c2.4,2.3,2.4,6.1,0.1,8.5l-3,3c-0.2,0.2-0.4,0.4-0.7,0.6C16.5,15.6,15.3,16,14,16z"
    }, null, -1), Ro("path", {
        d: "M7.1,22.9c-1.5,0-3-0.6-4.2-1.7c-2.4-2.3-2.4-6.1-0.1-8.5l3-3C6,9.6,6.2,9.4,6.4,9.2c1.3-1,2.9-1.4,4.4-1.1c1.6,0.2,3,1.1,3.9,2.3c0.3,0.4,0.2,1.1-0.2,1.4c-0.4,0.3-1.1,0.2-1.4-0.2c-0.6-0.9-1.6-1.4-2.6-1.6c-1.1-0.2-2.1,0.1-3,0.8c-0.2,0.1-0.3,0.2-0.4,0.4l-3,3c-1.5,1.6-1.5,4.1,0.1,5.6c1.6,1.5,4,1.5,5.6,0l1.7-1.7c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4l-1.7,1.7C10.1,22.4,8.6,22.9,7.1,22.9z"
    }, null, -1)];
var Gi = Nl(Ui, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Wi, qi)
    }]
]);
const Ki = {},
    Zi = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Yi = [Ro("path", {
        d: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
    }, null, -1)];
var Ji = Nl(Ki, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Zi, Yi)
    }]
]);
const Qi = {},
    Xi = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    er = [Ro("path", {
        d: "M20.73,2.18H3.27A3.28,3.28,0,0,0,0,5.45v13.1a3.28,3.28,0,0,0,3.27,3.27H20.73A3.28,3.28,0,0,0,24,18.55V5.45A3.28,3.28,0,0,0,20.73,2.18ZM3.27,4.36H20.73a1.1,1.1,0,0,1,1,.61L12,11.76,2.31,5A1.1,1.1,0,0,1,3.27,4.36ZM20.73,19.64H3.27a1.09,1.09,0,0,1-1.09-1.09v-11L11.37,14a1.09,1.09,0,0,0,1.26,0l9.19-6.43v11A1.09,1.09,0,0,1,20.73,19.64Z"
    }, null, -1)];
var tr = Nl(Qi, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Xi, er)
    }]
]);
const nr = {},
    or = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    sr = [Ro("path", {
        d: "M12,24c-0.2,0-0.4-0.1-0.6-0.2C11.1,23.6,2,17.4,2,10C2,4.5,6.5,0,12,0c5.5,0,10,4.5,10,10c0,7.4-9.1,13.6-9.4,13.8C12.4,23.9,12.2,24,12,24zM12,2c-4.4,0-8,3.6-8,8c0,5.4,6.1,10.4,8,11.8c1.9-1.4,8-6.4,8-11.8C20,5.6,16.4,2,12,2z"
    }, null, -1), Ro("path", {
        d: "M12,14c-2.2,0-4-1.8-4-4s1.8-4,4-4c2.2,0,4,1.8,4,4S14.2,14,12,14zM12,8c-1.1,0-2,0.9-2,2s0.9,2,2,2c1.1,0,2-0.9,2-2S13.1,8,12,8z"
    }, null, -1)];
var lr = Nl(nr, [
    ["render", function (e, t) {
        return Eo(), Io("svg", or, sr)
    }]
]);
const ir = {},
    rr = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    ar = [Ro("circle", {
        cx: "12",
        cy: "12",
        r: "2"
    }, null, -1), Ro("circle", {
        cx: "19",
        cy: "12",
        r: "2"
    }, null, -1), Ro("circle", {
        cx: "5",
        cy: "12",
        r: "2"
    }, null, -1)];
var cr = Nl(ir, [
    ["render", function (e, t) {
        return Eo(), Io("svg", rr, ar)
    }]
]);
const ur = {},
    dr = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    pr = [Ro("path", {
        d: "M12.1,22c-0.3,0-0.6,0-0.9,0c-5.5-0.5-9.5-5.4-9-10.9c0.4-4.8,4.2-8.6,9-9c0.4,0,0.8,0.2,1,0.5c0.2,0.3,0.2,0.8-0.1,1.1c-2,2.7-1.4,6.4,1.3,8.4c2.1,1.6,5,1.6,7.1,0c0.3-0.2,0.7-0.3,1.1-0.1c0.3,0.2,0.5,0.6,0.5,1c-0.2,2.7-1.5,5.1-3.6,6.8C16.6,21.2,14.4,22,12.1,22zM9.3,4.4c-2.9,1-5,3.6-5.2,6.8c-0.4,4.4,2.8,8.3,7.2,8.7c2.1,0.2,4.2-0.4,5.8-1.8c1.1-0.9,1.9-2.1,2.4-3.4c-2.5,0.9-5.3,0.5-7.5-1.1C9.2,11.4,8.1,7.7,9.3,4.4z"
    }, null, -1)];
var fr = Nl(ur, [
    ["render", function (e, t) {
        return Eo(), Io("svg", dr, pr)
    }]
]);
const hr = {},
    vr = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    mr = [Ro("path", {
        d: "M18.9,10.9h-6v-6c0-0.6-0.4-1-1-1s-1,0.4-1,1v6h-6c-0.6,0-1,0.4-1,1s0.4,1,1,1h6v6c0,0.6,0.4,1,1,1s1-0.4,1-1v-6h6c0.6,0,1-0.4,1-1S19.5,10.9,18.9,10.9z"
    }, null, -1)];
var gr = Nl(hr, [
    ["render", function (e, t) {
        return Eo(), Io("svg", vr, mr)
    }]
]);
const yr = {},
    br = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    kr = [Ro("path", {
        d: "M5.042 15.165a2.528 2.528 0 0 1-2.52 2.523A2.528 2.528 0 0 1 0 15.165a2.527 2.527 0 0 1 2.522-2.52h2.52v2.52zM6.313 15.165a2.527 2.527 0 0 1 2.521-2.52 2.527 2.527 0 0 1 2.521 2.52v6.313A2.528 2.528 0 0 1 8.834 24a2.528 2.528 0 0 1-2.521-2.522v-6.313zM8.834 5.042a2.528 2.528 0 0 1-2.521-2.52A2.528 2.528 0 0 1 8.834 0a2.528 2.528 0 0 1 2.521 2.522v2.52H8.834zM8.834 6.313a2.528 2.528 0 0 1 2.521 2.521 2.528 2.528 0 0 1-2.521 2.521H2.522A2.528 2.528 0 0 1 0 8.834a2.528 2.528 0 0 1 2.522-2.521h6.312zM18.956 8.834a2.528 2.528 0 0 1 2.522-2.521A2.528 2.528 0 0 1 24 8.834a2.528 2.528 0 0 1-2.522 2.521h-2.522V8.834zM17.688 8.834a2.528 2.528 0 0 1-2.523 2.521 2.527 2.527 0 0 1-2.52-2.521V2.522A2.527 2.527 0 0 1 15.165 0a2.528 2.528 0 0 1 2.523 2.522v6.312zM15.165 18.956a2.528 2.528 0 0 1 2.523 2.522A2.528 2.528 0 0 1 15.165 24a2.527 2.527 0 0 1-2.52-2.522v-2.522h2.52zM15.165 17.688a2.527 2.527 0 0 1-2.52-2.523 2.526 2.526 0 0 1 2.52-2.52h6.313A2.527 2.527 0 0 1 24 15.165a2.528 2.528 0 0 1-2.522 2.523h-6.313z"
    }, null, -1)];
var xr = Nl(yr, [
    ["render", function (e, t) {
        return Eo(), Io("svg", br, kr)
    }]
]);
const wr = {},
    _r = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Cr = [Uo('<path d="M12,18c-3.3,0-6-2.7-6-6s2.7-6,6-6s6,2.7,6,6S15.3,18,12,18zM12,8c-2.2,0-4,1.8-4,4c0,2.2,1.8,4,4,4c2.2,0,4-1.8,4-4C16,9.8,14.2,8,12,8z"></path><path d="M12,4c-0.6,0-1-0.4-1-1V1c0-0.6,0.4-1,1-1s1,0.4,1,1v2C13,3.6,12.6,4,12,4z"></path><path d="M12,24c-0.6,0-1-0.4-1-1v-2c0-0.6,0.4-1,1-1s1,0.4,1,1v2C13,23.6,12.6,24,12,24z"></path><path d="M5.6,6.6c-0.3,0-0.5-0.1-0.7-0.3L3.5,4.9c-0.4-0.4-0.4-1,0-1.4s1-0.4,1.4,0l1.4,1.4c0.4,0.4,0.4,1,0,1.4C6.2,6.5,5.9,6.6,5.6,6.6z"></path><path d="M19.8,20.8c-0.3,0-0.5-0.1-0.7-0.3l-1.4-1.4c-0.4-0.4-0.4-1,0-1.4s1-0.4,1.4,0l1.4,1.4c0.4,0.4,0.4,1,0,1.4C20.3,20.7,20,20.8,19.8,20.8z"></path><path d="M3,13H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h2c0.6,0,1,0.4,1,1S3.6,13,3,13z"></path><path d="M23,13h-2c-0.6,0-1-0.4-1-1s0.4-1,1-1h2c0.6,0,1,0.4,1,1S23.6,13,23,13z"></path><path d="M4.2,20.8c-0.3,0-0.5-0.1-0.7-0.3c-0.4-0.4-0.4-1,0-1.4l1.4-1.4c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4l-1.4,1.4C4.7,20.7,4.5,20.8,4.2,20.8z"></path><path d="M18.4,6.6c-0.3,0-0.5-0.1-0.7-0.3c-0.4-0.4-0.4-1,0-1.4l1.4-1.4c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4l-1.4,1.4C18.9,6.5,18.6,6.6,18.4,6.6z"></path>', 9)];
var Sr = Nl(wr, [
    ["render", function (e, t) {
        return Eo(), Io("svg", _r, Cr)
    }]
]);
const Mr = {},
    Ar = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Lr = [Ro("path", {
        d: "M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"
    }, null, -1)];
var Er = Nl(Mr, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Ar, Lr)
    }]
]);
const Pr = {},
    Tr = {
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        focusable: "false",
        viewBox: "0 0 24 24"
    },
    Vr = [Ro("path", {
        d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"
    }, null, -1)];
var Ir = Nl(Pr, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Tr, Vr)
    }]
]);
const $r = {},
    Br = {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
    },
    Or = [Ro("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
    }, null, -1)];
var jr = Nl($r, [
    ["render", function (e, t) {
        return Eo(), Io("svg", Br, Or)
    }]
]);
const Fr = {
        key: 0,
        class: "vt-backdrop"
    },
    zr = Sn({
        props: {
            show: {
                type: Boolean
            }
        },
        setup: e => (t, n) => (Eo(), $o($s, {
            name: "fade"
        }, {
            default: nn((() => [e.show ? (Eo(), Io("div", Fr)) : Wo("", !0)])),
            _: 1
        }))
    }),
    Rr = ht();
let Nr = !1,
    Hr = 0;

function Dr(e) {
    const t = ht(!1);
    if ("undefined" != typeof window) {
        !Nr && (document.addEventListener("focusin", Ur), Nr = !0, Rr.value = document.activeElement), Hr++;
        const n = fn(Rr, (n => {
            var o, s, l;
            n === e.elRef.value || (null == (o = e.elRef.value) ? void 0 : o.contains(n)) ? (t.value = !0, null == (s = e.onFocus) || s.call(e)) : (t.value = !1, null == (l = e.onBlur) || l.call(e))
        }));
        Fn((() => {
            n(), Hr--, Hr || document.removeEventListener("focusin", Ur)
        }))
    }
    return tt(t)
}

function Ur() {
    Rr.value = document.activeElement
}
const Wr = Sn({
        props: {
            href: null,
            noIcon: {
                type: Boolean
            }
        },
        setup(e) {
            const t = e,
                n = hs((() => t.href && /^[a-z]+:/i.test(t.href)));
            return (t, o) => (Eo(), $o(ko(e.href ? "a" : "span"), {
                class: r(["vt-link", {
                    link: e.href
                }]),
                href: e.href,
                target: yt(n) ? "_blank" : void 0,
                rel: yt(n) ? "noopener noreferrer" : void 0
            }, {
                default: nn((() => [Jo(t.$slots, "default"), yt(n) && !e.noIcon ? (Eo(), $o(bi, {
                    key: 0,
                    class: "vt-link-icon"
                })) : Wo("", !0)])),
                _: 3
            }, 8, ["class", "href", "target", "rel"]))
        }
    }),
    qr = Sn({
        props: {
            item: null
        },
        setup: e => (t, n) => (Eo(), $o(Wr, {
            class: "vt-menu-link",
            href: e.item.link
        }, {
            default: nn((() => [Do(u(e.item.text), 1)])),
            _: 1
        }, 8, ["href"]))
    }),
    Gr = {
        class: "vt-menu-group"
    },
    Kr = {
        key: 0,
        class: "vt-menu-group-title"
    },
    Zr = Sn({
        props: {
            text: null,
            items: null
        },
        setup: e => (t, n) => (Eo(), Io("div", Gr, [e.text ? (Eo(), Io("p", Kr, u(e.text), 1)) : Wo("", !0), (Eo(!0), Io(_o, null, Yo(e.items, (e => (Eo(), Io(_o, null, ["link" in e ? (Eo(), $o(qr, {
            key: 0,
            item: e
        }, null, 8, ["item"])) : Wo("", !0)], 64)))), 256))]))
    }),
    Yr = {
        class: "vt-menu"
    },
    Jr = {
        key: 0,
        class: "vt-menu-items"
    },
    Qr = Sn({
        props: {
            items: null
        },
        setup: e => (t, n) => (Eo(), Io("div", Yr, [e.items ? (Eo(), Io("div", Jr, [(Eo(!0), Io(_o, null, Yo(e.items, (e => (Eo(), Io(_o, {
            key: e.text
        }, ["link" in e ? (Eo(), $o(qr, {
            key: 0,
            item: e
        }, null, 8, ["item"])) : (Eo(), $o(Zr, {
            key: 1,
            text: e.text,
            items: e.items
        }, null, 8, ["text", "items"]))], 64)))), 128))])) : Wo("", !0), Jo(t.$slots, "default")]))
    }),
    Xr = ["aria-expanded", "aria-label"],
    ea = {
        key: 0,
        class: "vt-flyout-button-text"
    },
    ta = {
        class: "vt-flyout-menu"
    },
    na = Sn({
        props: {
            button: null,
            items: null,
            label: null
        },
        setup(e) {
            const t = e,
                n = ht(!1),
                o = ht();
            return Dr({
                elRef: o,
                onBlur: () => {
                    n.value = !1
                }
            }), (s, l) => (Eo(), Io("div", {
                class: "vt-flyout",
                ref_key: "elRef",
                ref: o,
                onMouseenter: l[1] || (l[1] = e => n.value = !0),
                onMouseleave: l[2] || (l[2] = e => n.value = !1)
            }, [Ro("button", {
                type: "button",
                class: "vt-flyout-button",
                "aria-haspopup": "true",
                "aria-expanded": n.value,
                "aria-label": e.label,
                onClick: l[0] || (l[0] = e => n.value = !n.value)
            }, [t.button ? (Eo(), Io("span", ea, [Do(u(t.button) + " ", 1), No(oi, {
                class: "vt-flyout-button-text-icon"
            })])) : (Eo(), $o(cr, {
                key: 1,
                class: "vt-flyout-button-icon"
            }))], 8, Xr), Ro("div", ta, [No(Qr, {
                items: e.items
            }, {
                default: nn((() => [Jo(s.$slots, "default")])),
                _: 3
            }, 8, ["items"])])], 544))
        }
    }),
    oa = ["aria-expanded"],
    sa = [Ro("span", {
        class: "vt-hamburger-container"
    }, [Ro("span", {
        class: "vt-hamburger-top"
    }), Ro("span", {
        class: "vt-hamburger-middle"
    }), Ro("span", {
        class: "vt-hamburger-bottom"
    })], -1)],
    la = Sn({
        props: {
            active: {
                type: Boolean
            }
        },
        setup: e => (t, n) => (Eo(), Io("button", {
            type: "button",
            class: r(["vt-hamburger", {
                "is-active": e.active
            }]),
            "aria-label": "mobile navigation",
            "aria-expanded": e.active,
            "aria-controls": "VPNavScreen"
        }, sa, 10, oa))
    }),
    ia = ["href", "title", "target"],
    ra = {
        class: "visually-hidden"
    },
    aa = Sn({
        props: {
            size: null,
            icon: null,
            link: null
        },
        setup(e) {
            const t = /^[a-z]+:/i.test(e.link) ? "_blank" : void 0,
                n = {
                    discord: vi,
                    facebook: _i,
                    github: Ai,
                    linkedin: Ji,
                    slack: xr,
                    twitter: Er,
                    languages: Di
                };
            return (o, s) => (Eo(), Io("a", {
                class: r(["vt-social-link", {
                    "is-small": "small" === e.size,
                    "is-medium": "medium" === e.size
                }]),
                href: e.link,
                title: e.icon,
                target: yt(t),
                rel: "noopener noreferrer"
            }, [(Eo(), $o(ko(n[e.icon]), {
                class: "vt-social-link-icon"
            })), Ro("span", ra, u(e.icon), 1)], 10, ia))
        }
    }),
    ca = {
        class: "vt-social-links"
    },
    ua = Sn({
        props: {
            size: null,
            links: null
        },
        setup: e => (t, n) => (Eo(), Io("div", ca, [(Eo(!0), Io(_o, null, Yo(e.links, (({
            link: t,
            icon: n
        }) => (Eo(), $o(aa, {
            key: t,
            size: e.size,
            icon: n,
            link: t
        }, null, 8, ["size", "icon", "link"])))), 128))]))
    }),
    da = {
        class: "vt-switch",
        type: "button",
        role: "switch"
    },
    pa = {
        class: "vt-switch-check"
    },
    fa = {
        key: 0,
        class: "vt-switch-icon"
    };
var ha = Nl({}, [
    ["render", function (e, t) {
        return Eo(), Io("button", da, [Ro("span", pa, [e.$slots.default ? (Eo(), Io("span", fa, [Jo(e.$slots, "default")])) : Wo("", !0)])])
    }]
]);
const va = Sn({
    setup(e) {
        const t = "vue-theme-appearance",
            n = "undefined" != typeof localStorage ? function () {
                let e = localStorage.getItem(t) || "auto";
                const n = window.matchMedia("(prefers-color-scheme: dark)"),
                    o = document.documentElement.classList;
                let s = "auto" === e ? n.matches : "dark" === e;
                const l = e => o[e ? "add" : "remove"]("dark");
                n.onchange = t => {
                    "auto" === e && l(s = t.matches)
                };
                return () => {
                    l(s = !s), localStorage.setItem(t, e = s ? n.matches ? "auto" : "dark" : n.matches ? "light" : "auto")
                }
            }() : () => {};
        return (e, t) => (Eo(), $o(ha, {
            class: "vt-switch-appearance",
            "aria-label": "toggle dark mode",
            onClick: yt(n)
        }, {
            default: nn((() => [No(Sr, {
                class: "vt-switch-appearance-sun"
            }), No(fr, {
                class: "vt-switch-appearance-moon"
            })])),
            _: 1
        }, 8, ["onClick"]))
    }
});
const ma = Sn({
    name: "VitePressContent",
    setup() {
        const e = jl();
        return () => vs("div", {
            style: {
                position: "relative"
            }
        }, [e.component ? vs(e.component) : null])
    }
});
const ga = /#.*$/,
    ya = /(index)?\.(md|html)$/,
    ba = /^[a-z]+:/i;

function ka(e) {
    return /^\//.test(e) ? e : `/${e}`
}

function xa(e) {
    if (t = e, ba.test(t)) return e;
    var t;
    const {
        pathname: n,
        search: o,
        hash: s
    } = new URL(e, "http://vuejs.org");
    return Il(n.endsWith("/") || n.endsWith(".html") ? e : `${n.replace(/(\.md)?$/,".html")}${o}${s}`)
}
const wa = "undefined" != typeof window,
    _a = ht(wa ? location.hash : "");

function Ca(e, t, n = !1) {
    if (void 0 === t) return !1;
    if (e = Sa(`/${e}`), n) return new RegExp(t).test(e); {
        if (Sa(t) !== e) return !1;
        const n = t.match(ga);
        return !n || _a.value === n[0]
    }
}

function Sa(e) {
    return decodeURI(e).replace(ga, "").replace(ya, "")
}

function Ma(e, t) {
    if (Array.isArray(e)) return e;
    t = ka(t);
    for (const n in e)
        if (t.startsWith(ka(n))) return e[n];
    return []
}
wa && window.addEventListener("hashchange", (() => {
    _a.value = location.hash
}));
const Aa = Symbol("config");

function La() {
    return {
        config: un(Aa)
    }
}

function Ea(e) {
    return "link" in e ? Object.assign({}, e, {
        link: xa(e.link)
    }) : Object.assign({}, e, {
        items: e.items.map(Ea)
    })
}

function Pa(e) {
    if (Array.isArray(e)) return e.map(Ea); {
        const t = {};
        for (const n in e) t[n] = Pa(e[n]);
        return t
    }
}

function Ta() {
    const e = jl(),
        {
            config: t
        } = La(),
        {
            frontmatter: n
        } = Vl(),
        o = ht(!1),
        s = hs((() => {
            const n = t.value.sidebar,
                o = e.data.relativePath;
            return n ? Ma(n, o) : []
        })),
        l = hs((() => !1 !== n.value.sidebar && s.value.length > 0));

    function i() {
        o.value = !0
    }

    function r() {
        o.value = !1
    }
    return {
        isOpen: o,
        sidebar: s,
        hasSidebar: l,
        open: i,
        close: r,
        toggle: function () {
            o.value ? r() : i()
        }
    }
}
const Va = {},
    Ia = e => (en("data-v-5f26462c"), e = e(), tn(), e),
    $a = {
        class: "VPNavBarTitle",
        href: "/"
    },
    Ba = [Ia((() => Ro("svg", {
        class: "logo",
        viewBox: "0 0 128 128",
        width: "24",
        height: "24"
    }, [Ro("path", {
        fill: "#42b883",
        d: "M78.8,10L64,35.4L49.2,10H0l64,110l64-110C128,10,78.8,10,78.8,10z"
    }), Ro("path", {
        fill: "#35495e",
        d: "M78.8,10L64,35.4L49.2,10H25.6L64,76l38.4-66H78.8z"
    })], -1))), Ia((() => Ro("span", {
        class: "text"
    }, "Vue.js", -1)))];
var Oa = Nl(Va, [
    ["render", function (e, t) {
        return Eo(), Io("a", $a, Ba)
    }],
    ["__scopeId", "data-v-5f26462c"]
]);
const ja = {
        key: 0,
        class: "VPNavBarSearch"
    },
    Fa = {
        type: "button",
        class: "DocSearch DocSearch-Button",
        "aria-label": "Search"
    },
    za = Ro("span", {
        class: "DocSearch-Button-Container"
    }, [Ro("svg", {
        width: "20",
        height: "20",
        class: "DocSearch-Search-Icon",
        viewBox: "0 0 20 20"
    }, [Ro("path", {
        d: "M14.386 14.386l4.0877 4.0877-4.0877-4.0877c-2.9418 2.9419-7.7115 2.9419-10.6533 0-2.9419-2.9418-2.9419-7.7115 0-10.6533 2.9418-2.9419 7.7115-2.9419 10.6533 0 2.9419 2.9418 2.9419 7.7115 0 10.6533z",
        stroke: "currentColor",
        fill: "none",
        "fill-rule": "evenodd",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    })]), Ro("span", {
        class: "DocSearch-Button-Placeholder"
    }, "Search")], -1),
    Ra = {
        class: "DocSearch-Button-Keys"
    },
    Na = Ro("span", {
        class: "DocSearch-Button-Key"
    }, "K", -1),
    Ha = Sn({
        setup(e) {
            const {
                theme: t
            } = Vl(), n = An((() => import("./chunks/VPAlgoliaSearchBox.c56f801b.js"))), o = ht(!1), s = ht();

            function l() {
                o.value || (o.value = !0)
            }
            return Bn((() => {
                s.value.textContent = /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform) ? "⌘" : "Ctrl";
                const e = e => {
                        "k" === e.key && (e.ctrlKey || e.metaKey) && (e.preventDefault(), l(), t())
                    },
                    t = () => {
                        window.removeEventListener("keydown", e)
                    };
                window.addEventListener("keydown", e), Fn(t)
            })), (e, i) => yt(t).algolia ? (Eo(), Io("div", ja, [o.value ? (Eo(), $o(yt(n), {
                key: 0
            })) : (Eo(), Io("div", {
                key: 1,
                id: "docsearch",
                onClick: l
            }, [Ro("button", Fa, [za, Ro("span", Ra, [Ro("span", {
                class: "DocSearch-Button-Key",
                ref_key: "metaKey",
                ref: s
            }, "Meta", 512), Na])])]))])) : Wo("", !0)
        }
    });
var Da = Nl(Sn({
    props: {
        item: null
    },
    setup(e) {
        const {
            page: t
        } = Vl();
        return (n, o) => (Eo(), $o(yt(Wr), {
            class: r({
                VPNavBarMenuLink: !0,
                active: yt(Ca)(yt(t).relativePath, e.item.activeMatch || e.item.link, !!e.item.activeMatch)
            }),
            href: e.item.link,
            noIcon: !0
        }, {
            default: nn((() => [Do(u(e.item.text), 1)])),
            _: 1
        }, 8, ["class", "href"]))
    }
}), [
    ["__scopeId", "data-v-c1ab2038"]
]);
var Ua = Nl(Sn({
    props: {
        item: null
    },
    setup(e) {
        const {
            page: t
        } = Vl();
        return (n, o) => (Eo(), $o(yt(na), {
            class: r({
                VPNavBarMenuGroup: !0,
                active: yt(Ca)(yt(t).relativePath, e.item.activeMatch, !0)
            }),
            button: e.item.text,
            items: e.item.items
        }, null, 8, ["class", "button", "items"]))
    }
}), [
    ["__scopeId", "data-v-b598edbc"]
]);
const Wa = {
        key: 0,
        "aria-labelledby": "main-nav-aria-label",
        class: "VPNavBarMenu"
    },
    qa = (e => (en("data-v-68faa570"), e = e(), tn(), e))((() => Ro("span", {
        id: "main-nav-aria-label",
        class: "visually-hidden"
    }, "Main Navigation", -1)));
var Ga = Nl(Sn({
    setup(e) {
        const {
            config: t
        } = La();
        return (e, n) => yt(t).nav ? (Eo(), Io("nav", Wa, [qa, (Eo(!0), Io(_o, null, Yo(yt(t).nav, (e => (Eo(), Io(_o, {
            key: e.text
        }, ["link" in e ? (Eo(), $o(Da, {
            key: 0,
            item: e
        }, null, 8, ["item"])) : (Eo(), $o(Ua, {
            key: 1,
            item: e
        }, null, 8, ["item"]))], 64)))), 128))])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-68faa570"]
]);
const Ka = {
    key: 0,
    class: "VPNavBarAppearance"
};
var Za = Nl(Sn({
    setup(e) {
        const {
            config: t
        } = La();
        return (e, n) => yt(t).appearance ? (Eo(), Io("div", Ka, [No(yt(va))])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-10e6f5bd"]
]);
var Ya = Nl(Sn({
    setup(e) {
        const {
            config: t
        } = La();
        return (e, n) => yt(t).socialLinks ? (Eo(), $o(yt(ua), {
            key: 0,
            class: "VPNavBarSocialLinks",
            size: "small",
            links: yt(t).socialLinks
        }, null, 8, ["links"])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-3d7800db"]
]);
const Ja = {
        key: 0,
        class: "vt-menu-group"
    },
    Qa = {
        class: "vt-menu-item item"
    },
    Xa = (e => (en("data-v-47ed6b06"), e = e(), tn(), e))((() => Ro("p", {
        class: "vt-menu-label"
    }, "Appearance", -1))),
    ec = {
        class: "vt-menu-action action"
    },
    tc = {
        key: 1,
        class: "vt-menu-group"
    },
    nc = {
        class: "vt-menu-item item"
    };
var oc = Nl(Sn({
    setup(e) {
        const {
            config: t
        } = La(), n = hs((() => t.value.appearance || t.value.socialLinks));
        return (e, o) => yt(n) ? (Eo(), $o(yt(na), {
            key: 0,
            class: "VPNavBarExtra",
            label: "extra navigation"
        }, {
            default: nn((() => [yt(t).appearance ? (Eo(), Io("div", Ja, [Ro("div", Qa, [Xa, Ro("div", ec, [No(yt(va))])])])) : Wo("", !0), yt(t).socialLinks ? (Eo(), Io("div", tc, [Ro("div", nc, [No(yt(ua), {
                class: "social-links",
                size: "small",
                links: yt(t).socialLinks
            }, null, 8, ["links"])])])) : Wo("", !0)])),
            _: 1
        })) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-47ed6b06"]
]);
var sc = Nl(Sn({
    props: {
        active: {
            type: Boolean
        }
    },
    setup(e) {
        const {
            config: t
        } = La(), n = hs((() => t.value.appearance || t.value.socialLinks));
        return (t, o) => yt(n) ? (Eo(), $o(yt(la), {
            key: 0,
            class: "VPNavBarHamburger",
            active: e.active
        }, null, 8, ["active"])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-160e7f70"]
]);
const lc = {
        class: "VPNavBar"
    },
    ic = {
        class: "container"
    },
    rc = {
        class: "content"
    };
var ac = Nl(Sn({
    props: {
        isScreenOpen: {
            type: Boolean
        }
    },
    setup: e => (t, n) => (Eo(), Io("div", lc, [Ro("div", ic, [No(Oa), Ro("div", rc, [No(Ha, {
        class: "search"
    }), No(Ga, {
        class: "menu"
    }), No(Za, {
        class: "appearance"
    }), No(Ya, {
        class: "social-links"
    }), No(oc, {
        class: "extra"
    }), No(sc, {
        class: "hamburger",
        active: e.isScreenOpen,
        onClick: n[0] || (n[0] = e => t.$emit("toggle-screen"))
    }, null, 8, ["active"])])])]))
}), [
    ["__scopeId", "data-v-6a126dd3"]
]);
var cc = !1;
if ("undefined" != typeof window) {
    var uc = {
        get passive() {
            cc = !0
        }
    };
    window.addEventListener("testPassive", null, uc), window.removeEventListener("testPassive", null, uc)
}
var dc = "undefined" != typeof window && window.navigator && window.navigator.platform && (/iP(ad|hone|od)/.test(window.navigator.platform) || "MacIntel" === window.navigator.platform && window.navigator.maxTouchPoints > 1),
    pc = [],
    fc = !1,
    hc = -1,
    vc = void 0,
    mc = void 0,
    gc = function (e) {
        return pc.some((function (t) {
            return !(!t.options.allowTouchMove || !t.options.allowTouchMove(e))
        }))
    },
    yc = function (e) {
        var t = e || window.event;
        return !!gc(t.target) || (t.touches.length > 1 || (t.preventDefault && t.preventDefault(), !1))
    },
    bc = function (e, t) {
        if (e) {
            if (!pc.some((function (t) {
                    return t.targetElement === e
                }))) {
                var n = {
                    targetElement: e,
                    options: t || {}
                };
                pc = [].concat(function (e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                        return n
                    }
                    return Array.from(e)
                }(pc), [n]), dc ? (e.ontouchstart = function (e) {
                    1 === e.targetTouches.length && (hc = e.targetTouches[0].clientY)
                }, e.ontouchmove = function (t) {
                    1 === t.targetTouches.length && function (e, t) {
                        var n = e.targetTouches[0].clientY - hc;
                        !gc(e.target) && (t && 0 === t.scrollTop && n > 0 || function (e) {
                            return !!e && e.scrollHeight - e.scrollTop <= e.clientHeight
                        }(t) && n < 0 ? yc(e) : e.stopPropagation())
                    }(t, e)
                }, fc || (document.addEventListener("touchmove", yc, cc ? {
                    passive: !1
                } : void 0), fc = !0)) : function (e) {
                    if (void 0 === mc) {
                        var t = !!e && !0 === e.reserveScrollBarGap,
                            n = window.innerWidth - document.documentElement.clientWidth;
                        t && n > 0 && (mc = document.body.style.paddingRight, document.body.style.paddingRight = n + "px")
                    }
                    void 0 === vc && (vc = document.body.style.overflow, document.body.style.overflow = "hidden")
                }(t)
            }
        } else console.error("disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices.")
    },
    kc = function () {
        dc ? (pc.forEach((function (e) {
            e.targetElement.ontouchstart = null, e.targetElement.ontouchmove = null
        })), fc && (document.removeEventListener("touchmove", yc, cc ? {
            passive: !1
        } : void 0), fc = !1), hc = -1) : (void 0 !== mc && (document.body.style.paddingRight = mc, mc = void 0), void 0 !== vc && (document.body.style.overflow = vc, vc = void 0)), pc = []
    };
var xc = Nl(Sn({
    props: {
        text: null,
        link: null
    },
    setup(e) {
        const t = un("close-screen");
        return (n, o) => (Eo(), $o(yt(Wr), {
            class: "VPNavScreenMenuLink",
            href: e.link,
            onClick: yt(t)
        }, {
            default: nn((() => [Do(u(e.text), 1)])),
            _: 1
        }, 8, ["href", "onClick"]))
    }
}), [
    ["__scopeId", "data-v-3fd32423"]
]);
var wc = Nl(Sn({
    props: {
        text: null,
        link: null
    },
    setup(e) {
        const t = un("close-screen");
        return (n, o) => (Eo(), $o(yt(Wr), {
            class: "VPNavScreenMenuGroupLink",
            href: e.link,
            onClick: yt(t)
        }, {
            default: nn((() => [Do(u(e.text), 1)])),
            _: 1
        }, 8, ["href", "onClick"]))
    }
}), [
    ["__scopeId", "data-v-7d9d92c0"]
]);
const _c = {
        class: "VPNavScreenMenuGroupSection"
    },
    Cc = {
        key: 0,
        class: "title"
    };
var Sc = Nl(Sn({
    props: {
        text: null,
        items: null
    },
    setup: e => (t, n) => (Eo(), Io("div", _c, [e.text ? (Eo(), Io("p", Cc, u(e.text), 1)) : Wo("", !0), (Eo(!0), Io(_o, null, Yo(e.items, (e => (Eo(), $o(wc, {
        key: e.text,
        text: e.text,
        link: e.link
    }, null, 8, ["text", "link"])))), 128))]))
}), [
    ["__scopeId", "data-v-360485c7"]
]);
const Mc = ["aria-controls", "aria-expanded"],
    Ac = {
        class: "button-text"
    },
    Lc = ["id"],
    Ec = {
        key: 1,
        class: "group"
    };
var Pc = Nl(Sn({
    props: {
        text: null,
        items: null
    },
    setup(e) {
        const t = e,
            n = ht(!1),
            o = hs((() => `NavScreenGroup-${t.text.replace(" ","-").toLowerCase()}`));

        function s() {
            n.value = !n.value
        }
        return (t, l) => (Eo(), Io("div", {
            class: r(["VPNavScreenMenuGroup", {
                open: n.value
            }])
        }, [Ro("button", {
            class: "button",
            "aria-controls": yt(o),
            "aria-expanded": n.value,
            onClick: s
        }, [Ro("span", Ac, u(e.text), 1), No(yt(gr), {
            class: "button-icon"
        })], 8, Mc), Ro("div", {
            id: yt(o),
            class: "items"
        }, [(Eo(!0), Io(_o, null, Yo(e.items, (e => (Eo(), Io(_o, {
            key: e.text
        }, ["link" in e ? (Eo(), Io("div", {
            key: e.text,
            class: "item"
        }, [No(wc, {
            text: e.text,
            link: e.link
        }, null, 8, ["text", "link"])])) : (Eo(), Io("div", Ec, [No(Sc, {
            text: e.text,
            items: e.items
        }, null, 8, ["text", "items"])]))], 64)))), 128))], 8, Lc)], 2))
    }
}), [
    ["__scopeId", "data-v-d231d4fc"]
]);
const Tc = {
        key: 0,
        class: "VPNavScreenMenu"
    },
    Vc = Sn({
        setup(e) {
            const {
                config: t
            } = La();
            return (e, n) => yt(t).nav ? (Eo(), Io("nav", Tc, [(Eo(!0), Io(_o, null, Yo(yt(t).nav, (e => (Eo(), Io(_o, {
                key: e.text
            }, ["link" in e ? (Eo(), $o(xc, {
                key: 0,
                text: e.text,
                link: e.link
            }, null, 8, ["text", "link"])) : (Eo(), $o(Pc, {
                key: 1,
                text: e.text || "",
                items: e.items
            }, null, 8, ["text", "items"]))], 64)))), 128))])) : Wo("", !0)
        }
    });
const Ic = {
        key: 0,
        class: "VPNavScreenAppearance"
    },
    $c = (e => (en("data-v-ad370484"), e = e(), tn(), e))((() => Ro("p", {
        class: "text"
    }, "Appearance", -1)));
var Bc = Nl(Sn({
    setup(e) {
        const {
            config: t
        } = La();
        return (e, n) => yt(t).appearance ? (Eo(), Io("div", Ic, [$c, No(yt(va))])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-ad370484"]
]);
const Oc = Sn({
    setup(e) {
        const {
            config: t
        } = La();
        return (e, n) => yt(t).socialLinks ? (Eo(), $o(yt(ua), {
            key: 0,
            class: "VPNavScreenSocialLinks",
            size: "medium",
            links: yt(t).socialLinks
        }, null, 8, ["links"])) : Wo("", !0)
    }
});
const jc = {
    class: "container"
};
var Fc = Nl(Sn({
    props: {
        open: {
            type: Boolean
        }
    },
    setup(e) {
        const t = ht(null);

        function n() {
            bc(t.value, {
                reserveScrollBarGap: !0
            })
        }

        function o() {
            kc()
        }
        return (s, l) => (Eo(), $o($s, {
            name: "fade",
            onEnter: n,
            onAfterLeave: o
        }, {
            default: nn((() => [e.open ? (Eo(), Io("div", {
                key: 0,
                class: "VPNavScreen",
                ref_key: "screen",
                ref: t
            }, [Ro("div", jc, [No(Vc, {
                class: "menu"
            }), No(Bc, {
                class: "appearance"
            }), No(Oc, {
                class: "social-links"
            })])], 512)) : Wo("", !0)])),
            _: 1
        }))
    }
}), [
    ["__scopeId", "data-v-6364a567"]
]);
var zc = Nl(Sn({
    setup(e) {
        const {
            isScreenOpen: t,
            closeScreen: n,
            toggleScreen: o
        } = function () {
            const e = ht(!1);

            function t() {
                e.value = !0, window.addEventListener("resize", o)
            }

            function n() {
                e.value = !1, window.removeEventListener("resize", o)
            }

            function o() {
                window.outerWidth >= 768 && n()
            }
            return {
                isScreenOpen: e,
                openScreen: t,
                closeScreen: n,
                toggleScreen: function () {
                    e.value ? n() : t()
                }
            }
        }(), {
            hasSidebar: s
        } = Ta();
        return cn("close-screen", n), (e, n) => (Eo(), Io("header", {
            class: r(["VPNav nav-bar", {
                stick: !yt(s)
            }])
        }, [No(ac, {
            "is-screen-open": yt(t),
            onToggleScreen: yt(o)
        }, null, 8, ["is-screen-open", "onToggleScreen"]), No(Fc, {
            open: yt(t)
        }, null, 8, ["open"])], 2))
    }
}), [
    ["__scopeId", "data-v-01dbeacc"]
]);
const Rc = {
        key: 0,
        class: "VPLocalNav"
    },
    Nc = ["aria-expanded"],
    Hc = (e => (en("data-v-27012588"), e = e(), tn(), e))((() => Ro("span", {
        class: "menu-text"
    }, "Menu", -1)));
var Dc = Nl(Sn({
    props: {
        open: {
            type: Boolean
        }
    },
    setup(e) {
        const {
            hasSidebar: t
        } = Ta(), {
            frontmatter: n
        } = Vl();

        function o() {
            window.scrollTo({
                top: 0,
                left: 0,
                behavior: "smooth"
            })
        }
        return (s, l) => yt(t) ? (Eo(), Io("div", Rc, [Ro("button", {
            class: "menu",
            "aria-expanded": e.open,
            "aria-controls": "VPSidebarNav",
            onClick: l[0] || (l[0] = e => s.$emit("open-menu"))
        }, [No(yt(Wl), {
            class: "menu-icon"
        }), Hc], 8, Nc), !1 !== yt(n).returnToTop ? (Eo(), Io("a", {
            key: 0,
            class: "top-link",
            href: "#",
            onClick: o
        }, "Return to top")) : Wo("", !0)])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-27012588"]
]);
var Uc = Nl(Sn({
    setup(e) {
        const t = jl(),
            n = ht();
        fn((() => t.path), (() => n.value.focus()));
        const o = ({
            target: e
        }) => {
            const t = document.querySelector(e.hash);
            if (t) {
                const e = () => {
                    t.removeAttribute("tabindex"), t.removeEventListener("blur", e)
                };
                t.setAttribute("tabindex", "-1"), t.addEventListener("blur", e), t.focus(), window.scrollTo(0, 0)
            }
        };
        return (e, t) => (Eo(), Io(_o, null, [Ro("span", {
            ref_key: "backToTop",
            ref: n,
            tabindex: "-1"
        }, null, 512), Ro("a", {
            href: "#VPContent",
            class: "VPSkipLink visually-hidden",
            onClick: o
        }, " Skip to content ")], 64))
    }
}), [
    ["__scopeId", "data-v-4f742274"]
]);
const Wc = {
        class: "visually-hidden",
        "aria-live": "polite"
    },
    qc = Sn({
        setup(e) {
            const {
                page: t
            } = Vl();
            return (e, n) => (Eo(), Io("div", Wc, u(yt(t).title) + " has loaded", 1))
        }
    });
const Gc = ["href"],
    Kc = {
        class: "link-text"
    };
var Zc = Nl(Sn({
    props: {
        item: null
    },
    setup(e) {
        const {
            page: t
        } = Vl(), n = un("close-sidebar");
        return (o, s) => (Eo(), Io("a", {
            class: r({
                link: !0,
                active: yt(Ca)(yt(t).relativePath, e.item.link)
            }),
            href: e.item.link,
            onClick: s[0] || (s[0] = (...e) => yt(n) && yt(n)(...e))
        }, [Ro("p", Kc, u(e.item.text), 1)], 10, Gc))
    }
}), [
    ["__scopeId", "data-v-9ad74656"]
]);
const Yc = {
        class: "VPSidebarGroup"
    },
    Jc = {
        class: "title"
    };
var Qc = Nl(Sn({
    props: {
        text: null,
        items: null
    },
    setup(e) {
        const t = e,
            {
                page: n
            } = Vl();

        function o() {
            const {
                relativePath: e
            } = n.value;
            return t.items.some((t => Ca(e, t.link)))
        }
        return (t, n) => (Eo(), Io("section", Yc, [Ro("div", Jc, [Ro("h2", {
            class: r(["title-text", {
                active: o()
            }])
        }, u(e.text), 3)]), (Eo(!0), Io(_o, null, Yo(e.items, (e => (Eo(), $o(Zc, {
            key: e.link,
            item: e
        }, null, 8, ["item"])))), 128))]))
    }
}), [
    ["__scopeId", "data-v-39795b07"]
]);
const Xc = {
        id: "VPSidebarNav",
        "aria-labelledby": "sidebar-aria-label",
        tabindex: "-1"
    },
    eu = (e => (en("data-v-305c183a"), e = e(), tn(), e))((() => Ro("span", {
        id: "sidebar-aria-label",
        class: "visually-hidden"
    }, "Sidebar Navigation", -1)));
var tu = Nl(Sn({
    props: {
        open: {
            type: Boolean
        }
    },
    setup(e) {
        const t = e,
            {
                sidebar: n,
                hasSidebar: o
            } = Ta();
        let s = ht(null);
        return hn((async () => {
            var e;
            t.open && (await Rt(), null == (e = s.value) || e.focus())
        }), null, {
            flush: "post"
        }), (t, l) => yt(o) ? (Eo(), Io("aside", {
            key: 0,
            ref_key: "navEl",
            ref: s,
            class: r(["VPSidebar", {
                open: e.open
            }]),
            onClick: l[0] || (l[0] = vl((() => {}), ["stop"]))
        }, [Ro("nav", Xc, [Jo(t.$slots, "top", {}, void 0, !0), eu, (Eo(!0), Io(_o, null, Yo(yt(n), (e => (Eo(), Io("div", {
            key: e.text,
            class: "group"
        }, [No(Qc, {
            text: e.text,
            items: e.items
        }, null, 8, ["text", "items"])])))), 128)), Jo(t.$slots, "bottom", {}, void 0, !0)])], 2)) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-305c183a"]
]);
const nu = {
        class: "VPFooter"
    },
    ou = {
        key: 0,
        class: "license"
    },
    su = Do(" Released under the "),
    lu = Do(". "),
    iu = {
        key: 1,
        class: "copyright"
    };
var ru = Nl(Sn({
    setup(e) {
        const {
            theme: t
        } = Vl();
        return (e, n) => {
            var o, s;
            return Eo(), Io("div", nu, [(null == (o = yt(t).footer) ? void 0 : o.license) ? (Eo(), Io("p", ou, [su, No(yt(Wr), {
                class: "link",
                href: yt(t).footer.license.link,
                "no-icon": ""
            }, {
                default: nn((() => [Do(u(yt(t).footer.license.text), 1)])),
                _: 1
            }, 8, ["href"]), lu])) : Wo("", !0), (null == (s = yt(t).footer) ? void 0 : s.copyright) ? (Eo(), Io("p", iu, u(yt(t).footer.copyright), 1)) : Wo("", !0)])
        }
    }
}), [
    ["__scopeId", "data-v-111e6896"]
]);
const au = {
        class: "VPContentPage"
    },
    cu = Sn({
        setup(e) {
            const {
                frontmatter: t
            } = Vl();
            return (e, n) => {
                const o = yo("Content");
                return Eo(), Io("div", au, [Ro("main", null, [No(o)]), Jo(e.$slots, "footer-before"), !1 !== yt(t).footer ? (Eo(), $o(ru, {
                    key: 0
                })) : Wo("", !0), Jo(e.$slots, "footer-after")])
            }
        }
    });

function uu(e) {
    return !!Z && (function (e) {
        Z && Z.cleanups.push(e)
    }(e), !0)
}
const du = "undefined" != typeof window;
const pu = du ? window : void 0;

function fu(e, t = {}) {
    const {
        window: n = pu
    } = t;
    let o;
    const s = ht(!1),
        l = () => {
            n && (o || (o = n.matchMedia(e)), s.value = o.matches)
        };
    return function (e, t = !0) {
        ls() ? Bn(e) : t ? e() : Rt(e)
    }((() => {
        l(), o && ("addEventListener" in o ? o.addEventListener("change", l) : o.addListener(l), uu((() => {
            "removeEventListener" in l ? o.removeEventListener("change", l) : o.removeListener(l)
        })))
    })), s
}
var hu, vu;
du && window.document, du && window.navigator, du && window.location, du && (null == window ? void 0 : window.navigator) && (null == (hu = null == window ? void 0 : window.navigator) ? void 0 : hu.platform) && /iP(ad|hone|od)/.test(null == (vu = null == window ? void 0 : window.navigator) ? void 0 : vu.platform);
var mu = Object.defineProperty,
    gu = Object.getOwnPropertySymbols,
    yu = Object.prototype.hasOwnProperty,
    bu = Object.prototype.propertyIsEnumerable,
    ku = (e, t, n) => t in e ? mu(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n;

function xu(e) {
    return wu(function (e) {
        let t;
        e = e.map((e => Object.assign({}, e)));
        for (const n of e) 2 === n.level ? t = n : t && n.level <= 3 && (t.children || (t.children = [])).push(n);
        return e.filter((e => 2 === e.level))
    }(e))
}

function wu(e) {
    return e.map((e => ({
        text: e.title,
        link: `#${e.slug}`,
        children: e.children ? wu(e.children) : void 0,
        hidden: e.hidden
    })))
}

function _u(e, t) {
    const n = fu("(min-width: 1280px)"),
        o = function (e, t) {
            let n, o = !1;
            return () => {
                n && clearTimeout(n), o ? n = setTimeout(e, t) : (e(), o = !0, setTimeout((() => {
                    o = !1
                }), t))
            }
        }(s, 100);

    function s() {
        if (!n.value) return;
        const t = [].slice.call(e.value.querySelectorAll(".outline-link")),
            o = [].slice.call(document.querySelectorAll(".content .header-anchor")).filter((e => t.some((t => t.hash === e.hash))));
        if (o.length && window.scrollY + window.innerHeight === document.body.offsetHeight) i(o[o.length - 1].hash);
        else
            for (let e = 0; e < o.length; e++) {
                const t = o[e],
                    n = o[e + 1],
                    [s, l] = Su(e, t, n);
                if (s) return history.replaceState(null, document.title, l || " "), void i(l)
            }
    }
    let l = null;

    function i(n) {
        l && l.classList.remove("active");
        const o = l = null == n ? null : e.value.querySelector(`a[href="${decodeURIComponent(n)}"]`);
        o ? (o.classList.add("active"), t.value.style.opacity = "1", t.value.style.top = o.offsetTop + 33 + "px") : (t.value.style.opacity = "0", t.value.style.top = "33px")
    }
    Bn((() => {
        requestAnimationFrame(s), window.addEventListener("scroll", o)
    })), On((() => {
        i(location.hash)
    })), Fn((() => {
        window.removeEventListener("scroll", o)
    }))
}((e, t) => {
    for (var n in t || (t = {})) yu.call(t, n) && ku(e, n, t[n]);
    if (gu)
        for (var n of gu(t)) bu.call(t, n) && ku(e, n, t[n])
})({
    text: ""
}, {
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    height: 0,
    width: 0
});

function Cu(e) {
    return e.parentElement.offsetTop - 56 - 15
}

function Su(e, t, n) {
    const o = window.scrollY;
    return 0 === e && 0 === o ? [!0, null] : o < Cu(t) ? [!1, null] : !n || o < Cu(n) ? [!0, t.hash] : [!1, null]
}
const Mu = e => (en("data-v-a843c894"), e = e(), tn(), e),
    Au = Mu((() => Ro("div", {
        class: "outline-title"
    }, "On this page", -1))),
    Lu = {
        "aria-labelledby": "doc-outline-aria-label"
    },
    Eu = Mu((() => Ro("span", {
        id: "doc-outline-aria-label",
        class: "visually-hidden"
    }, "Table of Contents for current page", -1))),
    Pu = {
        class: "root"
    },
    Tu = ["href"],
    Vu = {
        key: 0
    },
    Iu = ["href"];
var $u = Nl(Sn({
    setup(e) {
        const {
            page: t,
            frontmatter: n
        } = Vl(), o = ht(), s = ht();
        _u(o, s);
        const l = un("filter-headers", null),
            i = hs((() => l ? t.value.headers.map((e => l(e) ? e : Object.assign({}, e, {
                hidden: !0
            }))) : t.value.headers)),
            r = ({
                target: e
            }) => {
                const t = "#" + e.href.split("#")[1],
                    n = document.querySelector(t);
                null == n || n.focus()
            };
        return (e, t) => (Eo(), Io("div", {
            class: "VPContentDocOutline",
            ref_key: "container",
            ref: o
        }, [Ro("div", {
            class: "outline-marker",
            ref_key: "marker",
            ref: s
        }, null, 512), Au, Ro("nav", Lu, [Eu, Ro("ul", Pu, [(Eo(!0), Io(_o, null, Yo(yt(xu)(yt(i)), (({
            text: e,
            link: t,
            children: o,
            hidden: s
        }) => Qn((Eo(), Io("li", null, [Ro("a", {
            class: "outline-link",
            href: t,
            onClick: r
        }, u(e), 9, Tu), o && "deep" === yt(n).outline ? (Eo(), Io("ul", Vu, [(Eo(!0), Io(_o, null, Yo(o, (({
            text: e,
            link: t,
            hidden: n
        }) => Qn((Eo(), Io("li", null, [Ro("a", {
            class: "outline-link nested",
            href: t,
            onClick: r
        }, u(e), 9, Iu)], 512)), [
            [yl, !n]
        ]))), 256))])) : Wo("", !0)], 512)), [
            [yl, !s]
        ]))), 256))])])], 512))
    }
}), [
    ["__scopeId", "data-v-a843c894"]
]);
const Bu = {
        key: 0,
        class: "VPContentDocFooter"
    },
    Ou = ["href"],
    ju = {
        class: "desc"
    },
    Fu = Do(" Previous"),
    zu = {
        class: "title"
    },
    Ru = ["href"],
    Nu = {
        class: "desc"
    },
    Hu = Do("Next "),
    Du = {
        class: "title"
    };
var Uu = Nl(Sn({
    setup(e) {
        const {
            page: t,
            theme: n
        } = Vl(), o = hs((() => {
            const e = function (e) {
                    const t = [];
                    for (const n of e)
                        for (const e of n.items) t.push(e);
                    return t
                }(Ma(n.value.sidebar, t.value.relativePath)),
                o = e.findIndex((e => Ca(t.value.relativePath, e.link)));
            return {
                prev: e[o - 1],
                next: e[o + 1]
            }
        }));
        return (e, t) => yt(o).prev || yt(o).next ? (Eo(), Io("footer", Bu, [yt(o).prev ? (Eo(), Io("a", {
            key: 0,
            class: "prev-link",
            href: yt(xa)(yt(o).prev.link)
        }, [Ro("span", ju, [No(yt(ri), {
            class: "vt-link-icon"
        }), Fu]), Ro("span", zu, u(yt(o).prev.text), 1)], 8, Ou)) : Wo("", !0), yt(o).next ? (Eo(), Io("a", {
            key: 1,
            class: "next-link",
            href: yt(xa)(yt(o).next.link)
        }, [Ro("span", Nu, [Hu, No(yt(di), {
            class: "vt-link-icon"
        })]), Ro("span", Du, u(yt(o).next.text), 1)], 8, Ru)) : Wo("", !0)])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-26eee970"]
]);
const Wu = Sn({
    setup(e) {
        const {
            theme: t
        } = Vl(), n = t.value.carbonAds, o = ht(), s = fu("(min-width: 1280px)");
        let l = !1;

        function i() {
            if (!l) {
                l = !0;
                const e = document.createElement("script");
                e.id = "_carbonads_js", e.src = `//cdn.carbonads.com/carbon.js?serve=${n.code}&placement=${n.placement}`, e.async = !0, o.value.appendChild(e)
            }
        }
        return n && Bn((() => {
            s.value ? i() : fn(s, (e => e && i()))
        })), (e, t) => (Eo(), Io("div", {
            class: "VPCarbonAds",
            ref_key: "container",
            ref: o
        }, null, 512))
    }
});
const qu = {
        class: "container"
    },
    Gu = {
        key: 0,
        class: "aside"
    },
    Ku = {
        class: "aside-container"
    },
    Zu = {
        class: "content"
    },
    Yu = {
        key: 0,
        class: "edit-link"
    };
var Ju = Nl(Sn({
    setup(e) {
        const {
            page: t,
            frontmatter: n,
            theme: o
        } = Vl(), s = /#(\w+)$/, l = hs((() => {
            var e, n;
            return `https://github.com/vuejs/docs/edit/${(null==(n=((null==(e=o.value.editLink)?void 0:e.repo)||"vuejs/docs").match(s))?void 0:n[1])||"main"}/src/${t.value.relativePath}`
        })), i = hs((() => {
            const {
                relativePath: e
            } = t.value;
            return e.slice(0, e.indexOf("/"))
        }));
        return (e, s) => {
            const a = yo("Content");
            return Eo(), Io("div", {
                class: r(["VPContentDoc", {
                    "has-aside": !1 !== yt(n).aside
                }])
            }, [Ro("div", qu, [!1 !== yt(n).aside ? (Eo(), Io("div", Gu, [Ro("div", Ku, [Jo(e.$slots, "aside-top", {}, void 0, !0), yt(t).headers && !1 !== yt(n).outline ? (Eo(), $o($u, {
                key: 0
            })) : Wo("", !0), Jo(e.$slots, "aside-mid", {}, void 0, !0), yt(o).carbonAds && !1 !== yt(n).ads ? (Eo(), $o(Wu, {
                key: 1
            })) : Wo("", !0), Jo(e.$slots, "aside-bottom", {}, void 0, !0)])])) : Wo("", !0), Ro("div", Zu, [Jo(e.$slots, "content-top", {}, void 0, !0), Ro("main", null, [No(a, {
                class: r(["vt-doc", yt(i)])
            }, null, 8, ["class"]), yt(o).editLink && !1 !== yt(n).editLink ? (Eo(), Io("p", Yu, [No(yt(jr), {
                class: "vt-icon"
            }), No(yt(Wr), {
                href: yt(l),
                "no-icon": !0
            }, {
                default: nn((() => [Do(u(yt(o).editLink.text), 1)])),
                _: 1
            }, 8, ["href"])])) : Wo("", !0)]), Jo(e.$slots, "content-bottom", {}, void 0, !0), !1 !== yt(n).footer ? (Eo(), $o(Uu, {
                key: 0
            })) : Wo("", !0)])])], 2)
        }
    }
}), [
    ["__scopeId", "data-v-7d3b0a72"]
]);
const Qu = e => (en("data-v-e329ed34"), e = e(), tn(), e),
    Xu = {
        class: "vt-doc"
    },
    ed = Qu((() => Ro("h1", null, "Page Not Found", -1))),
    td = Do(" You found a dead link: "),
    nd = {
        class: "not-found-path"
    },
    od = Qu((() => Ro("br", null, null, -1))),
    sd = {
        key: 0
    },
    ld = Do("Please "),
    id = ["href"],
    rd = Do(" so we can fix it.");
var ad = Nl(Sn({
    setup(e) {
        const {
            theme: t
        } = Vl(), n = jl();
        return (e, o) => (Eo(), Io("div", Xu, [ed, Ro("p", null, [td, Ro("span", nd, u(yt(n).path), 1), od, yt(t).repo ? (Eo(), Io("span", sd, [ld, Ro("a", {
            href: `https://github.com/${yt(t).repo}`,
            target: "_blank"
        }, "let us know", 8, id), rd])) : Wo("", !0)])]))
    }
}), [
    ["__scopeId", "data-v-e329ed34"]
]);
const cd = Do("\\ ");
var ud = Nl(Sn({
    setup(e) {
        const t = jl(),
            {
                frontmatter: n
            } = Vl(),
            {
                hasSidebar: o
            } = Ta();
        return (e, s) => (Eo(), Io("div", {
            id: "VPContent",
            class: r(["VPContent", {
                "has-sidebar": yt(o)
            }])
        }, [yt(t).component === ad ? (Eo(), $o(ad, {
            key: 0
        })) : yt(n).page ? (Eo(), $o(cu, {
            key: 1
        }, {
            "footer-before": nn((() => [Jo(e.$slots, "footer-before", {}, void 0, !0)])),
            "footer-after": nn((() => [Jo(e.$slots, "footer-after", {}, void 0, !0)])),
            _: 3
        })) : (Eo(), $o(Ju, {
            key: 2,
            class: r({
                "has-sidebar": yt(o)
            })
        }, {
            "content-top": nn((() => [Jo(e.$slots, "content-top", {}, void 0, !0)])),
            "content-bottom": nn((() => [Jo(e.$slots, "content-bottom", {}, void 0, !0)])),
            "aside-top": nn((() => [Jo(e.$slots, "aside-top", {}, void 0, !0)])),
            "aside-mid": nn((() => [Jo(e.$slots, "aside-mid", {}, void 0, !0)])),
            "aside-bottom": nn((() => [Jo(e.$slots, "aside-bottom", {}, void 0, !0)])),
            default: nn((() => [cd])),
            _: 3
        }, 8, ["class"]))], 2))
    }
}), [
    ["__scopeId", "data-v-f56f3cfe"]
]);
const dd = {
    class: "VPApp"
};
const pd = {
    Layout: (fd = Nl(Sn({
        setup(e) {
            const {
                isOpen: t,
                open: n,
                close: o
            } = Ta();
            let s;
            dn((() => {
                s = t.value ? document.activeElement : void 0
            }));
            const l = e => {
                "Escape" === e.key && t.value && (o(), null == s || s.focus())
            };
            return Bn((() => {
                window.addEventListener("keyup", l)
            })), Fn((() => {
                window.removeEventListener("keyup", l)
            })), cn("close-sidebar", o), (e, s) => (Eo(), Io("div", dd, [No(Uc), No(yt(zr), {
                class: "backdrop",
                show: yt(t),
                onClick: yt(o)
            }, null, 8, ["show", "onClick"]), Jo(e.$slots, "banner", {}, void 0, !0), No(zc), No(Dc, {
                open: yt(t),
                onOpenMenu: yt(n)
            }, null, 8, ["open", "onOpenMenu"]), No(tu, {
                open: yt(t)
            }, {
                top: nn((() => [Jo(e.$slots, "sidebar-top", {}, void 0, !0)])),
                bottom: nn((() => [Jo(e.$slots, "sidebar-bottom", {}, void 0, !0)])),
                _: 3
            }, 8, ["open"]), No(ud, null, {
                "content-top": nn((() => [Jo(e.$slots, "content-top", {}, void 0, !0)])),
                "content-bottom": nn((() => [Jo(e.$slots, "content-bottom", {}, void 0, !0)])),
                "aside-top": nn((() => [Jo(e.$slots, "aside-top", {}, void 0, !0)])),
                "aside-mid": nn((() => [Jo(e.$slots, "aside-mid", {}, void 0, !0)])),
                "aside-bottom": nn((() => [Jo(e.$slots, "aside-bottom", {}, void 0, !0)])),
                "footer-before": nn((() => [Jo(e.$slots, "footer-before", {}, void 0, !0)])),
                "footer-after": nn((() => [Jo(e.$slots, "footer-after", {}, void 0, !0)])),
                _: 3
            }), No(qc)]))
        }
    }), [
        ["__scopeId", "data-v-204468d7"]
    ]), Sn({
        name: "VPConfigProvider",
        setup(e, {
            slots: t
        }) {
            const {
                theme: n
            } = Vl(), o = hs((() => function (e) {
                var t;
                return Object.assign({
                    appearance: !0
                }, e, {
                    nav: null == (t = e.nav) ? void 0 : t.map(Ea),
                    sidebar: e.sidebar && Pa(e.sidebar)
                })
            }(n.value)));
            return cn(Aa, o), () => vs(fd, null, t)
        }
    })),
    NotFound: ad
};
var fd;
const hd = e => (en("data-v-7b6b3f89"), e = e(), tn(), e),
    vd = {
        key: 0,
        class: "banner"
    },
    md = [Do(" Vue 3 is now the new default version! "), hd((() => Ro("a", {
        href: "https://blog.vuejs.org/posts/vue-3-as-the-new-default.html",
        target: "_blank"
    }, "Learn more", -1)))];
var gd = Nl({
    setup(e) {
        let t = ht(!0);
        return (e, n) => t.value ? (Eo(), Io("div", vd, md)) : Wo("", !0)
    }
}, [
    ["__scopeId", "data-v-7b6b3f89"]
]);
const yd = "undefined" != typeof localStorage,
    bd = (e, t = !1) => yd ? JSON.parse(localStorage.getItem(e) || String(t)) : t,
    kd = ht(bd("vue-docs-prefer-composition")),
    xd = ht(bd("vue-docs-prefer-sfc", !0));

function wd(e) {
    return kd.value ? !e.optionsOnly : !e.compositionOnly
}
const _d = {
        key: 0,
        class: "preference-switch"
    },
    Cd = ["aria-expanded"],
    Sd = (e => (en("data-v-ea271328"), e = e(), tn(), e))((() => Ro("span", null, "API Preference", -1))),
    Md = ["hidden", "aria-hidden"],
    Ad = {
        class: "switch-container"
    },
    Ld = {
        key: 0,
        class: "switch-container"
    };
var Ed = Nl(Sn({
    setup(e) {
        const t = jl(),
            n = hs((() => /^\/(guide|tutorial|examples)\//.test(t.path))),
            o = hs((() => !/^\/guide/.test(t.path)));
        let s = ht(!0);
        const l = () => {
                s.value = !s.value
            },
            i = e => {
                e.target.classList.add("no-outline")
            },
            a = e => {
                e.target.classList.remove("no-outline")
            },
            c = p("vue-docs-prefer-composition", kd, "prefer-composition"),
            u = p("vue-docs-prefer-sfc", xd, "prefer-sfc"),
            d = un("close-sidebar");

        function p(e, t, n) {
            if ("undefined" == typeof localStorage) return () => {};
            const o = document.documentElement.classList;
            return (s = !t.value) => {
                (t.value = s) ? o.add(n): o.remove(n), localStorage.setItem(e, String(t.value))
            }
        }
        return (e, t) => n.value ? (Eo(), Io("div", _d, [Ro("button", {
            class: "toggle",
            "aria-label": "preference switches toggle",
            "aria-controls": "preference-switches",
            "aria-expanded": s.value,
            onClick: l,
            onMousedown: i,
            onBlur: a
        }, [Sd, No(yt(oi), {
            class: r(["vt-link-icon", {
                open: s.value
            }])
        }, null, 8, ["class"])], 40, Cd), Ro("div", {
            id: "preference-switches",
            hidden: !s.value,
            "aria-hidden": !s.value
        }, [Ro("div", Ad, [Ro("label", {
            class: "options-label",
            onClick: t[0] || (t[0] = e => yt(c)(!1))
        }, "Options"), No(yt(ha), {
            class: "api-switch",
            "aria-label": "prefer composition api",
            "aria-checked": yt(kd),
            onClick: t[1] || (t[1] = e => yt(c)())
        }, null, 8, ["aria-checked"]), Ro("label", {
            class: "composition-label",
            onClick: t[2] || (t[2] = e => yt(c)(!0))
        }, "Composition"), Ro("a", {
            class: "switch-link",
            title: "About API preference",
            href: "/guide/introduction.html#api-styles",
            onClick: t[3] || (t[3] = (...e) => yt(d) && yt(d)(...e))
        }, "?")]), o.value ? (Eo(), Io("div", Ld, [Ro("label", {
            class: "no-sfc-label",
            onClick: t[4] || (t[4] = e => yt(u)(!1))
        }, "HTML"), No(yt(ha), {
            class: "sfc-switch",
            "aria-label": "prefer single file component",
            "aria-checked": yt(xd),
            onClick: t[5] || (t[5] = e => yt(u)())
        }, null, 8, ["aria-checked"]), Ro("label", {
            class: "sfc-label",
            onClick: t[6] || (t[6] = e => yt(u)(!0))
        }, "SFC"), Ro("a", {
            class: "switch-link",
            title: "About SFC",
            href: "/guide/scaling-up/sfc.html",
            onClick: t[7] || (t[7] = (...e) => yt(d) && yt(d)(...e))
        }, "?")])) : Wo("", !0)], 8, Md)])) : Wo("", !0)
    }
}), [
    ["__scopeId", "data-v-ea271328"]
]);
const Pd = {
        props: {
            href: {
                type: String,
                required: !0
            },
            title: {
                type: String,
                required: !0
            }
        }
    },
    Td = {
        class: "vueschool"
    },
    Vd = ["href", "title"],
    Id = Do("Watch a free video lesson on Vue School");
var $d = Nl(Pd, [
    ["render", function (e, t, n, o, s, l) {
        return Eo(), Io("div", Td, [Ro("a", {
            href: `${n.href}?friend=vuejs`,
            target: "_blank",
            rel: "sponsored noopener",
            title: n.title
        }, [Jo(e.$slots, "default", {}, (() => [Id]), !0)], 8, Vd)])
    }],
    ["__scopeId", "data-v-50eeed65"]
]);
const Bd = ["href"],
    Od = {
        key: 0
    },
    jd = ["srcset"],
    Fd = ["src", "alt"],
    zd = ["src", "alt"],
    Rd = {
        key: 1,
        href: "/sponsor/",
        class: "sponsor-item action"
    };
let Nd = ht(),
    Hd = !1;
const Dd = "https://sponsors.vuejs.org";
var Ud = Nl(Sn({
    props: {
        tier: null,
        placement: {
            default: "aside"
        }
    },
    setup(e) {
        let t = ht(),
            n = ht(!1);
        return Bn((async () => {
            const e = new IntersectionObserver((t => {
                t[0].isIntersecting && (n.value = !0, e.disconnect())
            }), {
                rootMargin: "0px 0px 300px 0px"
            });
            e.observe(t.value), Fn((() => e.disconnect())), Hd || (Hd = !0, Nd.value = await (await fetch(`${Dd}/data.json`)).json())
        })), (o, s) => (Eo(), Io("div", {
            ref_key: "container",
            ref: t,
            class: r(["sponsor-container", [e.tier.startsWith("plat") ? "platinum" : e.tier, e.placement]])
        }, [Nd.value && n.value ? (Eo(!0), Io(_o, {
            key: 0
        }, Yo(Nd.value[e.tier], (({
            url: e,
            img: t,
            name: n
        }) => (Eo(), Io("a", {
            class: "sponsor-item",
            href: e,
            target: "_blank",
            rel: "sponsored noopener"
        }, [t.endsWith("png") ? (Eo(), Io("picture", Od, [Ro("source", {
            type: "image/avif",
            srcset: `${Dd}/images/${t.replace(/\.png$/,".avif")}`
        }, null, 8, jd), Ro("img", {
            src: `${Dd}/images/${t}`,
            alt: n
        }, null, 8, Fd)])) : (Eo(), Io("img", {
            key: 1,
            src: `${Dd}/images/${t}`,
            alt: n
        }, null, 8, zd))], 8, Bd)))), 256)) : Wo("", !0), "page" !== e.placement && "special" !== e.tier ? (Eo(), Io("a", Rd, "Your logo")) : Wo("", !0)], 2))
    }
}), [
    ["__scopeId", "data-v-3793b348"]
]);
const Wd = {
        key: 0
    },
    qd = Ro("a", {
        class: "sponsors-aside-text",
        href: "/sponsor/"
    }, "Sponsors", -1),
    Gd = Sn({
        setup(e) {
            const {
                frontmatter: t
            } = Vl();
            return (e, n) => !1 !== yt(t).sponsors ? (Eo(), Io("div", Wd, [qd, No(Ud, {
                tier: "special"
            }), No(Ud, {
                tier: "platinum"
            })])) : Wo("", !0)
        }
    });
const Kd = {
        key: 0,
        class: "vuejobs-container"
    },
    Zd = ["href"],
    Yd = ["src"],
    Jd = {
        class: "vj-job-info"
    },
    Qd = (e => (en("data-v-148cefec"), e = e(), tn(), e))((() => Ro("span", null, "·", -1)));
let Xd = ht([]);
var ep = Nl(Sn({
        setup(e) {
            const {
                frontmatter: t
            } = Vl();
            let n = ht(),
                o = ht(!1);
            return Bn((async () => {
                const e = new IntersectionObserver((t => {
                    t[0].isIntersecting && (o.value = !0, e.disconnect())
                }), {
                    rootMargin: "0px 0px 300px 0px"
                });
                if (e.observe(n.value), Fn((() => e.disconnect())), !Xd.value.length) {
                    const e = await (await fetch("https://vuejobs.com/api/postings")).json();
                    e && e.length && (Xd.value = e.sort((() => .5 - Math.random())).slice(0, 2))
                }
            })), (e, o) => !1 !== yt(t).vuejobs ? (Eo(), Io("div", {
                key: 0,
                ref_key: "vuejobs",
                ref: n
            }, [Xd.value.length ? (Eo(), Io("div", Kd, [(Eo(!0), Io(_o, null, Yo(Xd.value, ((e, t) => (Eo(), Io("div", {
                class: "vj-item",
                key: t
            }, [Ro("a", {
                class: "vj-job-title",
                href: e.link,
                target: "_blank"
            }, [Ro("img", {
                src: e.company_logo,
                alt: "",
                class: "vj-company-logo"
            }, null, 8, Yd), Ro("div", null, [Ro("p", null, u(e.title), 1), Ro("p", Jd, [Do(u(e.company), 1), Qd, Do(" " + u(e.location), 1)])])], 8, Zd)])))), 128))])) : Wo("", !0)], 512)) : Wo("", !0)
        }
    }), [
        ["__scopeId", "data-v-148cefec"]
    ]),
    tp = Object.assign({}, pd, {
        Layout: () => vs(pd.Layout, null, {
            banner: () => vs(gd),
            "sidebar-top": () => vs(Ed),
            "aside-mid": () => vs(Gd),
            "aside-bottom": () => vs(ep)
        }),
        enhanceApp({
            app: e
        }) {
            e.provide("prefer-composition", kd), e.provide("prefer-sfc", xd), e.provide("filter-headers", wd), e.component("VueSchoolLink", $d)
        }
    });
const np = new Set,
    op = () => document.createElement("link");
let sp;
const lp = Sl && (sp = op()) && sp.relList && sp.relList.supports && sp.relList.supports("prefetch") ? e => {
    const t = op();
    t.rel = "prefetch", t.href = e, document.head.appendChild(t)
} : e => {
    const t = new XMLHttpRequest;
    t.open("GET", e, t.withCredentials = !0), t.send()
};
const ip = Sn({
        setup(e, {
            slots: t
        }) {
            const n = ht(!1);
            return Bn((() => {
                n.value = !0
            })), () => n.value && t.default ? t.default() : null
        }
    }),
    rp = tp.NotFound || (() => "404 Not Found"),
    ap = {
        name: "VitePressApp",
        setup() {
            const {
                site: e
            } = Vl();
            return Bn((() => {
                    fn((() => e.value.lang), (e => {
                        document.documentElement.lang = e
                    }), {
                        immediate: !0
                    })
                })),
                function () {
                    if (!Sl) return;
                    if (!window.IntersectionObserver) return;
                    let e;
                    if ((e = navigator.connection) && (e.saveData || /2g/.test(e.effectiveType))) return;
                    const t = window.requestIdleCallback || setTimeout;
                    let n = null;
                    const o = () => {
                        n && n.disconnect(), n = new IntersectionObserver((e => {
                            e.forEach((e => {
                                if (e.isIntersecting) {
                                    const t = e.target;
                                    n.unobserve(t);
                                    const {
                                        pathname: o
                                    } = t;
                                    if (!np.has(o)) {
                                        np.add(o);
                                        const e = $l(o);
                                        lp(e)
                                    }
                                }
                            }))
                        })), t((() => {
                            document.querySelectorAll("#app a").forEach((e => {
                                const {
                                    target: t,
                                    hostname: o,
                                    pathname: s
                                } = e, l = s.match(/\.\w+$/);
                                l && ".html" !== l[0] || "_blank" !== t && o === location.hostname && (s !== location.pathname ? n.observe(e) : np.add(s))
                            }))
                        }))
                    };
                    Bn(o);
                    const s = jl();
                    fn((() => s.path), o), Fn((() => {
                        n && n.disconnect()
                    }))
                }(), () => vs(tp.Layout)
        }
    };

function cp() {
    const e = function () {
            let e, t = Sl;
            return function (e, t) {
                const n = et({
                    path: "/",
                    component: null,
                    data: {
                        frontmatter: {}
                    }
                });

                function o(e = (Sl ? location.href : "/")) {
                    const t = new URL(e, "http://a.com");
                    return t.pathname.endsWith("/") || t.pathname.endsWith(".html") || (t.pathname += ".html", e = t.pathname + t.search + t.hash), Sl && (history.replaceState({
                        scrollPosition: window.scrollY
                    }, document.title), history.pushState(null, "", e)), l(e)
                }
                let s = null;
                async function l(o, i = 0, r = !1) {
                    const a = new URL(o, "http://a.com"),
                        c = s = a.pathname;
                    try {
                        let t = e(c);
                        if ("then" in t && "function" == typeof t.then && (t = await t), s === c) {
                            s = null;
                            const {
                                default: e,
                                __pageData: o
                            } = t;
                            if (!e) throw new Error(`Invalid route component: ${e}`);
                            n.path = c, n.component = at(e), n.data = at(JSON.parse(o)), Sl && Rt((() => {
                                if (a.hash && !i) {
                                    let t = null;
                                    try {
                                        t = document.querySelector(decodeURIComponent(a.hash))
                                    } catch (e) {
                                        console.warn(e)
                                    }
                                    if (t) return void Fl(t, a.hash)
                                }
                                window.scrollTo(0, i)
                            }))
                        }
                    } catch (u) {
                        if (u.message.match(/fetch/) || console.error(u), !r) try {
                            const e = await fetch(Pl.value.base + "hashmap.json");
                            return window.__VP_HASH_MAP__ = await e.json(), void(await l(o, i, !0))
                        } catch (d) {}
                        s === c && (s = null, n.path = c, n.component = t ? at(t) : null)
                    }
                }
                return Sl && (window.addEventListener("click", (e => {
                    const t = e.target.closest("a");
                    if (t) {
                        const {
                            href: n,
                            protocol: s,
                            hostname: l,
                            pathname: i,
                            hash: r,
                            target: a
                        } = t, c = window.location, u = i.match(/\.\w+$/);
                        e.ctrlKey || e.shiftKey || e.altKey || e.metaKey || "_blank" === a || s !== c.protocol || l !== c.hostname || u && ".html" !== u[0] || (e.preventDefault(), i === c.pathname ? r && r !== c.hash && (history.pushState(null, "", r), window.dispatchEvent(new Event("hashchange")), Fl(t, r, t.classList.contains("header-anchor"))) : o(n))
                    }
                }), {
                    capture: !0
                }), window.addEventListener("popstate", (e => {
                    l(location.href, e.state && e.state.scrollPosition || 0)
                })), window.addEventListener("hashchange", (e => {
                    e.preventDefault()
                }))), {
                    route: n,
                    go: o
                }
            }((n => {
                let o = $l(n);
                return t && (e = o), (t || e === o) && (o = o.replace(/\.js$/, ".lean.js")), Sl ? (t = !1, import(o)) : require(o)
            }), rp)
        }(),
        t = _l(ap);
    t.provide(Bl, e);
    const n = function (e) {
        const t = hs((() => Ll(Pl.value, e.path)));
        return {
            site: t,
            theme: hs((() => t.value.themeConfig)),
            page: hs((() => e.data)),
            frontmatter: hs((() => e.data.frontmatter)),
            lang: hs((() => t.value.lang)),
            localePath: hs((() => {
                const {
                    langs: e,
                    lang: n
                } = t.value;
                return Il(Object.keys(e).find((t => e[t].lang === n)) || "/")
            })),
            title: hs((() => e.data.title ? e.data.title + " | " + t.value.title : t.value.title)),
            description: hs((() => e.data.description || t.value.description))
        }
    }(e.route);
    return t.provide(El, n), Sl && zl(e.route, n.site), t.component("Content", ma), t.component("ClientOnly", ip), t.component("Debug", (() => null)), Object.defineProperty(t.config.globalProperties, "$frontmatter", {
        get: () => n.frontmatter.value
    }), tp.enhanceApp && tp.enhanceApp({
        app: t,
        router: e,
        siteData: Pl
    }), {
        app: t,
        router: e
    }
}
if (Sl) {
    const {
        app: e,
        router: t
    } = cp();
    t.go().then((() => {
        e.mount("#app")
    }))
}
export {
    fn as $, en as A, tn as B, Qn as C, ll as D, ko as E, _o as F, tr as G, _i as H, zi as I, Ir as J, An as K, yo as L, vt as M, al as N, Pn as O, et as P, Qs as Q, $s as R, vs as S, go as T, il as U, Bi as V, cl as W, o as X, vl as Y, r as Z, Nl as _, Uo as a, Fn as a0, Ud as a1, Vl as a2, jl as a3, Ol as a4, ms as a5, un as a6, dn as a7, cn as a8, wt as a9, gl as aa, yl as ab, jn as ac, Ed as ad, na as ae, ri as af, di as ag, Rt as ah, Bn as b, Io as c, cp as createApp, Ro as d, Do as e, Jo as f, Sn as g, hs as h, $o as i, No as j, Wr as k, Wo as l, Zl as m, Yo as n, Eo as o, lr as p, Ti as q, ht as r, Gi as s, u as t, yt as u, Ai as v, nn as w, Er as x, Ji as y, Xl as z
};